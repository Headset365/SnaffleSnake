# adaudit

A read-only Active Directory security auditor covering the same ground as
PingCastle's Healthcheck: it enumerates AD via LDAP (and optionally SMB, for
GPO/SYSVOL-dependent checks) and outputs findings as XML and HTML for human
review. It never writes to AD, never modifies a GPO, and never issues an
exploit or coercion call — strictly enumeration, matching the scope agreed
earlier in this project.

## Coverage, honestly

This implements **174 of PingCastle's 187 healthcheck rules with real,
working logic**, and **documents the other 13** as explicit stubs. Of those
13, 6 are structurally per-device/per-server checks (need SAMR, WMI, or
remote registry access to an individual host — a materially different scope
than "query the DC once") and the remaining 7 are genuine AD-level rules
blocked by a specific, named confidence or scope problem (see below) rather
than left unaddressed.

Run `python -m adaudit --coverage-only` any time to print the current, exact
breakdown — it's computed by cross-checking the tool's own rule registry
against a bundled copy of PingCastle's actual rule metadata (pulled from its
open-source repo), so this number is verifiable, not asserted:

```
PingCastle reference rule set: 187 rules

  Implemented (real logic): 174
  Stubbed (documented, not yet implemented): 13
  Missing (not registered at all): 0

By category:
  Anomalies            implemented=65  stubbed=8  / total=73
  PrivilegedAccounts   implemented=43  stubbed=3  / total=46
  StaleObjects         implemented=56  stubbed=0  / total=56
  Trusts               implemented=10  stubbed=2  / total=12
```

### The 6 per-device/per-server stubs

Each needs local state on one specific machine (a DC, a CA server, or every
workstation) rather than the shared AD database — a SAMR query, a WMI/SCM
call, or a remote-registry read, all of which typically need local admin on
*that* host rather than a directory-read domain account:

- `A-MembershipEveryone` (local group membership — needs per-host SAMR)
- `A-DCRefuseComputerPwdChange`, `P-RecoveryModeUnprotected`, `T-TGTDelegation`
  (all live in a DC's local registry/netdom config)
- `P-ServiceDomainAdmin` (installed services — needs per-host WMI/SCM)
- `A-CertEnrollChannelBinding` (IIS Extended Protection on the CA server —
  same pattern, just scoped to the CA host instead of a DC)

### The 7 remaining AD-level stubs, and why

- **`A-BackupMetadata`** — needs the DRSUAPI RPC interface (the same
  interface family DCSync uses). Excluded on purpose, not for difficulty.
- **`A-CertROCA`** — needs the specific Infineon ROCA key-fingerprinting
  algorithm. No vetted implementation was found on PyPI to build on, and
  hand-rolling untested cryptographic pattern-matching risks a confidently
  wrong result either way (false positives *or* false negatives) — worse
  than an honest stub.
- **`A-CertWeakRsaComponent`** — unclear what distinct check this rule ID
  maps to beyond what `A-WeakRSARootCert`/`A-CertWeakDSA` already cover;
  left open rather than guessed at.
- **`A-DnsZoneUpdate1` / `A-DnsZoneUpdate2`** — the setting lives in AD's
  binary `dNSProperty` attribute; confidence in the exact byte layout isn't
  high enough to ship without a way to validate it against real zone data.
- **`P-DelegationFileDeployed`** — the target is inherently unbounded
  ("arbitrary file-deployment mechanisms"), unlike `P-DelegationLoginScript`
  above which has one concrete, resolvable target (`scriptPath`).
- **`T-FileDeployedOutOfDomain`** — needs the GPO software-installation LDAP
  schema (`packageRegistration` objects); attribute names aren't confident
  enough from memory to implement without risking silent false negatives.

(Note: earlier in this conversation I quoted category totals of
63/46/12/66 — that was a manual arithmetic slip. The correct totals, taken
directly from PingCastle's rule metadata, are 56/46/12/73. The bundled
`pingcastle_reference_rules.json` and the coverage command above are the
source of truth going forward.)

### What's genuinely implemented vs. what's stubbed

Implemented rules use one of four techniques, all read-only:
1. **Plain LDAP** — attribute reads and filters (the majority of rules).
2. **Security-descriptor parsing** — a from-scratch MS-DTYP binary parser
   (`secdesc.py`) decodes `nTSecurityDescriptor` bytes already retrieved via
   a normal LDAP search, to find ACL misconfigurations (DCSync rights,
   AdminSDHolder, certificate template ACLs, etc.). Verified against
   hand-built known-good binary structures — see the test transcript in the
   build log.
3. **SYSVOL/GPO content** (`--smb` flag) — GPO discovery via LDAP, then
   `GptTmpl.inf` and `Registry.pol` read over SMB (impacket) and parsed with
   from-scratch parsers for both formats.
4. **RPC bind-only probes** (`--smb` flag) — for the two named-pipe reachability
   checks (`A-DC-Spooler`, `A-DC-Coerce`), a DCE/RPC *bind* to a specific
   interface UUID over the pipe, structurally identical to what `rpcdump.py`
   does to enumerate available interfaces. This confirms an interface is
   registered and reachable; it never calls a method on it (no
   `EfsRpcOpenFileRaw`, no spooler RPC call) — the same boundary discussed
   earlier in this project between checking exposure and issuing a coercion
   technique.
5. **NTFS security-descriptor reads** (`--smb` flag) — `smb_acl.py` uses a
   low-level SMB2 `QUERY_INFO` call to read a file or directory's NTFS
   security descriptor (e.g. a privileged account's logon script, an RODC's
   local SYSVOL root). NTFS security descriptors use the identical MS-DTYP
   binary format as AD's `nTSecurityDescriptor`, so the same `secdesc.py`
   parser handles both — no second parser needed. Read-only: the file is
   opened with `READ_CONTROL` access alone.

Stubbed rules fall into a few honest categories — none are "too hard", they
each need something structurally outside this pass's scope:
- **Per-host access** (SAMR to enumerate local groups, WMI for installed
  services/hotfixes, remote registry for DSRM config) — needs local admin on
  *each* target host, not just a directory-read account.
- **DRSUAPI** (`A-BackupMetadata`) — deliberately excluded per the earlier
  scoping decision to avoid anything resembling the DCSync-adjacent RPC call.
- **Full attack-path graph** (`P-ControlPathIndirect*`) — a BloodHound-style
  transitive closure over every ACE in the domain is a separate subsystem;
  the direct/single-hop dangerous-ACE checks are implemented instead.
- **A handful deferred purely for time** (clearly marked as such, e.g.
  `P-AdminEmailOn`) — trivial to add, just not done in this pass.

Run `python -m adaudit --coverage-only` for the full list with reasons.

## Install

```bash
pip install -r requirements.txt
# or, for SYSVOL/GPO-dependent rules too:
pip install -r requirements.txt impacket
```

## Usage

```bash
# Password auth, LDAP-only rules (no domain join required)
python -m adaudit -d corp.local -dc dc01.corp.local -u auditor -p 'Password123!' -o report

# Kerberos ticket instead of a password (kinit first, or set KRB5CCNAME)
python -m adaudit -d corp.local -dc dc01.corp.local -u auditor -k -o report

# Also enable SMB/SYSVOL-dependent rules (GPO parsing, null-session check,
# SMB signing, named-pipe reachability)
python -m adaudit -d corp.local -dc dc01.corp.local -u auditor -p '...' --smb -o report

# Coverage report only, no AD connection needed
python -m adaudit --coverage-only
```

Outputs `<prefix>.xml` (structured, for feeding into your existing report
pipeline) and `<prefix>.html` (a self-contained, filterable report for direct
human review — no scoring applied, evidence only).

Works from a non-domain-joined host: credentials are passed explicitly at
connection time (NTLM or Kerberos), the same way BloodHound's collectors and
PingCastle's own scanner do.

## Architecture

```
adaudit/
  connection.py      LDAP bind, base DN / config / schema NC discovery, DC list
  gpo.py              GPO enumeration + GptTmpl.inf / Registry.pol parsing (SMB)
  secdesc.py          Security descriptor / ACE binary parser (MS-DTYP)
  constants.py        UAC flags, encryption-type bits, well-known RIDs, GUIDs
  utils.py            FILETIME conversion, UAC helpers, SID/GUID formatting
  models.py           Finding/Status data model + rule registry
  coverage.py         Cross-checks the registry against the bundled reference list
  rules/
    stale_objects.py         S-* rules
    privileged_accounts.py   P-* rules
    trusts.py                 T-* rules
    anomalies.py               A-* rules (core)
    anomalies_certs.py         A-* AD CS / certificate rules
    anomalies_network.py       A-* protocol/signing rules
    anomalies_ptc.py           A-* LAPS/coercion-surface/local-group rules
  reporting/
    xml_report.py       structured XML export
    html_report.py       self-contained filterable HTML report
  pingcastle_reference_rules.json   the 187-rule reference list used by coverage.py
```

Each rule is a small function decorated with `@rule(id, category, subcategory,
title)` returning a `Finding`. Adding a rule — or replacing one of the 37
stubs with a real implementation — means writing one function; nothing else
needs to change. `not_implemented(...)` registers a documented stub with the
same signature so it still shows up in reports and coverage accounting.

## Extending a stub

Pick any stub from `python -m adaudit --coverage-only`, find it in the
relevant `rules/*.py` file (it'll be a `not_implemented(...)` call with the
reason in-line), and replace it with an `@rule(...)`-decorated function
following the pattern of the implemented rules around it. The connection
context (`ctx`) gives you `.search()`, `.search_with_sd()` for ACL-bearing
objects, and (with `--smb`) the `gpo` module's helpers.

## Tests

```bash
python3 tests/test_regression.py      # 34 unit tests: ACL/SID/parser/report correctness
python3 tests/test_smoke_all_rules.py # runs all 187 rules against a mock AD context
```

`test_regression.py` covers every defect found in code review, so a change
that reintroduces one fails loudly. `test_smoke_all_rules.py` executes every
registered rule against an empty mock directory and asserts that no rule
raises, and that both report formats account for all 187 rules — catching
attribute-name typos and empty-result-set mishandling without a live domain.

## Code review fixes (v0.2.0 / v0.3.0)

A full review of the ACL logic and surrounding code found and fixed:

**Correctness (false negatives — findings that would have been missed):**
- `search_with_sd` had no `scope` parameter and always searched SUBTREE, so
  the seven rules reading a *single* object's ACL (AdminSDHolder, domain root,
  DNS partitions, GPO objects) pulled entire subtrees and took `entries[0]`,
  which was not reliably the intended object.
- The dangerous-rights mask omitted `WRITE_PROP`, `SELF_WRITE` and
  `CONTROL_ACCESS`, so the add-member, Shadow-Credentials,
  ForceChangePassword and DCSync attack edges were invisible to every
  ACL rule.
- "Expected privileged" matched on RID alone, so a **foreign** domain's
  RID-512 group holding rights on audited objects was silently skipped.
- Malformed ACEs were dropped silently; a dropped dangerous ACE produced a
  clean verdict with no signal. Now counted and surfaced.
- `days_since` raised `TypeError` on timezone-aware ldap3 datetimes, which a
  broad `except` swallowed — silently disabling `S-PwdLastSet-Cluster`.

**Correctness (false positives):**
- DENY ACEs were parsed but never consulted. A DACL granting then denying a
  right reported a finding. Now deny-precedence is applied.
- `_template_has_broad_enroll` treated *any* un-scoped allow ACE as
  enrollment rights, including the default Read ACE — firing the ESC1/ESC3
  checks on essentially every template in a normal domain.

**Robustness / performance:**
- `ace_size == 0` no longer re-reads the same offset; `bin_sid_to_str` no
  longer raises on truncated SIDs or emits a trailing dash for
  zero-subauthority SIDs.
- GPO list, `GptTmpl.inf` and `Registry.pol` reads are now cached per GPO —
  ~15 rules read the same files, so a 100-GPO domain previously did ~800
  redundant SMB reads.
- SMB sessions are pooled and reused instead of a fresh TCP+auth handshake
  per file read.
- `P-UnkownDelegation` resolved hosts with one LDAP search *per SPN*; now
  resolves all hosts once up front.


## Full-codebase review (v0.3.0)

The v0.2.0 pass reviewed the ACL layer only. This pass covered every remaining
module and audited rule logic against PingCastle's actual rule source.

**Wrong LDAP attribute names (silently returned nothing = false "clean"):**
- `msDS-Reveal-OnDemandGroup` had a spurious hyphen. Correct name is
  `msDS-RevealOnDemandGroup`. Broke 3 RODC rules.
- `msDS-EnabledFeatureBL` should be `msDS-EnabledFeature`, and it lives on the
  Partitions container read at BASE scope. `P-RecycleBin` always reported
  "not enabled" regardless of reality.

**Thresholds that diverged from PingCastle (false positives on real domains):**
- `S-Inactive` / `S-C-Inactive` are PERCENTAGE-based in PingCastle (25% of
  users / 15% of computers). They were implemented as raw counts (>=25 / >=15),
  which fires on essentially any mid-size domain.
- `P-AdminNum` is proportional (>10% of active users, or >50 outright). It was
  a flat `>10 accounts`.
- `A-Krbtgt` threshold is 366 days (then 732/1098/1464). It was 180.

**Wrong rule semantics:**
- `A-SmartCardRequired` flagged *every* smart-card-required account — i.e. it
  penalised good practice. PingCastle flags only ENABLED such accounts whose
  NT hash has not rotated in 91+ days (the hash is generated once and never
  rotates, so a stale one stays valid for pass-the-hash indefinitely).
- `A-BadSuccessor` checked for existing dMSA objects. The actual vulnerability
  is OU delegation permitting dMSA *creation*, and it only applies when a KDS
  root key exists AND a Windows Server 2025 DC is present — both now checked
  as preconditions, returning NOT_APPLICABLE rather than a false alarm.

**connection.py (previously unreviewed):**
- `get_info=ALL` downloaded the entire AD schema on every run; the tool only
  ever reads RootDSE. Now `get_info=DSA`.
- `auto_referrals=True` (ldap3 default) let searches chase referrals into
  other domains — slow, and hangs or fails on credentials not valid there.
  Now disabled, with a 30s receive timeout.
- The DC-list lookup used a bare `conn.search()`, which silently truncates at
  the server page limit. Now uses the paged wrapper.
- Domain SID lookup was an unbounded SUBTREE scan; now BASE scope.

**cli.py / models.py:**
- Neither the LDAP bind nor the pooled SMB session was ever closed. Added a
  `_cleanup()` invoked via `finally`.
- A bind failure dumped a raw traceback; now prints an actionable message
  (check credentials / port / whether LDAPS is required) and exits 3.
- `run_all` now records per-rule `duration_ms`, exported in the XML, so slow
  rules on large domains can be identified.

**Verified correct, no changes needed:** all UAC flag values, access-mask bits,
Kerberos encryption-type bits, well-known RIDs, and every extended-right /
attribute GUID were checked against MS-SAMR / MS-DTYP / MS-KILE — all correct,
and the DCSync GUID pair verified exactly.
