"""
Regression tests for adaudit.

Every test here corresponds to a defect found during the code review, so a
future change that reintroduces one fails loudly. Runnable with no test
framework: `python3 tests/test_regression.py`.
"""
import struct
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from adaudit.secdesc import parse_security_descriptor
from adaudit.utils import bin_sid_to_str, filetime_to_datetime, guid_bin_to_str
from adaudit.acl import (
    effective_dangerous_aces, is_expected_privileged, is_broad_trustee, has_dcsync_rights,
)
from adaudit.constants import ACCESS_MASK, DANGEROUS_RIGHTS_MASK_EXTENDED
from adaudit.gpo import parse_registry_pol, parse_gpttmpl, find_reg_value

FAILURES = []


def check(name, cond, detail=""):
    if cond:
        print(f"  PASS  {name}")
    else:
        print(f"  FAIL  {name} {detail}")
        FAILURES.append(name)


# ---------------------------------------------------------------- builders
def mk_sid(auth, subs):
    return bytes([1, len(subs)]) + auth.to_bytes(6, "big") + b"".join(struct.pack("<I", s) for s in subs)


def mk_ace(atype, mask, sid, size=None, flags=0x00):
    body = struct.pack("<I", mask) + sid
    return struct.pack("<BBH", atype, flags, size if size is not None else 4 + len(body)) + body


def mk_obj_ace(atype, mask, sid, guid_str, flags=0x00):
    import uuid
    g = uuid.UUID(guid_str).bytes_le
    body = struct.pack("<II", mask, 0x1) + g + sid
    return struct.pack("<BBH", atype, flags, 4 + len(body)) + body


def mk_sd(aces, owner=None):
    owner = owner or mk_sid(5, [18])
    acl = struct.pack("<BBHH", 2, 0, 8 + sum(len(a) for a in aces), len(aces)) + b"\x00\x00" + b"".join(aces)
    return struct.pack("<BBH", 1, 0, 0x0004) + struct.pack("<IIII", 20, 0, 0, 20 + len(owner)) + owner + acl


EVERYONE = mk_sid(1, [0])
DOMAIN_SID = "S-1-5-21-111-222-333"
DA_SID = mk_sid(5, [21, 111, 222, 333, 512])
FOREIGN_DA_SID = mk_sid(5, [21, 999, 888, 777, 512])
USER_SID = mk_sid(5, [21, 111, 222, 333, 1105])

print("\n=== SID parsing ===")
check("zero-subauthority SID has no trailing dash",
      bin_sid_to_str(bytes([1, 0]) + (1).to_bytes(6, "big")) == "S-1-1",
      f"got {bin_sid_to_str(bytes([1,0]) + (1).to_bytes(6,'big'))!r}")
check("truncated SID returns '' instead of raising",
      bin_sid_to_str(bytes([1, 5]) + (5).to_bytes(6, "big") + struct.pack("<II", 21, 999)) == "")
check("normal SID parses",
      bin_sid_to_str(DA_SID) == "S-1-5-21-111-222-333-512")

print("\n=== Parser robustness ===")
sd = parse_security_descriptor(mk_sd([mk_ace(0x00, 0x10000000, EVERYONE, size=0)]))
check("ace_size==0 does not hang and is counted malformed", sd.malformed_ace_count >= 1)

bad = mk_ace(0x00, 0x10000000, bytes([1, 5]) + (5).to_bytes(6, "big") + struct.pack("<II", 21, 999))
good = mk_ace(0x00, 0x10000000, EVERYONE)
sd = parse_security_descriptor(mk_sd([bad, good]))
check("malformed ACE is counted, not silently dropped", sd.malformed_ace_count >= 1,
      f"malformed={sd.malformed_ace_count}")

print("\n=== Deny precedence (was: DENY parsed but ignored) ===")
sd = parse_security_descriptor(mk_sd([
    mk_ace(0x01, ACCESS_MASK["GENERIC_ALL"], EVERYONE),   # DENY first
    mk_ace(0x00, ACCESS_MASK["GENERIC_ALL"], EVERYONE),   # then ALLOW
]))
hits = effective_dangerous_aces(sd, DOMAIN_SID)
check("preceding DENY suppresses the ALLOW", len(hits) == 0, f"got {hits}")

sd = parse_security_descriptor(mk_sd([mk_ace(0x00, ACCESS_MASK["GENERIC_ALL"], EVERYONE)]))
check("un-denied ALLOW is still reported", len(effective_dangerous_aces(sd, DOMAIN_SID)) == 1)

print("\n=== Domain-aware privilege check (was: RID-only) ===")
check("own-domain Domain Admins is expected",
      is_expected_privileged("S-1-5-21-111-222-333-512", DOMAIN_SID) is True)
check("FOREIGN domain RID-512 is NOT treated as expected",
      is_expected_privileged("S-1-5-21-999-888-777-512", DOMAIN_SID) is False)
check("BUILTIN Administrators is expected regardless of domain",
      is_expected_privileged("S-1-5-32-544", DOMAIN_SID) is True)

sd = parse_security_descriptor(mk_sd([mk_ace(0x00, ACCESS_MASK["GENERIC_ALL"], FOREIGN_DA_SID)]))
check("foreign Domain Admins ACE IS reported (was false-negative)",
      len(effective_dangerous_aces(sd, DOMAIN_SID)) == 1)
sd = parse_security_descriptor(mk_sd([mk_ace(0x00, ACCESS_MASK["GENERIC_ALL"], DA_SID)]))
check("own Domain Admins ACE is correctly skipped",
      len(effective_dangerous_aces(sd, DOMAIN_SID)) == 0)

print("\n=== Extended rights mask (was: WRITE_PROP/CONTROL_ACCESS missed) ===")
for right in ("WRITE_PROP", "SELF_WRITE", "CONTROL_ACCESS"):
    sd = parse_security_descriptor(mk_sd([mk_ace(0x00, ACCESS_MASK[right], USER_SID)]))
    check(f"{right} ACE is now detected",
          len(effective_dangerous_aces(sd, DOMAIN_SID)) == 1)

print("\n=== DCSync detection ===")
G1 = "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2"
G2 = "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2"
sd = parse_security_descriptor(mk_sd([
    mk_obj_ace(0x05, ACCESS_MASK["CONTROL_ACCESS"], USER_SID, G1),
    mk_obj_ace(0x05, ACCESS_MASK["CONTROL_ACCESS"], USER_SID, G2),
]))
check("both replication rights => DCSync flagged", len(has_dcsync_rights(sd, DOMAIN_SID)) == 1)
sd = parse_security_descriptor(mk_sd([mk_obj_ace(0x05, ACCESS_MASK["CONTROL_ACCESS"], USER_SID, G1)]))
check("only ONE replication right => not flagged (avoids false positive)",
      len(has_dcsync_rights(sd, DOMAIN_SID)) == 0)

print("\n=== Broad trustee detection ===")
check("Everyone is broad", is_broad_trustee("S-1-1-0", DOMAIN_SID))
check("Authenticated Users is broad", is_broad_trustee("S-1-5-11", DOMAIN_SID))
check("own-domain Domain Users is broad", is_broad_trustee(DOMAIN_SID + "-513", DOMAIN_SID))
check("a normal user is not broad", not is_broad_trustee(DOMAIN_SID + "-1105", DOMAIN_SID))

print("\n=== Inherited flag is parsed ===")
sd = parse_security_descriptor(mk_sd([mk_ace(0x00, ACCESS_MASK["GENERIC_ALL"], USER_SID, flags=0x10)]))
check("inherited ACE flagged as inherited", sd.dacl and sd.dacl[0].is_inherited)
check("include_inherited=False filters it out",
      len(effective_dangerous_aces(sd, DOMAIN_SID, include_inherited=False)) == 0)

print("\n=== GUID / FILETIME ===")
import uuid as _uuid
g = "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2"
check("GUID round-trips mixed-endian", guid_bin_to_str(_uuid.UUID(g).bytes_le) == g)
check("FILETIME 'never' sentinel -> None", filetime_to_datetime(0x7FFFFFFFFFFFFFFF) is None)
check("FILETIME zero -> None", filetime_to_datetime(0) is None)

print("\n=== GPO parsers ===")
def regpol_sz(key, value, text):
    return f"[{key};{value};1;{len(text)+1};{text}\x00]".encode("utf-16-le")
def regpol_dword(key, value, d):
    return f"[{key};{value};4;4;".encode("utf-16-le") + struct.pack("<I", d) + "]".encode("utf-16-le")

blob = b"PReg" + (1).to_bytes(4, "little")
blob += regpol_sz(r"Software\Policies\Microsoft\Windows\WindowsUpdate", "WUServer", "http://wsus:8530")
blob += regpol_dword(r"System\CurrentControlSet\Control\Lsa", "NoLMHash", 1)
entries = parse_registry_pol(blob)
check("Registry.pol REG_SZ parsed", find_reg_value(entries, "windowsupdate", "WUServer") == "http://wsus:8530")
check("Registry.pol REG_DWORD parsed as int", find_reg_value(entries, "lsa", "NoLMHash") == 1)

inf = "[Registry Values]\nMACHINE\\System\\CCS\\Control\\Lsa\\LmCompatibilityLevel=4,5\n\n[Privilege Rights]\nSeDebugPrivilege = *S-1-5-32-544\n"
parsed = parse_gpttmpl(inf.encode("utf-16-le"))
check("GptTmpl.inf sections parsed", "Registry Values" in parsed and "Privilege Rights" in parsed)
check("GptTmpl.inf value readable",
      any(k.lower().endswith("lmcompatibilitylevel") for k in parsed["Registry Values"]))

print("\n=== Batch 1: obsolete-OS normalisation (PingCastle parity) ===")
from adaudit.rules.stale_objects import normalise_os, _W10_EOL_BUILDS
_os_cases = [
    ("Windows XP Professional", "Windows XP"),
    # Ordered-table trap: "Embedded" precedes "XP", so XP Embedded is NOT XP.
    ("Windows XP Embedded", "Windows Embedded"),
    ("Windows Server 2003 R2 Standard Edition", "Windows 2003"),
    ("Windows Server 2008 R2 Datacenter", "Windows 2008"),
    ("Windows Server 2012 R2 Standard", "Windows 2012"),
    ("Windows Server 2016 Standard", "Windows 2016"),
    ("Windows Server 2025 Datacenter", "Windows 2025"),
    ("Windows 7 Professional", "Windows 7"),
    ("Windows 8.1 Enterprise", "Windows 8"),
    ("Windows 10 Enterprise", "Windows 10"),
    ("Windows 11 Pro", "Windows 11"),
    ("Windows Vista Business", "Windows Vista"),
    ("Windows 2000 Server", "Windows 2000"),
    ("", "OperatingSystem not set"),
]
for _raw, _exp in _os_cases:
    check(f"normalise_os({_raw!r}) == {_exp!r}", normalise_os(_raw) == _exp,
          f"got {normalise_os(_raw)!r}")
check("W10 EOL table covers 22H2 (19045)", 19045 in _W10_EOL_BUILDS)
check("W10 EOL table does not claim a future build is EOL", 26100 not in _W10_EOL_BUILDS)

print("\n=== Batch 2: Stale Objects parity ===")
import inspect as _insp
from adaudit.rules import stale_objects as _so

_src = _insp.getsource(_so)
# Disabled-account exclusion must be present in the account-flag rules.
for _fn, _name in [(_so.r_pwd_never_expires, "S-PwdNeverExpires"),
                   (_so.r_pwd_not_required, "S-PwdNotRequired"),
                   (_so.r_des_enabled, "S-DesEnabled"),
                   (_so._preauth_check, "S-NoPreAuth*"),
                   (_so._primary_group_check, "S-*PrimaryGroup"),
                   (_so.r_aes_not_enabled, "S-AesNotEnabled")]:
    _s = _insp.getsource(_fn)
    check(f"{_name} excludes disabled accounts", "UAC_ACCOUNTDISABLE" in _s)

check("S-PwdNeverExpires honours the 30-day grace",
      "< 30" in _insp.getsource(_so.r_pwd_never_expires))
check("S-PwdNeverExpires exempts HealthMailbox",
      "healthmailbox" in _insp.getsource(_so.r_pwd_never_expires).lower())
check("S-PwdNotRequired exempts Monitoring Mailboxes",
      "Monitoring Mailboxes" in _insp.getsource(_so.r_pwd_not_required))
check("S-DesEnabled checks enctype DES bits, not just the UAC flag",
      "ENCTYPE_DES_CBC_CRC" in _insp.getsource(_so.r_des_enabled))
check("S-Duplicate detects the $duplicate- prefix",
      "$duplicate-" in _insp.getsource(_so.r_duplicate))
check("S-NoPreAuth and S-NoPreAuthAdmin are disjoint (admin split)",
      "privileged_only" in _insp.getsource(_so._preauth_check))
_pg = _insp.getsource(_so._primary_group_check)
check("primary-group check distinguishes users from computers", "is_computer" in _pg)
check("computer primary-group allows 516/521 only in the DC OU",
      "ou=domain controllers,dc=" in _pg.lower())
check("user primary-group allows 515 only for (g)MSA",
      "managedserviceaccount" in _pg.lower())
_aes = _insp.getsource(_so.r_aes_not_enabled)
check("S-AesNotEnabled covers computers too", "objectCategory=computer" in _aes)
check("S-AesNotEnabled implements the pre-2008-DC password branch", "baseline_days" in _aes)

print("\n=== Batch 3: Privileged Accounts parity ===")
from adaudit.rules import privileged_accounts as _pa
_g = _insp.getsource

check("P-DNSAdmin is NOT_APPLICABLE (deactivated upstream)",
      "NOT_APPLICABLE" in _g(_pa.r_dns_admin))
check("P-OperatorsEmpty covers only Account+Server Operators",
      "Backup Operators" not in _g(_pa.r_operators_empty)
      and "Server Operators" in _g(_pa.r_operators_empty))
check("P-AdminEmailOn requires enabled accounts",
      "UAC_ACCOUNTDISABLE" in _g(_pa.r_admin_email_on))
check("P-Delegated excludes gMSA",
      "groupmanagedserviceaccount" in _g(_pa.r_p_delegated).lower())
check("P-UnconstrainedDelegation excludes RODCs too",
      "primaryGroupID=521" in _g(_pa.r_unconstrained_delegation))
# dSHeuristics character positions (were crossed)
check("AdminSDExMask reads dSHeuristics index 15",
      "[15]" in _g(_pa.r_ds_heuristics_adminsd))
check("DoListObject reads dSHeuristics index 2",
      "[2]" in _g(_pa.r_ds_heuristics_list_object))
# DC delegation triad mapped to the right attributes
_a2d2, _t2a4d, _src = _g(_pa.r_delegation_dc_a2d2), _g(_pa.r_delegation_dc_t2a4d), _g(_pa.r_delegation_dc_source_deleg)
check("a2d2 = AllowedToDelegateTo without protocol transition",
      "not d[\"protocol_transition\"]" in _a2d2)
check("t2a4d = AllowedToDelegateTo WITH protocol transition",
      'd["protocol_transition"]' in _t2a4d and "not d[" not in _t2a4d)
check("sourcedeleg = RBCD on the DC", 'has_rbcd' in _src)
check("P-DelegationEveryone inspects object delegations, not RBCD",
      "_enumerate_delegations" in _g(_pa.r_delegation_everyone))
check("P-DelegationKeyAdmin checks a -527 ACE on the domain root, not membership",
      "-527" in _g(_pa.r_delegation_key_admin))
check("P-DisplaySpecifier flags UNC paths in field [2]",
      "parts[2]" in _g(_pa.r_display_specifier))

print("\n=== Batch 4: Anomalies (non-cert) parity ===")
from adaudit.rules import anomalies as _an
from adaudit.rules import anomalies_ptc as _aptc
from adaudit.rules import anomalies_network as _anet

# All four dSHeuristics rules read a specific character index; all four were wrong.
check("dSHeuristics anonymous LDAP reads index 6", "_dsh_char(val, 6)" in _g(_an.r_dsh_anonymous))
check("dSHeuristics anon NSPI reads index 7", "_dsh_char(val, 7)" in _g(_an.r_dsh_anon_nspi))
check("dSHeuristics uniqueness reads index 20", "_dsh_char(val, 20)" in _g(_an.r_dsh_uniqueness))
check("dSHeuristics LDAP security reads index 27", "_dsh_char(val, 27)" in _g(_an.r_dsh_ldap_security))

# Polarity: Authenticated Users PRESENT is the finding (was inverted).
_pw = _g(_an.r_pre2k_auth_users)
check("A-PreWin2000AuthenticatedUsers triggers when present (not inverted)",
      "Status.TRIGGERED if hit else Status.CLEAN" in _pw)
check("A-PreWin2000Anonymous also matches Everyone (S-1-1-0)",
      "s-1-1-0" in _g(_an.r_pre2k_anonymous).lower())
check("A-PreWin2000Other uses the CN=S- structural test",
      'startswith("CN=S-")' in _g(_an.r_pre2k_other))

check("A-ProtectedUsers tests schema objectVersion < 69, not membership",
      "objectVersion" in _g(_aptc.r_protected_users_domainwide)
      and "69" in _g(_aptc.r_protected_users_domainwide))
check("A-NoServicePolicy requires min length >= 20",
      ">= 20" in _g(_an.r_no_service_policy))
check("A-LDAPSigningDisabled reads LDAPClientIntegrity, not Server",
      "LDAPClientIntegrity" in _g(_anet.r_ldap_signing_disabled))
check("A-DC-Coerce is a RestrictSendingNTLMTraffic mitigation check",
      "restrictsendingntlmtraffic" in _g(_aptc.r_dc_coerce).lower())

print("\n=== Batch 5: AD CS / certificate parity ===")
from adaudit.rules import anomalies_certs as _ac
check("cert source is NTAuthCertificates, not just the CA container",
      "NTAuthCertificates" in _g(_ac._cas))
check("signature algorithms classified by OID", "_SIG_OID" in _insp.getsource(_ac))
check("SHA-0 is detectable via OID 1.3.14.3.2.15 (was declared impossible)",
      "1.3.14.3.2.15" in _insp.getsource(_ac))
check("A-WeakRSARootCert threshold is <1024", "rsa_lt1024" in _g(_ac.r_weak_rsa_root))
check("A-WeakRSARootCert2 is the 1024-2047 size band, not 'intermediate'",
      "rsa_1024_2048" in _g(_ac.r_weak_rsa_root2))
check("A-CertWeakDSA tests DigitalSignature usage, not key size",
      "dsa_signing" in _g(_ac.r_cert_weak_dsa))
check("A-DCLdapsProtocol covers SSL only", 'startswith("SSL")' in _g(_ac.r_dc_ldaps_protocol))
check("A-DCLdapsProtocolAdvanced covers TLS1.0/1.1, not ciphers",
      'startswith("TLS")' in _g(_ac.r_dc_ldaps_protocol_advanced))

print("\n=== Batch 6: Trusts parity ===")
from adaudit.rules import trusts as _tr
check("T-AlgsAES reads msDS-SupportedEncryptionTypes, not a trustAttributes bit",
      "enc_types" in _g(_tr.r_trust_aes))
check("T-AlgsAES skips outbound-only trusts", 'trust_dir"] == 2' in _g(_tr.r_trust_aes))
check("T-Downlevel tests trustType == 1", 'trust_type"] == 1' in _g(_tr.r_trust_downlevel))
check("T-Inactive uses whenChanged + 40 days", "40" in _g(_tr.r_trust_inactive)
      and "when_changed" in _g(_tr.r_trust_inactive))
check("T-AzureADSSO threshold is one year", ">= 365" in _g(_tr.r_azure_sso))
check("T-SIDHistoryDangerous flags any RID < 1000", "< 1000" in _g(_tr.r_sidhistory_dangerous))
check("T-ScriptOutOfDomain also covers GPO logon scripts",
      "scripts.ini" in _g(_tr.r_script_out_of_domain))

print("\n=== Report generation ===")
from adaudit.models import Finding, Status
from adaudit.reporting import build_xml, build_html
from xml.etree import ElementTree as ET

findings = [
    Finding("S-Inactive", "StaleObjects", "InactiveUserOrComputer", "Inactive users", Status.TRIGGERED,
            "2 found", [{"account": "a<b>&", "days": 200}]),
    Finding("P-DCOwner", "PrivilegedAccounts", "ACLCheck", "DC owner", Status.CLEAN, "none"),
]
xml_out = build_xml(findings, "corp.local")
root = ET.fromstring(xml_out)
check("XML is well-formed and parseable", root.tag == "ADAuditReport")
check("XML contains both rules", len(root.findall(".//Rule")) == 2)
check("XML escapes special chars in evidence", "a<b>&" in [
    f.text for f in root.findall(".//Field")])

html_out = build_html(findings, "corp.local")
check("HTML renders both findings", html_out.count('class="f s-') == 2)
check("HTML defaults to the failures view when there are failures",
      'data-boot="triggered"' in html_out)
check("HTML shows an evidence affordance when evidence exists", 'class="evcue"' in html_out)
check("HTML humanizes snake_case evidence headers", "Password age days" in build_html(
      [Finding("X", "C", "S", "t", Status.TRIGGERED, "s", [{"password_age_days": 9}])], "d"))
check("HTML escapes evidence (no raw injection)", "a<b>&" not in html_out and "a&lt;b&gt;&amp;" in html_out)
check("HTML humanizes acronyms correctly", "ACL Check" in html_out and "A C L" not in html_out)

print("\n" + "=" * 60)
if FAILURES:
    print(f"FAILED: {len(FAILURES)} test(s): {FAILURES}")
    sys.exit(1)
print("ALL REGRESSION TESTS PASSED")
