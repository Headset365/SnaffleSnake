"""
End-to-end smoke test: runs ALL 187 registered rules against a mock AD
context and verifies (a) no rule raises an unhandled exception, and (b) both
report formats generate correctly from the real rule output.

This catches the class of bug unit tests miss -- a rule that references a
missing attribute, mishandles an empty result set, or returns the wrong shape
-- without needing a live domain.
"""
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import adaudit.rules  # noqa: F401 - registers rules
from adaudit.models import REGISTRY, run_all, Status
from adaudit.reporting import build_xml, build_html


class MockAttr:
    def __init__(self, values):
        self._v = values if isinstance(values, list) else [values]

    @property
    def value(self):
        return self._v[0] if self._v else None

    @property
    def values(self):
        return self._v

    @property
    def raw_values(self):
        return [v if isinstance(v, bytes) else str(v).encode() for v in self._v]

    def __str__(self):
        return str(self.value) if self.value is not None else ""

    def __len__(self):
        return len(self._v)


class MockEntry:
    """Mimics an ldap3 Entry: missing attributes raise, present ones return
    MockAttr -- matching the real library's behaviour that rules code against."""
    def __init__(self, attrs):
        self._attrs = {k: MockAttr(v) for k, v in attrs.items()}

    def __getitem__(self, key):
        if key not in self._attrs:
            raise KeyError(key)
        return self._attrs[key]

    def __contains__(self, key):
        return key in self._attrs


class MockServerInfo:
    other = {
        "domainFunctionality": ["7"],
        "forestFunctionality": ["7"],
        "defaultNamingContext": ["DC=corp,DC=local"],
    }


class MockServer:
    info = MockServerInfo()
    host = "127.0.0.1"
    port = 389


class MockConn:
    bound = True
    server = MockServer()
    entries = []
    result = {}


class MockCtx:
    """Returns empty result sets for every search. Every rule must handle
    'nothing found' gracefully -- that is itself the assertion."""
    def __init__(self):
        self.conn = MockConn()
        self.server = MockServer()
        self.domain = "corp.local"
        self.base_dn = "DC=corp,DC=local"
        self.config_nc = "CN=Configuration,DC=corp,DC=local"
        self.schema_nc = "CN=Schema,CN=Configuration,DC=corp,DC=local"
        self.domain_sid = "S-1-5-21-111-222-333"
        self.dc_hostnames = []
        self.smb_available = False
        self._cache = {}

    def search(self, base, filt, attributes=None, scope=None, controls=None, paged_size=1000):
        return []

    def search_with_sd(self, base, filt, attributes=None, scope=None):
        return []

    def get_raw_sd_bytes(self, entry):
        return None


def main():
    ctx = MockCtx()
    print(f"Running all {len(REGISTRY)} registered rules against mock context...\n")
    findings = run_all(ctx)

    by_status = {}
    for f in findings:
        by_status[f.status] = by_status.get(f.status, 0) + 1

    print("Status breakdown:")
    for st, n in sorted(by_status.items(), key=lambda x: -x[1]):
        print(f"  {st.value:20s} {n}")

    errors = [f for f in findings if f.status == Status.ERROR]
    print(f"\nRules that raised an unhandled exception: {len(errors)}")
    for f in errors[:25]:
        first_line = (f.summary or "").split("\n")[0][:100]
        print(f"  {f.rule_id:32s} {first_line}")

    print(f"\nTotal findings returned: {len(findings)} (expected {len(REGISTRY)})")

    # Reports must generate from real rule output, not just synthetic findings.
    xml_out = build_xml(findings, "corp.local")
    html_out = build_html(findings, "corp.local")
    from xml.etree import ElementTree as ET
    root = ET.fromstring(xml_out)
    n_rules_xml = len(root.findall(".//Rule"))
    n_findings_html = html_out.count('class="f s-')

    print(f"\nXML:  well-formed, {n_rules_xml} <Rule> elements")
    print(f"HTML: {n_findings_html} finding blocks, {len(html_out):,} bytes")

    ok = (len(findings) == len(REGISTRY)
          and n_rules_xml == len(REGISTRY)
          and n_findings_html == len(REGISTRY))
    if not ok:
        print("\nFAIL: report output does not account for every rule")
        return 1
    # Errors are reported but not fatal here: with an all-empty mock, a rule
    # that legitimately requires data may surface as ERROR. The count is what
    # we watch -- it should stay near zero.
    if len(errors) > 5:
        print(f"\nFAIL: {len(errors)} rules crashed on empty input (threshold 5)")
        return 1
    print("\nSMOKE TEST PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
