"""
Smoke test against a POPULATED directory.

The original smoke test returns [] for every search, so every code path guarded
by `if entries:` -- i.e. all the actual parsing -- is never executed. That is
exactly how two live-only bugs (the paged-cookie AttributeError and the
bytes-valued attributes) shipped while the suite was green.

This mock returns realistic entries instead, and deliberately includes the
shapes a real directory produces but a hand-built mock usually does not:

  * attributes that are simply absent on some objects
  * bytes-valued attributes (what ldap3 hands back with no formatter)
  * timezone-aware datetimes (ldap3's generalized-time format)
  * "never"/0 FILETIME sentinels
  * an ldap3 `result` dict whose 'controls' key is present but None

A rule may legitimately report TRIGGERED or CLEAN here. What it must not do is
raise.
"""
import datetime as _dt
import os
import struct
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import adaudit.rules  # noqa: F401
from adaudit.models import REGISTRY, run_all, Status

DOMAIN_SID = "S-1-5-21-111-222-333"


def _sid_bytes(rid, sub=(21, 111, 222, 333)):
    subs = list(sub) + [rid]
    return bytes([1, len(subs)]) + (5).to_bytes(6, "big") + b"".join(
        struct.pack("<I", s) for s in subs)


def _sd_bytes():
    """A minimal but well-formed security descriptor with one dangerous ACE."""
    everyone = bytes([1, 1]) + (1).to_bytes(6, "big") + struct.pack("<I", 0)
    ace_body = struct.pack("<I", 0x10000000) + everyone
    ace = struct.pack("<BBH", 0x00, 0x00, 4 + len(ace_body)) + ace_body
    acl = struct.pack("<BBHH", 2, 0, 8 + len(ace), 1) + b"\x00\x00" + ace
    owner = _sid_bytes(512)
    return (struct.pack("<BBH", 1, 0, 0x0004)
            + struct.pack("<IIII", 20, 0, 0, 20 + len(owner)) + owner + acl)


class Attr:
    def __init__(self, values):
        self._v = values if isinstance(values, list) else [values]

    @property
    def value(self):
        return self._v[0] if self._v else None

    @property
    def values(self):
        return self._v

    @property
    def raw_values(self):
        out = []
        for v in self._v:
            out.append(v if isinstance(v, bytes) else str(v).encode())
        return out

    def __str__(self):
        return str(self.value) if self.value is not None else ""

    def __len__(self):
        return len(self._v)

    def __iter__(self):
        return iter(self._v)


class Entry:
    def __init__(self, **attrs):
        self._a = {k: Attr(v) for k, v in attrs.items()}

    def __getitem__(self, k):
        if k not in self._a:
            raise KeyError(k)  # ldap3 raises on absent attributes
        return self._a[k]

    def __contains__(self, k):
        return k in self._a


_NOW = _dt.datetime.utcnow()
_AWARE = _dt.datetime(2019, 3, 1, tzinfo=_dt.timezone.utc)   # ldap3 generalized time
_OLD_FT = int((_dt.datetime(2018, 1, 1) - _dt.datetime(1970, 1, 1)).total_seconds()
              * 10_000_000) + 116444736000000000


def _user(name, **over):
    base = dict(
        sAMAccountName=name, distinguishedName=f"CN={name},CN=Users,DC=corp,DC=local",
        userAccountControl="512", pwdLastSet=str(_OLD_FT), lastLogonTimestamp=str(_OLD_FT),
        objectSid=_sid_bytes(1105), objectClass=["top", "person", "user"],
        whenCreated=_AWARE, adminCount="1", mail=f"{name}@corp.local",
        primaryGroupID="513", nTSecurityDescriptor=_sd_bytes(),
    )
    base.update(over)
    return Entry(**base)


def _computer(name, os_name="Windows Server 2012 R2 Standard", **over):
    base = dict(
        sAMAccountName=f"{name}$", dNSHostName=f"{name}.corp.local",
        distinguishedName=f"CN={name},OU=Domain Controllers,DC=corp,DC=local",
        operatingSystem=os_name, operatingSystemVersion="6.3 (9600)",
        userAccountControl="4096", primaryGroupID="516",
        pwdLastSet=str(_OLD_FT), lastLogonTimestamp=str(_OLD_FT),
        objectSid=_sid_bytes(1010), objectClass=["top", "computer"],
        whenCreated=_AWARE, nTSecurityDescriptor=_sd_bytes(),
    )
    base.update(over)
    return Entry(**base)


class ServerInfo:
    other = {
        "domainFunctionality": ["7"], "forestFunctionality": ["7"],
        "defaultNamingContext": ["DC=corp,DC=local"],
    }


class Server:
    info = ServerInfo()
    host = "127.0.0.1"
    port = 389


class Conn:
    bound = True
    server = Server()
    entries = []
    # The exact shape that broke the paged-search loop live: key present, value None.
    result = {"result": 0, "controls": None}


class PopulatedCtx:
    def __init__(self):
        self.conn = Conn()
        self.server = Server()
        self.domain = "corp.local"
        self.base_dn = "DC=corp,DC=local"
        self.config_nc = "CN=Configuration,DC=corp,DC=local"
        self.schema_nc = "CN=Schema,CN=Configuration,DC=corp,DC=local"
        self.domain_sid = DOMAIN_SID
        self.dc_hostnames = ["dc01.corp.local"]
        self.smb_available = False
        self._cache = {}

    def search(self, base, filt, attributes=None, scope=None, controls=None, paged_size=1000):
        f = (filt or "").lower()
        if "computer" in f or "515" in f or "516" in f or "521" in f:
            return [_computer("DC01"), _computer("WS01", "Windows 10 Enterprise",
                                                 primaryGroupID="515")]
        if "trusteddomain" in f:
            return [Entry(trustPartner="other.local", trustDirection="3", trustType="2",
                          trustAttributes="8", flatName="OTHER", whenChanged=_AWARE,
                          securityIdentifier=_sid_bytes(0))]
        if "domaindns" in f or "objectclass=*" in f:
            return [Entry(distinguishedName=base, objectSid=_sid_bytes(0),
                          **{"ms-DS-MachineAccountQuota": "10", "minPwdLength": "7",
                             "pwdProperties": "1", "dSHeuristics": "0000000",
                             "objectVersion": "88", "nTSecurityDescriptor": _sd_bytes(),
                             "wellKnownObjects": ["GUID:CN=Users,DC=corp,DC=local"]})]
        # Default: a couple of users, one missing several attributes entirely.
        return [_user("jdoe"), Entry(sAMAccountName=b"bytesuser",
                                     distinguishedName="CN=b,DC=corp,DC=local")]

    def search_with_sd(self, base, filt, attributes=None, scope=None):
        return self.search(base, filt, attributes=attributes, scope=scope)

    def get_raw_sd_bytes(self, entry):
        try:
            return entry["nTSecurityDescriptor"].raw_values[0]
        except Exception:
            return None


def main():
    ctx = PopulatedCtx()
    print(f"Running all {len(REGISTRY)} rules against a POPULATED mock directory...\n")
    findings = run_all(ctx)

    by = {}
    for f in findings:
        by[f.status] = by.get(f.status, 0) + 1
    for st, n in sorted(by.items(), key=lambda x: -x[1]):
        print(f"  {st.value:20s} {n}")

    errors = [f for f in findings if f.status == Status.ERROR]
    print(f"\nRules that raised: {len(errors)}")
    for f in errors:
        print(f"  {f.rule_id:32s} {(f.summary or '')[:90]}")

    # Reports must still build from this data.
    from adaudit.reporting import build_xml, build_html
    from xml.etree import ElementTree as ET
    ET.fromstring(build_xml(findings, "corp.local"))
    html = build_html(findings, "corp.local")
    assert html.count('class="f s-') == len(REGISTRY)
    print("\nXML and HTML built successfully from populated data.")

    # Some rules legitimately cannot run without a live DC or SMB; the bar is that
    # parsing paths do not explode. Anything above a small floor is a real bug.
    if len(errors) > 2:
        print(f"\nFAIL: {len(errors)} rules raised against populated data (threshold 2)")
        return 1
    print("POPULATED SMOKE TEST PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
