"""
XML report generation. Produces a flat, machine-readable document -- one
<Rule> element per finding, with nested <Evidence> rows -- intended to feed
into an existing report pipeline (per the brief: scoring/formatting happens
downstream, this just needs to carry the evidence faithfully).
"""
from __future__ import annotations

import datetime as _dt
from xml.etree import ElementTree as ET
from xml.dom import minidom

from ..models import Finding


def _sub(parent, tag, text=None):
    el = ET.SubElement(parent, tag)
    if text is not None:
        el.text = str(text)
    return el


def build_xml(findings: list[Finding], domain: str) -> str:
    root = ET.Element("ADAuditReport")
    root.set("domain", domain)
    root.set("generatedAt", _dt.datetime.utcnow().isoformat() + "Z")

    summary = ET.SubElement(root, "Summary")
    counts: dict[str, int] = {}
    for f in findings:
        counts[f.status.value] = counts.get(f.status.value, 0) + 1
    for status, n in counts.items():
        s = ET.SubElement(summary, "StatusCount")
        s.set("status", status)
        s.set("count", str(n))

    rules_el = ET.SubElement(root, "Rules")
    for f in findings:
        rule_el = ET.SubElement(rules_el, "Rule")
        rule_el.set("id", f.rule_id)
        rule_el.set("category", f.category)
        rule_el.set("subcategory", f.subcategory)
        rule_el.set("status", f.status.value)
        _sub(rule_el, "Title", f.title)
        _sub(rule_el, "Summary", f.summary)
        if f.error:
            _sub(rule_el, "Error", f.error)
        if f.evidence:
            ev_el = ET.SubElement(rule_el, "Evidence")
            ev_el.set("count", str(len(f.evidence)))
            for row in f.evidence:
                row_el = ET.SubElement(ev_el, "Item")
                for k, v in row.items():
                    field_el = ET.SubElement(row_el, "Field")
                    field_el.set("name", str(k))
                    field_el.text = str(v)

    raw = ET.tostring(root, encoding="unicode")
    return minidom.parseString(raw).toprettyxml(indent="  ")


def write_xml(findings, domain: str, path: str):
    xml_str = build_xml(findings, domain)
    with open(path, "w", encoding="utf-8") as f:
        f.write(xml_str)
