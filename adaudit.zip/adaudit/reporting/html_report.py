"""
HTML report generation.

Design brief: this artifact is read by a security consultant triaging findings
before they enter a client report, and sometimes by the client's own IT team.
Its job is fast, defensible triage -- what failed, how concentrated, and what
the supporting evidence is.

Visual direction is drafting/blueprint: an audit is a structural survey of a
directory, so the language is cool blue-grey, fine rules, precise annotation.
The hero is a matrix of every rule in the reference set, one cell each, coloured
by outcome -- because the rule set is fixed and known, the *shape* of the
failures across it is the most informative thing available at a glance.
Monospace appears only where the content is genuinely machine data (rule IDs,
SIDs, DNs), never as a decorative label style.

Single self-contained file: no external assets, works offline, prints cleanly.
"""
from __future__ import annotations

import datetime as _dt
import html
import re

from ..models import Finding, Status

STATUS_LABEL = {
    Status.TRIGGERED: "Needs attention",
    Status.CLEAN: "Passed",
    Status.NOT_APPLICABLE: "Not applicable",
    Status.NOT_IMPLEMENTED: "Not implemented",
    Status.REQUIRES_SMB: "Skipped",
    Status.ERROR: "Could not run",
}

STATUS_ORDER = [
    Status.TRIGGERED, Status.ERROR, Status.CLEAN,
    Status.REQUIRES_SMB, Status.NOT_IMPLEMENTED, Status.NOT_APPLICABLE,
]

CSS = """
:root{
  --paper:#E9EEF3;
  --surface:#FFFFFF;
  --ink:#141F29;
  --ink-mid:#4C5F6E;
  --ink-soft:#7B8B99;
  --rule:#C6D3DE;
  --rule-soft:#DFE7EE;
  --fail:#A62639;
  --fail-bg:#F8E9EC;
  --pass:#2C6A51;
  --warn:#9A5B1E;
  --focus:#1F6FB2;
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{
  margin:0;background:var(--paper);color:var(--ink);
  font-family:"Inter","Segoe UI Variable Text","Segoe UI",-apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;
  font-size:15px;line-height:1.5;font-variant-numeric:tabular-nums;
}
.wrap{max-width:1080px;margin:0 auto;padding:40px 28px 120px}
code{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:.92em}
:focus-visible{outline:2px solid var(--focus);outline-offset:2px;border-radius:2px}

/* masthead */
.masthead{display:flex;justify-content:space-between;align-items:flex-end;gap:24px;flex-wrap:wrap;
  padding-bottom:18px;border-bottom:2px solid var(--ink)}
.masthead h1{margin:0;font-size:26px;font-weight:640;letter-spacing:-.021em;line-height:1.15}
.masthead .domain{margin:4px 0 0;font-family:ui-monospace,"SF Mono",Consolas,monospace;
  font-size:14px;color:var(--ink-mid)}
.masthead .stamp{text-align:right;font-size:13px;color:var(--ink-soft);line-height:1.7}
.masthead .stamp b{display:block;color:var(--ink-mid);font-weight:600}

/* hero: verdict + matrix */
.hero{display:grid;grid-template-columns:minmax(190px,215px) 1fr;gap:44px;
  padding:32px 0 30px;border-bottom:1px solid var(--rule)}
.verdict .count{font-size:76px;line-height:.86;font-weight:660;letter-spacing:-.045em;color:var(--fail)}
.verdict .count.zero{color:var(--pass);font-size:52px}
.verdict .caption{margin-top:12px;font-size:15px;color:var(--ink-mid);max-width:22ch}
.verdict .breakdown{margin-top:18px;padding-top:16px;border-top:1px solid var(--rule);font-size:13px}
.verdict .breakdown div{display:flex;justify-content:space-between;gap:12px;padding:2.5px 0;
  color:var(--ink-mid)}
.verdict .breakdown span:last-child{color:var(--ink)}

.matrix h2{margin:0 0 3px;font-size:14px;font-weight:620;letter-spacing:-.006em}
.matrix .lede{margin:0 0 18px;font-size:13px;color:var(--ink-soft);max-width:62ch}
.mrow{margin-bottom:15px}
.mrow .mlabel{display:flex;justify-content:space-between;align-items:baseline;gap:14px;
  font-size:12.5px;color:var(--ink-mid);margin-bottom:6px}
.mrow .mlabel .mcount{color:var(--ink-soft)}
.cells{display:flex;flex-wrap:wrap;gap:2.5px}
.cell{width:11px;height:11px;border:0;padding:0;border-radius:1px;cursor:pointer;
  background:var(--rule);opacity:0;animation:cellIn .3s ease forwards;transition:transform .1s ease}
.cell.s-triggered{background:var(--fail)}
.cell.s-error{background:var(--warn)}
.cell.s-clean{background:var(--pass);animation-name:cellInDim}
.cell.s-requires_smb,.cell.s-not_implemented,.cell.s-not_applicable{
  background:transparent;box-shadow:inset 0 0 0 1px var(--rule)}
.cell:hover,.cell:focus-visible{transform:scale(1.5);z-index:2}
@keyframes cellIn{to{opacity:1}}
@keyframes cellInDim{to{opacity:.4}}
@media (prefers-reduced-motion:reduce){
  .cell{animation:none;opacity:1;transition:none}
  .cell.s-clean{opacity:.4}
}

/* controls */
.controls{position:sticky;top:0;z-index:5;background:var(--paper);
  display:flex;gap:10px;flex-wrap:wrap;align-items:center;
  padding:16px 0 14px;border-bottom:1px solid var(--rule)}
.controls input[type=search],.controls select{
  font:inherit;font-size:14px;padding:8px 11px;background:var(--surface);
  border:1px solid var(--rule);border-radius:3px;color:var(--ink)}
.controls input[type=search]{flex:1;min-width:210px}
.chip{font:inherit;font-size:13px;padding:7px 13px;border-radius:3px;cursor:pointer;
  background:var(--surface);border:1px solid var(--rule);color:var(--ink-mid)}
.chip[aria-pressed=true]{background:var(--ink);border-color:var(--ink);color:#fff}
.resultcount{font-size:13px;color:var(--ink-soft);margin-left:auto}

/* findings */
.cat{margin-top:34px}
.cat > h2{margin:0 0 2px;font-size:19px;font-weight:620;letter-spacing:-.014em}
.cat > .catmeta{margin:0 0 14px;font-size:13px;color:var(--ink-soft)}
.sub{margin:18px 0}
.sub > h3{margin:0 0 7px;font-size:13px;font-weight:600;color:var(--ink-mid)}

.f{background:var(--surface);border:1px solid var(--rule-soft);border-left:3px solid var(--rule);
  border-radius:3px;margin-bottom:5px;padding:11px 14px;cursor:pointer}
.f:hover{border-color:var(--rule)}
.f.s-triggered{border-left-color:var(--fail);background:var(--fail-bg);border-color:#EED3D8}
.f.s-error{border-left-color:var(--warn)}
.f.s-clean{border-left-color:var(--pass)}
.f .top{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap}
.f .rid{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:12px;color:var(--ink-soft);
  flex:0 0 auto;min-width:86px}
.f .title{font-weight:590;letter-spacing:-.006em}
.f .tag{margin-left:auto;order:2;font-size:12px;color:var(--ink-soft);white-space:nowrap}
.f .evcue{order:3;font-size:12px;color:var(--ink-soft);white-space:nowrap;
  display:inline-flex;align-items:center;gap:5px}
.f .evcue::after{content:"";width:5px;height:5px;border-right:1.4px solid currentColor;
  border-bottom:1.4px solid currentColor;transform:rotate(45deg) translate(-1px,-1px);
  transition:transform .14s ease}
.f.open .evcue::after{transform:rotate(-135deg) translate(-2px,-2px)}
@media (prefers-reduced-motion:reduce){.f .evcue::after{transition:none}}
.f.s-triggered .tag{color:var(--fail);opacity:.75}
.f .sum{margin-top:4px;font-size:13.5px;color:var(--ink-mid);max-width:82ch}
.f.s-requires_smb,.f.s-not_implemented,.f.s-not_applicable{opacity:.72}
.f.s-requires_smb .title,.f.s-not_implemented .title,.f.s-not_applicable .title{font-weight:520}
.f .ev{display:none;margin-top:11px;border-top:1px solid var(--rule-soft);padding-top:10px}
.f.open .ev{display:block}
.f .evhead{font-size:12px;color:var(--ink-soft);margin-bottom:6px}
table{border-collapse:collapse;width:100%;font-size:12.5px;
  font-family:ui-monospace,"SF Mono",Consolas,monospace}
th,td{text-align:left;padding:5px 9px;border-bottom:1px solid var(--rule-soft);
  vertical-align:top;word-break:break-word}
th{color:var(--ink-soft);font-weight:500;border-bottom-color:var(--rule)}
tbody tr:last-child td{border-bottom:0}
.more{margin-top:7px;font-size:12px;color:var(--ink-soft)}
.empty{padding:44px 0;text-align:center;color:var(--ink-soft);font-size:14px}

footer{margin-top:56px;padding-top:16px;border-top:1px solid var(--rule);
  font-size:12.5px;color:var(--ink-soft);max-width:80ch;line-height:1.65}
.hidden{display:none !important}

@media (max-width:820px){
  .hero{grid-template-columns:1fr;gap:28px}
  .verdict .count{font-size:60px}
  .wrap{padding:26px 18px 80px}
  .f .rid{min-width:0}
  .f .tag{margin-left:0}
}
@media print{
  :root{--paper:#fff;--fail-bg:#fff}
  body{font-size:10.5pt}
  .controls,.matrix .lede{display:none}
  .cell{animation:none;opacity:1}
  .cell.s-clean{opacity:.4}
  .f{break-inside:avoid;background:#fff}
  .f .ev{display:block}
  .f.s-clean,.f.s-not_implemented,.f.s-requires_smb,.f.s-not_applicable{display:none}
}
"""

JS = """
(function(){
  // Open on the failures: this report exists for triage, so the default view is
  // whatever needs attention. 'All outcomes' is one click away.
  var boot=document.body.dataset.boot||'all';
  var q='',status=boot;
  function apply(){
    var shown=0;
    document.querySelectorAll('.f').forEach(function(f){
      var ok=(status==='all'||f.dataset.status===status)&&(!q||f.dataset.k.indexOf(q)!==-1);
      f.classList.toggle('hidden',!ok); if(ok)shown++;
    });
    document.querySelectorAll('.sub,.cat').forEach(function(s){
      s.classList.toggle('hidden',!s.querySelector('.f:not(.hidden)'));
    });
    var e=document.getElementById('empty'); if(e)e.classList.toggle('hidden',shown>0);
    var c=document.getElementById('rc');
    if(c)c.textContent=shown+' of '+document.querySelectorAll('.f').length+' shown';
  }
  function reset(){
    status='all';q='';
    var qi=document.getElementById('q'); if(qi)qi.value='';
    var sel=document.getElementById('st'); if(sel)sel.value='all';
    document.querySelectorAll('.chip').forEach(function(c){c.setAttribute('aria-pressed','false');});
  }
  document.addEventListener('input',function(e){
    if(e.target.id==='q'){q=e.target.value.toLowerCase();apply();}
  });
  document.addEventListener('change',function(e){
    if(e.target.id==='st'){
      status=e.target.value;
      document.querySelectorAll('.chip').forEach(function(c){
        c.setAttribute('aria-pressed',String(c.dataset.status===status));});
      apply();
    }
  });
  document.addEventListener('click',function(e){
    var chip=e.target.closest('.chip');
    if(chip){
      var on=chip.getAttribute('aria-pressed')==='true';
      document.querySelectorAll('.chip').forEach(function(c){c.setAttribute('aria-pressed','false');});
      status=on?'all':chip.dataset.status;
      if(!on)chip.setAttribute('aria-pressed','true');
      var sel=document.getElementById('st'); if(sel)sel.value=status;
      apply();return;
    }
    var cell=e.target.closest('.cell');
    if(cell){
      var t=document.getElementById(cell.dataset.rid);
      if(t){reset();apply();t.classList.add('open');
        t.scrollIntoView({block:'center',behavior:'smooth'});
        t.focus({preventScroll:true});}
      return;
    }
    var f=e.target.closest('.f');
    if(f&&!e.target.closest('table'))f.classList.toggle('open');
  });
  document.addEventListener('keydown',function(e){
    if(e.key==='Enter'||e.key===' '){
      var f=e.target.closest('.f');
      if(f){e.preventDefault();f.classList.toggle('open');}
    }
  });
  if(status!=='all'){
    var c0=document.querySelector('.chip[data-status="'+status+'"]');
    if(c0)c0.setAttribute('aria-pressed','true');
    var s0=document.getElementById('st'); if(s0)s0.value=status;
  }
  apply();
})();
"""


def _esc(v):
    return html.escape(str(v))


def _humanize(name: str) -> str:
    """Turn machine identifiers into readable labels.

    Handles CamelCase while keeping acronym runs intact ('ACLCheck' -> 'ACL
    Check') and snake_case, which evidence column keys use
    ('password_age_days' -> 'Password age days').
    """
    if not name or not name[0].isalpha():
        return name
    special = {"dn": "DN", "os": "OS", "ou": "OU", "gpo": "GPO", "sid": "SID",
               "rid": "RID", "dc": "DC", "ca": "CA", "spn": "SPN"}
    if name.lower() in special:
        return special[name.lower()]
    if "_" in name:
        words = " ".join(special.get(w.lower(), w) for w in name.split("_")).strip()
        return words[:1].upper() + words[1:]
    if name.islower():
        return name[:1].upper() + name[1:]
    return re.sub(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", " ", name)


def _ev_cue(f: Finding) -> str:
    """Disclosure affordance. Without this there is no way to tell which findings
    carry supporting rows short of clicking every one."""
    n = len(f.evidence)
    if not n:
        return ""
    return f'<span class="evcue">{n} item{"s" if n != 1 else ""}</span>'


def _evidence_table(f: Finding) -> str:
    if not f.evidence:
        return ""
    rows = f.evidence[:60]
    cols = []
    for r in rows:
        for k in r.keys():
            if k not in cols:
                cols.append(k)
    head = "".join(f"<th>{_esc(_humanize(c))}</th>" for c in cols)
    body = "".join(
        "<tr>" + "".join(f"<td>{_esc(r.get(c, ''))}</td>" for c in cols) + "</tr>"
        for r in rows
    )
    more = (f'<div class="more">{len(f.evidence) - 60} more rows in the XML export.</div>'
            if len(f.evidence) > 60 else "")
    n = len(f.evidence)
    label = f"{n} item{'s' if n != 1 else ''} of evidence"
    return (f'<div class="ev"><div class="evhead">{label}</div>'
            f'<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>{more}</div>')


def build_html(findings: list[Finding], domain: str) -> str:
    counts = {}
    for f in findings:
        counts[f.status] = counts.get(f.status, 0) + 1
    n_fail = counts.get(Status.TRIGGERED, 0)
    total = len(findings)

    grouped: dict[str, dict[str, list[Finding]]] = {}
    for f in findings:
        grouped.setdefault(f.category, {}).setdefault(f.subcategory, []).append(f)

    matrix_rows = []
    for cat in sorted(grouped):
        cells, fails = [], 0
        for sub in sorted(grouped[cat]):
            for f in grouped[cat][sub]:
                if f.status == Status.TRIGGERED:
                    fails += 1
                cells.append(
                    f'<button class="cell s-{f.status.value}" data-rid="rule-{_esc(f.rule_id)}" '
                    f'title="{_esc(f.rule_id)} — {_esc(f.title)} ({STATUS_LABEL[f.status]})" '
                    f'aria-label="{_esc(f.rule_id)}, {STATUS_LABEL[f.status]}"></button>'
                )
        n = len(cells)
        summary = f"{fails} of {n} need attention" if fails else f"all {n} clear"
        matrix_rows.append(
            f'<div class="mrow"><div class="mlabel"><span>{_esc(_humanize(cat))}</span>'
            f'<span class="mcount">{summary}</span></div>'
            f'<div class="cells">{"".join(cells)}</div></div>'
        )

    breakdown = "".join(
        f'<div><span>{STATUS_LABEL[s]}</span><span>{counts[s]}</span></div>'
        for s in STATUS_ORDER if counts.get(s)
    )
    chips = "".join(
        f'<button class="chip" data-status="{s.value}" aria-pressed="false">'
        f'{STATUS_LABEL[s]} {counts[s]}</button>'
        for s in (Status.TRIGGERED, Status.ERROR) if counts.get(s)
    )
    options = "".join(
        f'<option value="{s.value}">{STATUS_LABEL[s]}</option>'
        for s in STATUS_ORDER if counts.get(s)
    )

    sections = []
    for cat in sorted(grouped):
        subs = []
        cat_fail = sum(1 for v in grouped[cat].values() for f in v if f.status == Status.TRIGGERED)
        cat_total = sum(len(v) for v in grouped[cat].values())
        for sub in sorted(grouped[cat]):
            items = sorted(grouped[cat][sub], key=lambda f: STATUS_ORDER.index(f.status))
            body = []
            for f in items:
                key = " ".join([f.rule_id, f.title, f.summary, cat, sub]).lower()
                body.append(
                    f'<article class="f s-{f.status.value}" id="rule-{_esc(f.rule_id)}" tabindex="0" '
                    f'data-status="{f.status.value}" data-k="{_esc(key)}">'
                    f'<div class="top"><span class="rid">{_esc(f.rule_id)}</span>'
                    f'<span class="title">{_esc(f.title)}</span>'
                    f'<span class="tag">{STATUS_LABEL[f.status]}</span>'
                    f'{_ev_cue(f)}</div>'
                    f'<div class="sum">{_esc(f.summary)}</div>{_evidence_table(f)}</article>'
                )
            subs.append(f'<section class="sub"><h3>{_esc(_humanize(sub))}</h3>{"".join(body)}</section>')
        meta = (f"{cat_fail} of {cat_total} rules need attention" if cat_fail
                else f"{cat_total} rules, all clear")
        sections.append(
            f'<section class="cat"><h2>{_esc(_humanize(cat))}</h2>'
            f'<p class="catmeta">{meta}</p>{"".join(subs)}</section>'
        )

    generated = _dt.datetime.utcnow().strftime("%d %B %Y, %H:%M UTC")
    headline = "None" if n_fail == 0 else str(n_fail)
    boot = Status.TRIGGERED.value if n_fail else "all"
    caption = (f"of {total} rules need attention."
               if n_fail else "of the rules that ran flagged anything.")

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AD audit — {_esc(domain)}</title>
<style>{CSS}</style>
</head>
<body data-boot="{boot}">
<div class="wrap">

  <header class="masthead">
    <div>
      <h1>Active Directory audit</h1>
      <p class="domain">{_esc(domain)}</p>
    </div>
    <div class="stamp">
      <b>{generated}</b>
      {total} rules evaluated · read-only enumeration
    </div>
  </header>

  <div class="hero">
    <div class="verdict">
      <div class="count{' zero' if n_fail == 0 else ''}">{headline}</div>
      <p class="caption">{caption}</p>
      <div class="breakdown">{breakdown}</div>
    </div>
    <div class="matrix">
      <h2>Every rule, by outcome</h2>
      <p class="lede">One square per rule in the reference set. Select a square to jump to its finding.</p>
      {"".join(matrix_rows)}
    </div>
  </div>

  <div class="controls">
    <input type="search" id="q" placeholder="Search rules, titles and summaries" aria-label="Search findings">
    <select id="st" aria-label="Filter by outcome"><option value="all">All outcomes</option>{options}</select>
    {chips}
    <span class="resultcount" id="rc"></span>
  </div>

  <div class="empty hidden" id="empty">Nothing matches that filter. Choose “All outcomes” to see every rule.</div>

  {"".join(sections)}

  <footer>
    Findings are evidence only — no risk score is applied here, so severity stays with the reviewer.
    Rules marked “Not implemented” or “Skipped” are recorded gaps rather than silent omissions; run
    <code>python -m adaudit --coverage-only</code> for the full accounting against the reference rule set.
  </footer>
</div>
<script>{JS}</script>
</body>
</html>"""


def write_html(findings, domain: str, path: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(build_html(findings, domain))
