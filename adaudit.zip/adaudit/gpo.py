"""
GPO discovery and SYSVOL file parsing.

A meaningful slice of PingCastle's rules (LLMNR, firewall restrictions,
Defender ASR, Terminal Services hardening, WSUS settings, LAN Manager auth
level, Kerberos armoring, hardened UNC paths, passwords embedded in Group
Policy Preferences) are ultimately GPO *content* checks: the setting lives in
a file inside SYSVOL, not as an LDAP attribute. This module reads that
content read-only over SMB (via impacket) and parses the two file formats
those settings live in:

  * GptTmpl.inf   - an INI-style security template (Local Policies, etc.)
  * Registry.pol  - a small documented binary format for registry-based
                    policy (MS-GPREG)

If impacket / SMB access isn't available, callers get an empty result and
the rules that depend on this module report REQUIRES_SMB rather than a
false "clean" result.
"""
from __future__ import annotations

import configparser
import io
import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

REG_POL_SIGNATURE = b"PReg"


@dataclass
class GPO:
    display_name: str
    gpo_id: str  # e.g. {31B2F340-016D-11D2-945F-00C04FB984F9}
    file_sys_path: str  # \\domain\SysVol\domain\Policies\{GUID}


def list_gpos(ctx) -> List[GPO]:
    """Enumerate GPOs. Cached: ~15 rules call this, and without caching each
    one re-queries the DC for the same list."""
    if "gpo_list" in ctx._cache:
        return ctx._cache["gpo_list"]
    base = f"CN=Policies,CN=System,{ctx.base_dn}"
    entries = ctx.search(
        base, "(objectClass=groupPolicyContainer)",
        attributes=["displayName", "cn", "gPCFileSysPath"],
    )
    gpos = []
    for e in entries:
        try:
            gpos.append(GPO(
                display_name=str(e["displayName"]) if e["displayName"].value else str(e["cn"]),
                gpo_id=str(e["cn"]),
                file_sys_path=str(e["gPCFileSysPath"]),
            ))
        except Exception:
            continue
    ctx._cache["gpo_list"] = gpos
    return gpos


def _get_smb_session(ctx):
    """Return a cached, logged-in SMB session, reconnecting if the cached one
    has gone stale. Previously every single file read opened and tore down a
    fresh SMB session, which on a large domain meant hundreds of needless
    TCP+auth handshakes against the DC."""
    sess = ctx._cache.get("_smb_session")
    if sess is not None:
        try:
            sess.listShares()  # cheap liveness probe
            return sess
        except Exception:
            ctx._cache.pop("_smb_session", None)
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError:
        return None
    try:
        smb = SMBConnection(ctx.smb_target, ctx.smb_target, timeout=10)
        smb.login(ctx.smb_username or "", ctx.smb_password or "", domain=ctx.smb_domain or "")
        ctx._cache["_smb_session"] = smb
        return smb
    except Exception:
        return None


def _smb_read(ctx, unc_relative_path: str) -> Optional[bytes]:
    """Read a file from SYSVOL given a path relative to the SYSVOL share,
    e.g. 'domain.local/Policies/{GUID}/MACHINE/.../GptTmpl.inf'."""
    if not getattr(ctx, "smb_available", False):
        return None
    smb = _get_smb_session(ctx)
    if smb is None:
        return None
    try:
        buf = io.BytesIO()
        smb.getFile("SYSVOL", unc_relative_path, buf.write)
        return buf.getvalue()
    except Exception:
        # A missing file is the normal case for most GPOs (not every GPO
        # defines every policy area), so this is not logged as an error.
        return None


def gpo_relative_path(gpo: GPO, subpath: str) -> str:
    """Turn a gPCFileSysPath UNC into the path-relative-to-SYSVOL-share form
    impacket's getFile wants, then append the requested subpath."""
    # gPCFileSysPath looks like \\domain\SysVol\domain\Policies\{GUID}
    parts = gpo.file_sys_path.strip("\\").split("\\")
    # parts[0]=domain, parts[1]='SysVol', rest is what we want relative to the share
    rel = "/".join(parts[2:])
    return f"{rel}/{subpath}".replace("/", "\\")


def fetch_gpttmpl(ctx, gpo: GPO) -> Optional[Dict[str, Dict[str, str]]]:
    """Read+parse a GPO's security template. Cached per GPO: this is an SMB
    round-trip and roughly 8 rules read the same file, so without caching a
    100-GPO domain does ~800 redundant SMB reads."""
    key = f"gpttmpl:{gpo.gpo_id}"
    if key in ctx._cache:
        return ctx._cache[key]
    raw = _smb_read(ctx, gpo_relative_path(gpo, r"MACHINE\Microsoft\Windows NT\SecEdit\GptTmpl.inf"))
    result = None if raw is None else parse_gpttmpl(raw)
    ctx._cache[key] = result
    return result


def parse_gpttmpl(raw: bytes) -> Dict[str, Dict[str, str]]:
    text = raw.decode("utf-16-le", errors="ignore")
    if not text.strip():
        text = raw.decode("utf-8", errors="ignore")
    parser = configparser.ConfigParser(strict=False, delimiters=("=",))
    parser.optionxform = str
    try:
        parser.read_string(text)
    except configparser.Error:
        return {}
    return {section: dict(parser.items(section)) for section in parser.sections()}


def fetch_registry_pol(ctx, gpo: GPO, scope: str = "MACHINE") -> List[Tuple[str, str, int, object]]:
    """Read+parse a GPO's Registry.pol. Cached per (GPO, scope) for the same
    reason as fetch_gpttmpl -- roughly a dozen rules read this same file."""
    key = f"regpol:{gpo.gpo_id}:{scope}"
    if key in ctx._cache:
        return ctx._cache[key]
    raw = _smb_read(ctx, gpo_relative_path(gpo, f"{scope}\\Registry.pol"))
    result = [] if raw is None else parse_registry_pol(raw)
    ctx._cache[key] = result
    return result


def parse_registry_pol(data: bytes) -> List[Tuple[str, str, int, object]]:
    """Parse the MS-GPREG Registry.pol format into (key, value_name, type, data) tuples.

    Format: 'PReg' signature (4 bytes), version (4 bytes LE), then repeated
    entries of the form: '[' key ';' value ';' type ';' size ';' data ']'
    where each field (except the brackets/semicolons) is a null-terminated
    UTF-16LE string, and type/size are UTF-16LE-encoded decimal numbers.
    """
    results: List[Tuple[str, str, int, object]] = []
    if len(data) < 8 or data[0:4] != REG_POL_SIGNATURE:
        return results
    pos = 8
    text = data[pos:].decode("utf-16-le", errors="ignore")
    # Entries are bracket-delimited; split naively on '][' boundaries.
    entries = text.strip("\ufeff\x00").split("[")
    for entry in entries:
        entry = entry.rstrip("]\x00")
        if not entry:
            continue
        fields = entry.split(";")
        if len(fields) < 5:
            continue
        key, value_name, type_str, size_str = fields[0], fields[1], fields[2], fields[3]
        value_data_raw = ";".join(fields[4:])
        try:
            reg_type = int(type_str)
        except ValueError:
            reg_type = -1
        # REG_DWORD (4): numeric; REG_SZ (1)/EXPAND_SZ(2): string; others: raw
        if reg_type == 4:
            try:
                parsed_value = int.from_bytes(
                    value_data_raw.encode("utf-16-le", errors="ignore")[:4].ljust(4, b"\x00"),
                    "little",
                )
            except Exception:
                parsed_value = value_data_raw
        else:
            parsed_value = value_data_raw.rstrip("\x00")
        results.append((key.strip("\x00"), value_name.strip("\x00"), reg_type, parsed_value))
    return results


def find_reg_value(entries: List[Tuple[str, str, int, object]], key_suffix: str, value_name: str):
    key_suffix_l = key_suffix.lower()
    value_name_l = value_name.lower()
    for key, vname, _type, data in entries:
        if key.lower().endswith(key_suffix_l) and vname.lower() == value_name_l:
            return data
    return None
