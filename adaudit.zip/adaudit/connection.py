"""
Connection layer: establishes a read-only LDAP bind against a Domain
Controller and discovers the handful of well-known locations (base DN,
Configuration/Schema naming contexts, domain SID, DC list) that most rules
need. Never issues an LDAP write, modify, or delete.

Works from a non-domain-joined host: authentication is passed explicitly on
each bind (simple/NTLM with a password, or SASL GSSAPI if a Kerberos ticket
is already available via a configured krb5 ccache), the same way BloodHound
and PingCastle's own collectors work.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ldap3 import ALL, BASE, Connection, Server, SUBTREE, NTLM, SASL, KERBEROS
from ldap3.protocol.microsoft import security_descriptor_control

from .utils import bin_sid_to_str

log = logging.getLogger("adaudit")

# A paged search over every user or computer in a large domain routinely takes
# longer than half a minute. An earlier revision set this to 30s, which meant the
# first big query killed the socket and every later rule failed with
# "socket is not open". Generous by default, tunable via --timeout.
DEFAULT_TIMEOUT = 300
# Smaller pages return sooner, so a slow DC is far less likely to trip the
# receive timeout on any single round trip.
DEFAULT_PAGE_SIZE = 500

SD_FLAGS_OWNER_GROUP_DACL = 0x07  # OWNER | GROUP | DACL (no SACL - we don't need/request audit ACEs)


def _paged_cookie(result):
    """Extract the paged-results cookie from an ldap3 result, defensively.

    dict.get(key, default) returns the default only when the key is ABSENT. ldap3
    sets result['controls'] to None when the server returned no controls -- which
    AD does for BASE-scope searches and for result sets that fit one page -- so a
    chained .get() walks into None and raises AttributeError. That single line was
    aborting a large share of the rules on a real domain while passing every test
    against the mock, which never populates `result`.
    """
    if not isinstance(result, dict):
        return None
    controls = result.get("controls") or {}
    if not isinstance(controls, dict):
        return None
    paged = controls.get("1.2.840.113556.1.4.319") or {}
    if not isinstance(paged, dict):
        return None
    value = paged.get("value") or {}
    if not isinstance(value, dict):
        return None
    return value.get("cookie")


@dataclass
class ADContext:
    conn: Connection
    server: Server
    domain: str
    base_dn: str
    config_nc: str
    schema_nc: str
    domain_sid: Optional[str] = None
    dc_hostnames: List[str] = field(default_factory=list)
    smb_available: bool = False
    smb_target: Optional[str] = None
    smb_username: Optional[str] = None
    smb_password: Optional[str] = None
    smb_domain: Optional[str] = None
    # Retained so a dropped connection can be rebuilt mid-run (see reconnect()).
    _bind: Dict[str, object] = field(default_factory=dict)
    _reconnects: int = 0
    _cache: Dict[str, object] = field(default_factory=dict)

    def reconnect(self) -> bool:
        """Re-establish the LDAP bind after the socket has dropped.

        A single slow search that exceeds the receive timeout closes the socket,
        and without this every following rule fails with "socket is not open" --
        one timeout cascading into a run-wide failure. Rebinding keeps that
        contained to the rule that actually timed out.
        """
        b = self._bind
        if not b:
            return False
        try:
            try:
                self.conn.unbind()
            except Exception:
                pass
            if b.get("use_kerberos"):
                conn = Connection(self.server, authentication=SASL, sasl_mechanism=KERBEROS,
                                   auto_bind=True, auto_referrals=False,
                                   receive_timeout=b.get("timeout", DEFAULT_TIMEOUT))
            else:
                conn = Connection(self.server, user=b.get("user"), password=b.get("password"),
                                   authentication=NTLM, auto_bind=True, auto_referrals=False,
                                   receive_timeout=b.get("timeout", DEFAULT_TIMEOUT))
            self.conn = conn
            self._reconnects += 1
            log.warning("LDAP connection dropped; rebound (reconnect #%d)", self._reconnects)
            return True
        except Exception as exc:
            log.error("LDAP reconnect failed: %s", exc)
            return False

    # -- convenience search wrapper -----------------------------------
    def search(self, base, filt, attributes=None, scope=SUBTREE, controls=None, paged_size=None):
        """Run a paged LDAP search and return the entries found.

        Tolerates a dropped connection: if the socket has closed (typically
        because an earlier search exceeded the receive timeout) this rebinds once
        and retries, rather than letting one timeout fail every later rule.
        """
        attributes = attributes or ["*"]
        paged_size = paged_size or self._bind.get("page_size", DEFAULT_PAGE_SIZE)
        for attempt in (1, 2):
            entries = []
            cookie = True
            try:
                while cookie:
                    self.conn.search(
                        search_base=base, search_filter=filt, search_scope=scope,
                        attributes=attributes, controls=controls, paged_size=paged_size,
                        paged_cookie=cookie if cookie is not True else None,
                    )
                    entries.extend(self.conn.entries)
                    cookie = _paged_cookie(self.conn.result)
                    if not cookie:
                        break
                return entries
            except Exception as exc:
                dead = any(s in str(exc).lower() for s in
                           ("socket is not open", "socket", "timed out", "connection"))
                if attempt == 1 and dead and self.reconnect():
                    continue          # rebound: try this search once more
                raise
        return []

    def search_with_sd(self, base, filt, attributes=None, scope=SUBTREE):
        """Search including the nTSecurityDescriptor attribute via the
        SD_FLAGS control (needed because it's not returned by default).

        NOTE: pass scope=BASE when reading the ACL of one specific object --
        the default SUBTREE would otherwise pull that object's entire subtree
        and `entries[0]` would not reliably be the object you asked for.
        """
        attrs = list(attributes or [])
        if "nTSecurityDescriptor" not in attrs:
            attrs.append("nTSecurityDescriptor")
        control = security_descriptor_control(sdflags=SD_FLAGS_OWNER_GROUP_DACL)
        return self.search(base, filt, attributes=attrs, controls=[control], scope=scope)

    def get_raw_sd_bytes(self, entry) -> Optional[bytes]:
        try:
            raw = entry["nTSecurityDescriptor"].raw_values
            return raw[0] if raw else None
        except Exception:
            return None


def domain_to_base_dn(domain: str) -> str:
    return ",".join(f"DC={part}" for part in domain.split("."))


def connect(
    domain: str,
    dc_ip: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    use_kerberos: bool = False,
    use_ssl: bool = False,
    base_dn_override: Optional[str] = None,
    timeout: int = DEFAULT_TIMEOUT,
    page_size: int = DEFAULT_PAGE_SIZE,
) -> ADContext:
    target = dc_ip or domain
    # get_info MUST include the schema. ldap3 picks its attribute value formatters
    # from the schema definition: with no schema loaded, find_attribute_helpers()
    # returns (None, None) and every value comes back as raw bytes -- so
    # str(entry["sAMAccountName"]) yields "b\'jdoe\'", objectSid is never rendered
    # as S-1-5-..., and whenCreated never becomes a datetime. An earlier revision
    # set this to DSA to avoid the schema download; that traded a slow start for
    # silently corrupt values across the whole run.
    server = Server(target, use_ssl=use_ssl, get_info=ALL, port=636 if use_ssl else 389)

    if use_kerberos:
        conn = Connection(server, authentication=SASL, sasl_mechanism=KERBEROS,
                          auto_bind=True, auto_referrals=False, receive_timeout=timeout)
    else:
        user = username if not username or "\\" in username or "@" in username else f"{domain}\\{username}"
        conn = Connection(
            server, user=user, password=password, authentication=NTLM,
            auto_bind=True, auto_referrals=False, receive_timeout=timeout,
        )

    base_dn = base_dn_override or (str(server.info.other.get("defaultNamingContext", [""])[0])
                                    if server.info and server.info.other.get("defaultNamingContext")
                                    else domain_to_base_dn(domain))
    config_nc = (str(server.info.other.get("configurationNamingContext", [""])[0])
                 if server.info and server.info.other.get("configurationNamingContext")
                 else f"CN=Configuration,{base_dn}")
    schema_nc = (str(server.info.other.get("schemaNamingContext", [""])[0])
                 if server.info and server.info.other.get("schemaNamingContext")
                 else f"CN=Schema,{config_nc}")

    ctx = ADContext(conn=conn, server=server, domain=domain, base_dn=base_dn,
                     config_nc=config_nc, schema_nc=schema_nc)
    ctx._bind = {"user": (username if not username or "\\" in username or "@" in username
                          else f"{domain}\\{username}"),
                 "password": password, "use_kerberos": use_kerberos,
                 "timeout": timeout, "page_size": page_size}

    # Domain SID: read from the domain root object's objectSid
    conn.search(base_dn, "(objectClass=*)", search_scope=BASE, attributes=["objectSid"])
    if conn.entries:
        raw = conn.entries[0]["objectSid"].raw_values
        if raw:
            ctx.domain_sid = bin_sid_to_str(raw[0])

    # DC list: computer objects with the Domain Controllers primary group
    # Use the paged wrapper: a bare conn.search() silently truncates at the
    # server-side page limit (1000 by default).
    dc_entries = ctx.search(base_dn, "(&(objectCategory=computer)(primaryGroupID=516))",
                             attributes=["dNSHostName"])
    ctx.dc_hostnames = [str(e["dNSHostName"]) for e in dc_entries
                        if "dNSHostName" in e and e["dNSHostName"].value]

    ctx.smb_username = username
    ctx.smb_password = password
    ctx.smb_domain = domain
    ctx.smb_target = dc_ip or (ctx.dc_hostnames[0] if ctx.dc_hostnames else domain)

    return ctx


def try_enable_smb(ctx: ADContext) -> bool:
    """Best-effort: confirm impacket is importable and the target SMB port is
    reachable with the supplied credentials. Sets ctx.smb_available.
    Never required for the LDAP-only rules; only gates the small subset of
    rules that read SYSVOL or observe SMB protocol negotiation."""
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError:
        log.warning("impacket not installed - SMB/SYSVOL-dependent rules will be skipped")
        ctx.smb_available = False
        return False

    try:
        smb = SMBConnection(ctx.smb_target, ctx.smb_target, timeout=5)
        smb.login(ctx.smb_username or "", ctx.smb_password or "", domain=ctx.smb_domain or "")
        smb.close()
        ctx.smb_available = True
    except Exception as exc:
        log.warning("SMB connectivity check failed (%s) - SMB-dependent rules will be skipped", exc)
        ctx.smb_available = False
    return ctx.smb_available
