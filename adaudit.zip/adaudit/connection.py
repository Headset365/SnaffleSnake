"""
Connection layer: establishes a read-only LDAP bind against a Domain
Controller and discovers the handful of well-known locations (base DN,
Configuration/Schema naming contexts, domain SID, DC list) that most rules
need. Never issues an LDAP write, modify, or delete.

Works from a non-domain-joined host: authentication is passed explicitly on
each bind (simple/NTLM with a password, or SASL GSSAPI if a Kerberos ticket
is already available via a configured krb5 ccache), the same way BloodHound
and PingCastle's own collectors work.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ldap3 import DSA, BASE, Connection, Server, SUBTREE, NTLM, SASL, KERBEROS
from ldap3.protocol.microsoft import security_descriptor_control

from .utils import bin_sid_to_str

log = logging.getLogger("adaudit")

SD_FLAGS_OWNER_GROUP_DACL = 0x07  # OWNER | GROUP | DACL (no SACL - we don't need/request audit ACEs)


@dataclass
class ADContext:
    conn: Connection
    server: Server
    domain: str
    base_dn: str
    config_nc: str
    schema_nc: str
    domain_sid: Optional[str] = None
    dc_hostnames: List[str] = field(default_factory=list)
    smb_available: bool = False
    smb_target: Optional[str] = None
    smb_username: Optional[str] = None
    smb_password: Optional[str] = None
    smb_domain: Optional[str] = None
    _cache: Dict[str, object] = field(default_factory=dict)

    # -- convenience search wrapper -----------------------------------
    def search(self, base, filt, attributes=None, scope=SUBTREE, controls=None, paged_size=1000):
        """Run a paged LDAP search and return the list of entries found."""
        attributes = attributes or ["*"]
        entries = []
        cookie = True
        while cookie:
            self.conn.search(
                search_base=base,
                search_filter=filt,
                search_scope=scope,
                attributes=attributes,
                controls=controls,
                paged_size=paged_size,
                paged_cookie=cookie if cookie is not True else None,
            )
            entries.extend(self.conn.entries)
            cookie = self.conn.result.get("controls", {}).get(
                "1.2.840.113556.1.4.319", {}
            ).get("value", {}).get("cookie")
            if not cookie:
                break
        return entries

    def search_with_sd(self, base, filt, attributes=None, scope=SUBTREE):
        """Search including the nTSecurityDescriptor attribute via the
        SD_FLAGS control (needed because it's not returned by default).

        NOTE: pass scope=BASE when reading the ACL of one specific object --
        the default SUBTREE would otherwise pull that object's entire subtree
        and `entries[0]` would not reliably be the object you asked for.
        """
        attrs = list(attributes or [])
        if "nTSecurityDescriptor" not in attrs:
            attrs.append("nTSecurityDescriptor")
        control = security_descriptor_control(sdflags=SD_FLAGS_OWNER_GROUP_DACL)
        return self.search(base, filt, attributes=attrs, controls=[control], scope=scope)

    def get_raw_sd_bytes(self, entry) -> Optional[bytes]:
        try:
            raw = entry["nTSecurityDescriptor"].raw_values
            return raw[0] if raw else None
        except Exception:
            return None


def domain_to_base_dn(domain: str) -> str:
    return ",".join(f"DC={part}" for part in domain.split("."))


def connect(
    domain: str,
    dc_ip: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    use_kerberos: bool = False,
    use_ssl: bool = False,
    base_dn_override: Optional[str] = None,
) -> ADContext:
    target = dc_ip or domain
    # get_info=DSA fetches RootDSE only. get_info=ALL would additionally download the
    # entire AD schema (large, slow) which this tool never reads.
    server = Server(target, use_ssl=use_ssl, get_info=DSA, port=636 if use_ssl else 389)

    if use_kerberos:
        conn = Connection(server, authentication=SASL, sasl_mechanism=KERBEROS,
                          auto_bind=True, auto_referrals=False, receive_timeout=30)
    else:
        user = username if not username or "\\" in username or "@" in username else f"{domain}\\{username}"
        conn = Connection(
            server, user=user, password=password, authentication=NTLM,
            auto_bind=True, auto_referrals=False, receive_timeout=30,
        )

    base_dn = base_dn_override or (str(server.info.other.get("defaultNamingContext", [""])[0])
                                    if server.info and server.info.other.get("defaultNamingContext")
                                    else domain_to_base_dn(domain))
    config_nc = (str(server.info.other.get("configurationNamingContext", [""])[0])
                 if server.info and server.info.other.get("configurationNamingContext")
                 else f"CN=Configuration,{base_dn}")
    schema_nc = (str(server.info.other.get("schemaNamingContext", [""])[0])
                 if server.info and server.info.other.get("schemaNamingContext")
                 else f"CN=Schema,{config_nc}")

    ctx = ADContext(conn=conn, server=server, domain=domain, base_dn=base_dn,
                     config_nc=config_nc, schema_nc=schema_nc)

    # Domain SID: read from the domain root object's objectSid
    conn.search(base_dn, "(objectClass=*)", search_scope=BASE, attributes=["objectSid"])
    if conn.entries:
        raw = conn.entries[0]["objectSid"].raw_values
        if raw:
            ctx.domain_sid = bin_sid_to_str(raw[0])

    # DC list: computer objects with the Domain Controllers primary group
    # Use the paged wrapper: a bare conn.search() silently truncates at the
    # server-side page limit (1000 by default).
    dc_entries = ctx.search(base_dn, "(&(objectCategory=computer)(primaryGroupID=516))",
                             attributes=["dNSHostName"])
    ctx.dc_hostnames = [str(e["dNSHostName"]) for e in dc_entries
                        if "dNSHostName" in e and e["dNSHostName"].value]

    ctx.smb_username = username
    ctx.smb_password = password
    ctx.smb_domain = domain
    ctx.smb_target = dc_ip or (ctx.dc_hostnames[0] if ctx.dc_hostnames else domain)

    return ctx


def try_enable_smb(ctx: ADContext) -> bool:
    """Best-effort: confirm impacket is importable and the target SMB port is
    reachable with the supplied credentials. Sets ctx.smb_available.
    Never required for the LDAP-only rules; only gates the small subset of
    rules that read SYSVOL or observe SMB protocol negotiation."""
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError:
        log.warning("impacket not installed - SMB/SYSVOL-dependent rules will be skipped")
        ctx.smb_available = False
        return False

    try:
        smb = SMBConnection(ctx.smb_target, ctx.smb_target, timeout=5)
        smb.login(ctx.smb_username or "", ctx.smb_password or "", domain=ctx.smb_domain or "")
        smb.close()
        ctx.smb_available = True
    except Exception as exc:
        log.warning("SMB connectivity check failed (%s) - SMB-dependent rules will be skipped", exc)
        ctx.smb_available = False
    return ctx.smb_available
