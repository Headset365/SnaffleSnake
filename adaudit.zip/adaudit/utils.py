"""
Small, dependency-free helper functions shared by rule implementations:
Windows FILETIME <-> datetime conversion, userAccountControl bit tests,
and binary SID <-> string formatting.
"""
from __future__ import annotations

import struct
import datetime as _dt
from typing import Optional

from .constants import FILETIME_EPOCH_DIFF


def filetime_to_datetime(value) -> Optional[_dt.datetime]:
    """Convert an AD FILETIME (as int, str, or bytes) to a UTC datetime.

    Returns None for the sentinel values 0 and 0x7FFFFFFFFFFFFFFF (which mean
    "never" for attributes like accountExpires).
    """
    if value is None:
        return None
    try:
        ivalue = int(value)
    except (TypeError, ValueError):
        return None
    if ivalue in (0, 0x7FFFFFFFFFFFFFFF):
        return None
    try:
        unix_ts = (ivalue - FILETIME_EPOCH_DIFF) / 10_000_000
        return _dt.datetime.utcfromtimestamp(unix_ts)
    except (OverflowError, OSError, ValueError):
        return None


def days_since(dt) -> Optional[int]:
    """Whole days between `dt` and now (UTC).

    Accepts both naive datetimes (as produced by filetime_to_datetime) and
    timezone-aware ones (as ldap3 returns for generalized-time attributes such
    as whenCreated/whenChanged). Mixing the two previously raised a TypeError
    that a rule's broad except swallowed, silently disabling the check.
    """
    if dt is None:
        return None
    if not hasattr(dt, "year"):
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone(_dt.timezone.utc).replace(tzinfo=None)
    return (_dt.datetime.utcnow() - dt).days


def has_uac_flag(uac_value, flag: int) -> bool:
    try:
        return (int(uac_value) & flag) == flag
    except (TypeError, ValueError):
        return False


def _decode(value):
    """Coerce a raw bytes attribute value to str.

    ldap3 returns bytes for any attribute it has no formatter for. Left
    unconverted, str() renders them as "b\'jdoe\'" -- valid-looking output that
    is quietly wrong everywhere it lands, including in the report.
    """
    if isinstance(value, (bytes, bytearray)):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value  # genuinely binary (e.g. a raw descriptor); leave alone
    return value


def to_int(value, default=None):
    """Best-effort int conversion across the shapes AD values arrive in."""
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, (bytes, bytearray)):
        try:
            value = value.decode("utf-8")
        except UnicodeDecodeError:
            return default
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return default


def get_attr(entry, name, default=None):
    """Safely read a single-value ldap3 attribute, returning `default` if
    absent/empty. Works whether ldap3 gave us a list-like Attribute or the
    attribute is simply missing from the returned entry."""
    try:
        val = entry[name]
    except Exception:
        return default
    if val is None:
        return default
    values = val.values if hasattr(val, "values") else val
    if not values:
        return default
    out = values[0] if isinstance(values, (list, tuple)) else values
    return _decode(out)


def get_attr_list(entry, name):
    try:
        val = entry[name]
    except Exception:
        return []
    if val is None:
        return []
    values = val.values if hasattr(val, "values") else val
    if values is None:
        return []
    if isinstance(values, (list, tuple)):
        return [_decode(v) for v in values]
    return [_decode(values)]


def sid_to_rid(sid_str: Optional[str]) -> Optional[int]:
    if not sid_str or "-" not in sid_str:
        return None
    try:
        return int(sid_str.rsplit("-", 1)[-1])
    except ValueError:
        return None


def bin_sid_to_str(data: bytes) -> str:
    """Parse a binary SID into S-R-I-S... string form.

    Returns "" for input that is too short or that declares more
    sub-authorities than the buffer actually contains, rather than raising --
    callers treat "" as "unparseable" and count it, so a malformed SID never
    silently becomes a benign-looking result.
    """
    if not data or len(data) < 8:
        return ""
    revision = data[0]
    sub_auth_count = data[1]
    if len(data) < 8 + (sub_auth_count * 4):
        return ""  # truncated / malformed - do not guess
    identifier_authority = int.from_bytes(data[2:8], "big")
    sub_authorities = []
    offset = 8
    for _ in range(sub_auth_count):
        sub_authorities.append(struct.unpack_from("<I", data, offset)[0])
        offset += 4
    if not sub_authorities:
        return f"S-{revision}-{identifier_authority}"
    return "S-{}-{}-{}".format(
        revision, identifier_authority, "-".join(str(s) for s in sub_authorities)
    )


def guid_bin_to_str(data: bytes) -> str:
    """Convert a binary GUID (as stored in objectGUID / ObjectType in ACEs) to
    the standard mixed-endian string form used by Microsoft tooling."""
    if not data or len(data) != 16:
        return ""
    d1 = struct.unpack_from("<I", data, 0)[0]
    d2, d3 = struct.unpack_from("<HH", data, 4)
    d4 = data[8:16]
    return "{:08x}-{:04x}-{:04x}-{}-{}".format(
        d1, d2, d3, d4[:2].hex(), d4[2:].hex()
    )
