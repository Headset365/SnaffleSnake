"""Read-only Active Directory security auditor (PingCastle-style enumeration)."""
__version__ = "1.0.0"
