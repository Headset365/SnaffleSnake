"""
Command-line entry point.

Usage:
    python -m adaudit -d corp.local -dc dc01.corp.local -u auditor -p 'Password123!' -o report

    # Kerberos ticket (kinit first, or set KRB5CCNAME)
    python -m adaudit -d corp.local -dc dc01.corp.local -u auditor -k -o report

    # Enable the SMB/SYSVOL-dependent rules (GPO parsing, null session, SMB signing, etc.)
    python -m adaudit -d corp.local -dc dc01.corp.local -u auditor -p '...' --smb -o report

    # Just print coverage against the full PingCastle reference rule set, no AD connection needed
    python -m adaudit --coverage-only
"""
from __future__ import annotations

import argparse
import getpass
import logging
import sys

from . import connection
from .coverage import print_coverage_report
from .models import run_all
from .reporting import write_html, write_xml


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="adaudit", description="Read-only Active Directory security auditor "
                                                              "(PingCastle-style enumeration).")
    p.add_argument("-d", "--domain", help="DNS domain name, e.g. corp.local")
    p.add_argument("-dc", "--dc-ip", help="Domain Controller IP or hostname (defaults to --domain via DNS)")
    p.add_argument("-u", "--username", help="Username (with or without DOMAIN\\ prefix)")
    p.add_argument("-p", "--password", help="Password (omit to be prompted; ignored with --kerberos)")
    p.add_argument("-k", "--kerberos", action="store_true", help="Use an existing Kerberos ticket (SASL GSSAPI) "
                                                                  "instead of a password")
    p.add_argument("--ssl", action="store_true", help="Use LDAPS (port 636) instead of plain LDAP (389)")
    p.add_argument("--smb", action="store_true", help="Also attempt SMB connectivity for the subset of rules "
                                                        "that read SYSVOL/GPOs or observe SMB behaviour "
                                                        "(requires impacket)")
    p.add_argument("--base-dn", help="Override the discovered base DN")
    p.add_argument("-o", "--output", default="adaudit_report", help="Output file prefix (writes <prefix>.xml "
                                                                     "and <prefix>.html)")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("--coverage-only", action="store_true",
                    help="Print coverage against the bundled PingCastle reference rule list and exit "
                         "(no AD connection needed)")
    return p


def _cleanup(ctx):
    """Tear down the LDAP bind and any pooled SMB session. Without this the
    process could exit holding an open bind and a cached SMB connection."""
    try:
        if getattr(ctx, "conn", None) is not None and ctx.conn.bound:
            ctx.conn.unbind()
    except Exception:
        pass
    try:
        sess = ctx._cache.pop("_smb_session", None)
        if sess is not None:
            sess.close()
    except Exception:
        pass


def main(argv=None):
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING,
                         format="%(levelname)s %(name)s: %(message)s")

    if args.coverage_only:
        print_coverage_report()
        return 0

    if not args.domain:
        print("error: --domain is required unless --coverage-only is given", file=sys.stderr)
        return 2

    password = args.password
    if not args.kerberos and password is None:
        password = getpass.getpass(f"Password for {args.username}@{args.domain}: ")

    print(f"Connecting to {args.domain} ({args.dc_ip or 'via DNS'})...", file=sys.stderr)
    try:
        ctx = connection.connect(
            domain=args.domain, dc_ip=args.dc_ip, username=args.username, password=password,
            use_kerberos=args.kerberos, use_ssl=args.ssl, base_dn_override=args.base_dn,
        )
    except Exception as exc:
        # A bind failure is by far the most common first-run problem (bad creds,
        # unreachable DC, LDAPS required). Show something actionable rather than
        # a raw traceback.
        print(f"\nERROR: could not bind to the domain: {exc}", file=sys.stderr)
        print("Check: credentials, that the DC is reachable on port "
              f"{'636' if args.ssl else '389'}, and whether the DC requires LDAPS (--ssl) "
              "or channel binding.", file=sys.stderr)
        return 3
    print(f"Bound. Base DN: {ctx.base_dn}. Domain SID: {ctx.domain_sid}. "
          f"{len(ctx.dc_hostnames)} DC(s) found.", file=sys.stderr)

    if args.smb:
        print("Checking SMB connectivity for SYSVOL/GPO-dependent rules...", file=sys.stderr)
        connection.try_enable_smb(ctx)
        print(f"SMB available: {ctx.smb_available}", file=sys.stderr)

    print("Running rules...", file=sys.stderr)
    try:
        findings = run_all(ctx)
    finally:
        _cleanup(ctx)
    triggered = sum(1 for f in findings if f.status.value == "triggered")
    print(f"Done. {len(findings)} rule(s) evaluated, {triggered} triggered.", file=sys.stderr)

    xml_path = f"{args.output}.xml"
    html_path = f"{args.output}.html"
    write_xml(findings, args.domain, xml_path)
    write_html(findings, args.domain, html_path)
    print(f"Wrote {xml_path}", file=sys.stderr)
    print(f"Wrote {html_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
