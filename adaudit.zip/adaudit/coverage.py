"""
Cross-checks `adaudit.models.REGISTRY` against the bundled reference list of
all 187 PingCastle healthcheck rules (extracted from the PingCastle
open-source repository's rule metadata) and reports exactly which rules are
implemented, stubbed, or entirely missing -- so coverage claims in this tool
are verifiable rather than asserted.
"""
from __future__ import annotations

import json
from importlib import resources
from typing import Dict, List

from . import rules  # noqa: F401 - importing populates the registry
from .models import REGISTRY, Status


def _load_reference() -> List[dict]:
    with resources.files("adaudit").joinpath("pingcastle_reference_rules.json").open("r", encoding="utf-8") as f:
        return json.load(f)


def build_coverage_report() -> Dict:
    reference = _load_reference()
    implemented_ids = {m.rule_id for m in REGISTRY}
    stub_ids = set()
    for m in REGISTRY:
        # A stub is any rule whose func, when introspected, is the closure produced
        # by `not_implemented()`. We detect this via a marker attribute set below.
        if getattr(m.func, "_adaudit_stub", False):
            stub_ids.add(m.rule_id)

    real_implemented = implemented_ids - stub_ids
    missing = [r for r in reference if r["id"] not in implemented_ids]
    stubbed = [r for r in reference if r["id"] in stub_ids]
    covered = [r for r in reference if r["id"] in real_implemented]

    by_category = {}
    for r in reference:
        by_category.setdefault(r["cat"], {"total": 0, "implemented": 0, "stubbed": 0, "missing": 0})
        by_category[r["cat"]]["total"] += 1
        if r["id"] in real_implemented:
            by_category[r["cat"]]["implemented"] += 1
        elif r["id"] in stub_ids:
            by_category[r["cat"]]["stubbed"] += 1
        else:
            by_category[r["cat"]]["missing"] += 1

    return {
        "reference_total": len(reference),
        "implemented_count": len(covered),
        "stubbed_count": len(stubbed),
        "missing_count": len(missing),
        "by_category": by_category,
        "missing_rules": missing,
        "stubbed_rules": stubbed,
        "extra_rules_not_in_reference": sorted(implemented_ids - {r["id"] for r in reference}),
    }


def print_coverage_report():
    report = build_coverage_report()
    total = report["reference_total"]
    print(f"PingCastle reference rule set: {total} rules\n")
    print(f"  Implemented (real logic): {report['implemented_count']}")
    print(f"  Stubbed (documented, not yet implemented): {report['stubbed_count']}")
    print(f"  Missing (not registered at all): {report['missing_count']}\n")
    print("By category:")
    for cat, stats in sorted(report["by_category"].items()):
        print(f"  {cat:20s} implemented={stats['implemented']:3d}  stubbed={stats['stubbed']:3d}  "
              f"missing={stats['missing']:3d}  / total={stats['total']:3d}")
    if report["missing_rules"]:
        print("\nMissing entirely (not even stubbed):")
        for r in report["missing_rules"]:
            print(f"  - {r['id']} ({r['cat']}/{r['subcat']})")


if __name__ == "__main__":
    print_coverage_report()
