"""
Reads the NTFS security descriptor of a file/directory over SMB using a
low-level SMB2 QUERY_INFO call (SMB2_0_INFO_SECURITY). NTFS security
descriptors use the identical MS-DTYP self-relative binary format as AD's
`nTSecurityDescriptor`, so `secdesc.parse_security_descriptor` handles both
without modification -- this module only has to get the bytes.

Read-only: the file is opened with READ_CONTROL access alone (no data read,
no write). This only works against SMB2/3 dialects (impacket's low-level
`queryInfo` lives on the SMB3 protocol object); a target that negotiates
legacy SMB1 will simply fail this call cleanly and the caller treats that as
inconclusive rather than a false "clean".
"""
from __future__ import annotations

from typing import Optional


def get_smb_file_security_descriptor(ctx, share: str, path: str, target: str = None,
                                      is_directory: bool = False) -> Optional[bytes]:
    if not getattr(ctx, "smb_available", False):
        return None
    try:
        from impacket.smbconnection import SMBConnection
        import impacket.smb3structs as s
    except ImportError:
        return None
    host = target or ctx.smb_target
    try:
        smb = SMBConnection(host, host, timeout=10)
        smb.login(ctx.smb_username or "", ctx.smb_password or "", domain=ctx.smb_domain or "")
        tree_id = smb.connectTree(share)
        open_kwargs = {"desiredAccess": s.READ_CONTROL}
        if is_directory:
            open_kwargs["creationOption"] = s.FILE_DIRECTORY_FILE
        file_id = smb.openFile(tree_id, path, **open_kwargs)
        server = smb.getSMBServer()
        raw = server.queryInfo(
            tree_id, file_id,
            infoType=s.SMB2_0_INFO_SECURITY,
            additionalInformation=(s.OWNER_SECURITY_INFORMATION
                                    | s.GROUP_SECURITY_INFORMATION
                                    | s.DACL_SECURITY_INFORMATION),
        )
        try:
            smb.closeFile(tree_id, file_id)
        except Exception:
            pass
        smb.close()
        return raw
    except Exception:
        return None
