"""
Core data model: `Finding` (the output of one rule run) and a lightweight
registry/decorator so each rule module can self-register without a central
switch statement.
"""
from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


class Status(str, Enum):
    TRIGGERED = "triggered"        # the condition the rule checks for was found
    CLEAN = "clean"                # checked, condition not found
    NOT_APPLICABLE = "not_applicable"  # e.g. rule needs a feature/role not present
    NOT_IMPLEMENTED = "not_implemented"  # rule stubbed out (documented reason)
    REQUIRES_SMB = "requires_smb"  # needs impacket/SMB and it's unavailable
    ERROR = "error"                # rule raised an exception while running


@dataclass
class Finding:
    rule_id: str
    category: str
    subcategory: str
    title: str
    status: Status
    summary: str = ""
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    error: Optional[str] = None
    duration_ms: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "category": self.category,
            "subcategory": self.subcategory,
            "title": self.title,
            "status": self.status.value,
            "summary": self.summary,
            "evidence": self.evidence,
            "error": self.error,
            "duration_ms": self.duration_ms,
        }


@dataclass
class RuleMeta:
    rule_id: str
    category: str
    subcategory: str
    title: str
    requires: tuple  # e.g. ("ldap",) or ("ldap", "smb")
    func: Callable


REGISTRY: List[RuleMeta] = []
_SEEN_IDS = set()


def rule(rule_id: str, category: str, subcategory: str, title: str, requires=("ldap",)):
    """Decorator: register a function as an audit rule.

    The decorated function must accept a single `ctx` (ADContext) argument
    and return a `Finding`.
    """

    def decorator(func: Callable):
        if rule_id in _SEEN_IDS:
            raise ValueError(f"Duplicate rule id registered: {rule_id}")
        _SEEN_IDS.add(rule_id)
        REGISTRY.append(RuleMeta(rule_id, category, subcategory, title, requires, func))
        return func

    return decorator


def not_implemented(rule_id: str, category: str, subcategory: str, title: str, reason: str, requires=("ldap",)):
    """Register a documented stub for a rule that isn't implemented yet.

    This keeps the rule visible in the report/coverage output (status
    NOT_IMPLEMENTED with the reason recorded) instead of silently vanishing,
    which matters for honest coverage reporting against the full PingCastle
    rule set.
    """

    def _stub(ctx):
        return Finding(
            rule_id=rule_id,
            category=category,
            subcategory=subcategory,
            title=title,
            status=Status.NOT_IMPLEMENTED,
            summary=reason,
        )

    _stub._adaudit_stub = True  # marker used by coverage.py to distinguish stubs from real rules

    if rule_id in _SEEN_IDS:
        raise ValueError(f"Duplicate rule id registered: {rule_id}")
    _SEEN_IDS.add(rule_id)
    REGISTRY.append(RuleMeta(rule_id, category, subcategory, title, requires, _stub))


def run_all(ctx) -> List[Finding]:
    """Execute every registered rule against the given context, catching
    exceptions per-rule so one broken/unreachable check doesn't abort the
    whole run."""
    results: List[Finding] = []
    for meta in REGISTRY:
        if "smb" in meta.requires and not getattr(ctx, "smb_available", False):
            results.append(
                Finding(
                    rule_id=meta.rule_id,
                    category=meta.category,
                    subcategory=meta.subcategory,
                    title=meta.title,
                    status=Status.REQUIRES_SMB,
                    summary="Skipped: requires an SMB/SYSVOL connection that was not available "
                            "(impacket not installed, or SYSVOL unreachable). Re-run with --smb.",
                )
            )
            continue
        started = time.monotonic()
        try:
            finding = meta.func(ctx)
            if finding is None:
                finding = Finding(
                    rule_id=meta.rule_id, category=meta.category, subcategory=meta.subcategory,
                    title=meta.title, status=Status.CLEAN,
                )
            finding.duration_ms = int((time.monotonic() - started) * 1000)
            results.append(finding)
        except Exception as exc:  # noqa: BLE001 - we want to keep going regardless
            results.append(
                Finding(
                    rule_id=meta.rule_id,
                    category=meta.category,
                    subcategory=meta.subcategory,
                    title=meta.title,
                    status=Status.ERROR,
                    summary=str(exc),
                    error=traceback.format_exc(limit=3),
                )
            )
    return results
