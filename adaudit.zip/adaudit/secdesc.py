"""
Minimal, dependency-free parser for the self-relative SECURITY_DESCRIPTOR
binary format returned by Active Directory in the `nTSecurityDescriptor`
attribute (MS-DTYP 2.4.6). This is READ-ONLY: it only decodes bytes that were
already retrieved via a normal authenticated LDAP search: there is no code
path here that writes a security descriptor back to the directory.

Reference layout (MS-DTYP 2.4.6 SECURITY_DESCRIPTOR, self-relative form):
    Revision(1) Sbz1(1) Control(2) OffsetOwner(4) OffsetGroup(4)
    OffsetSacl(4) OffsetDacl(4) [OwnerSid] [GroupSid] [Sacl] [Dacl]

ACL header (MS-DTYP 2.4.5): AclRevision(1) Sbz1(1) AclSize(2) AceCount(2) Sbz2(2)
ACE header (MS-DTYP 2.4.4.1): AceType(1) AceFlags(1) AceSize(2)
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .utils import bin_sid_to_str, guid_bin_to_str

ACCESS_ALLOWED_ACE_TYPE = 0x00
ACCESS_DENIED_ACE_TYPE = 0x01
ACCESS_ALLOWED_OBJECT_ACE_TYPE = 0x05
ACCESS_DENIED_OBJECT_ACE_TYPE = 0x06

# ACE flag bits we care about
ACE_FLAG_OBJECT_TYPE_PRESENT = 0x1
ACE_FLAG_INHERITED_OBJECT_TYPE_PRESENT = 0x2
INHERITED_ACE_FLAG = 0x10  # ACE header flag: this ACE was inherited, not set explicitly


@dataclass
class ACE:
    ace_type: int
    flags: int
    mask: int
    trustee_sid: str
    object_type: Optional[str] = None            # GUID string, if present
    inherited_object_type: Optional[str] = None
    is_inherited: bool = False

    @property
    def is_allow(self) -> bool:
        return self.ace_type in (ACCESS_ALLOWED_ACE_TYPE, ACCESS_ALLOWED_OBJECT_ACE_TYPE)


@dataclass
class SecurityDescriptor:
    owner_sid: Optional[str] = None
    group_sid: Optional[str] = None
    dacl: List[ACE] = field(default_factory=list)
    dacl_present: bool = False
    dacl_protected: bool = False  # SE_DACL_PROTECTED control bit (inheritance disabled)
    malformed_ace_count: int = 0  # ACEs that could not be parsed - see _parse_acl
    parse_ok: bool = True         # False if the descriptor itself was unusable


SE_DACL_PRESENT = 0x0004
SE_DACL_PROTECTED = 0x1000


def _parse_acl(data: bytes, offset: int) -> Tuple[List[ACE], int]:
    """Parse a DACL. Returns (aces, malformed_count).

    malformed_count is surfaced to callers so a dropped ACE can never silently
    become a clean audit result -- an ACL we couldn't fully read is reported as
    such rather than assumed benign.
    """
    aces: List[ACE] = []
    malformed = 0
    if offset == 0 or offset + 8 > len(data):
        return aces, malformed
    ace_count = struct.unpack_from("<H", data, offset + 4)[0]
    pos = offset + 8
    for _ in range(ace_count):
        if pos + 4 > len(data):
            malformed += 1
            break
        ace_type, ace_flags, ace_size = struct.unpack_from("<BBH", data, pos)
        if ace_size < 4 or pos + ace_size > len(data):
            # A zero/undersized/overrunning AceSize means we cannot trust the
            # walk any further -- stop rather than loop on the same offset.
            malformed += 1
            break
        ace_body_start = pos + 4
        try:
            if ace_type in (ACCESS_ALLOWED_ACE_TYPE, ACCESS_DENIED_ACE_TYPE):
                mask = struct.unpack_from("<I", data, ace_body_start)[0]
                sid = bin_sid_to_str(data[ace_body_start + 4: pos + ace_size])
                if not sid:
                    malformed += 1
                else:
                    aces.append(ACE(ace_type, ace_flags, mask, sid,
                                    is_inherited=bool(ace_flags & INHERITED_ACE_FLAG)))
            elif ace_type in (ACCESS_ALLOWED_OBJECT_ACE_TYPE, ACCESS_DENIED_OBJECT_ACE_TYPE):
                mask = struct.unpack_from("<I", data, ace_body_start)[0]
                obj_flags = struct.unpack_from("<I", data, ace_body_start + 4)[0]
                cursor = ace_body_start + 8
                object_type = None
                inherited_object_type = None
                if obj_flags & ACE_FLAG_OBJECT_TYPE_PRESENT:
                    object_type = guid_bin_to_str(data[cursor:cursor + 16])
                    cursor += 16
                if obj_flags & ACE_FLAG_INHERITED_OBJECT_TYPE_PRESENT:
                    inherited_object_type = guid_bin_to_str(data[cursor:cursor + 16])
                    cursor += 16
                sid = bin_sid_to_str(data[cursor: pos + ace_size])
                if not sid:
                    malformed += 1
                else:
                    aces.append(
                        ACE(
                            ace_type, ace_flags, mask, sid,
                            object_type=object_type,
                            inherited_object_type=inherited_object_type,
                            is_inherited=bool(ace_flags & INHERITED_ACE_FLAG),
                        )
                    )
            # Callback/audit ACE types carry no additional access grant we act
            # on for these checks and are intentionally skipped (not counted
            # as malformed -- they are well-formed, just not relevant).
        except (struct.error, IndexError):
            malformed += 1
        pos += ace_size
    return aces, malformed


def parse_security_descriptor(data: bytes) -> SecurityDescriptor:
    sd = SecurityDescriptor()
    if not data or len(data) < 20:
        sd.parse_ok = False
        return sd
    control = struct.unpack_from("<H", data, 2)[0]
    off_owner, off_group, off_sacl, off_dacl = struct.unpack_from("<IIII", data, 4)
    if off_owner:
        # owner SID length is variable; find via next struct or just parse to end
        # We slice conservatively using bin_sid_to_str which stops reading once
        # it has consumed sub_auth_count * 4 + 8 bytes internally is not true -
        # so we bound it using declared offsets.
        end = min([o for o in (off_group, off_sacl, off_dacl, len(data)) if o > off_owner] or [len(data)])
        sd.owner_sid = bin_sid_to_str(data[off_owner:end])
    if off_group:
        end = min([o for o in (off_sacl, off_dacl, len(data)) if o > off_group] or [len(data)])
        sd.group_sid = bin_sid_to_str(data[off_group:end])
    sd.dacl_present = bool(control & SE_DACL_PRESENT)
    sd.dacl_protected = bool(control & SE_DACL_PROTECTED)
    if sd.dacl_present and off_dacl:
        sd.dacl, sd.malformed_ace_count = _parse_acl(data, off_dacl)
    return sd
