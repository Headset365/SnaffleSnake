"""
Shared ACL evaluation helpers.

Rules previously hand-rolled "is this ACE dangerous?" inline, which led to
three recurring defects this module exists to fix centrally:

  1. DENY ACEs were parsed but never consulted, so a DACL that grants a right
     and then denies it produced a false positive.
  2. "Is this trustee an expected admin?" matched on RID alone, so a FOREIGN
     domain's Domain Admins (RID 512 under a different domain SID) was
     wrongly treated as expected and skipped -- a false negative on exactly
     the kind of cross-domain finding you'd most want surfaced.
  3. The dangerous-rights mask omitted WRITE_PROP / SELF_WRITE /
     CONTROL_ACCESS, missing the add-member, Shadow-Credentials,
     ForceChangePassword and DCSync attack edges entirely.

Everything here is pure evaluation over already-parsed bytes; nothing here
performs I/O or modifies anything.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .constants import (
    ACCESS_MASK, DANGEROUS_RIGHTS_MASK, DANGEROUS_RIGHTS_MASK_EXTENDED,
    DANGEROUS_WRITE_PROP_GUIDS, DCSYNC_GUIDS, EXTENDED_RIGHTS,
)
from .utils import sid_to_rid

# SIDs that are legitimately privileged regardless of domain
UNIVERSAL_PRIVILEGED_SIDS = {
    "S-1-5-18",        # LOCAL SYSTEM
    "S-1-5-32-544",    # BUILTIN\Administrators
    "S-1-5-9",         # Enterprise Domain Controllers
    "S-1-5-32-548",    # BUILTIN\Account Operators (privileged by design)
    "S-1-5-10",        # SELF
}

# Domain-relative RIDs that are legitimately privileged -- ONLY when the SID
# also belongs to the domain being audited (see is_expected_privileged).
PRIVILEGED_DOMAIN_RIDS = {
    500,  # Administrator
    512,  # Domain Admins
    516,  # Domain Controllers
    518,  # Schema Admins
    519,  # Enterprise Admins
    521,  # Read-only Domain Controllers
}

BROAD_SIDS = {
    "S-1-1-0",   # Everyone
    "S-1-5-11",  # Authenticated Users
    "S-1-5-7",   # Anonymous Logon
    "S-1-5-32-545",  # BUILTIN\Users
}


def is_broad_trustee(sid: str, domain_sid: Optional[str] = None) -> bool:
    """True for 'effectively everyone' principals, including the audited
    domain's own Domain Users (RID 513) and Domain Computers (RID 515)."""
    if sid in BROAD_SIDS:
        return True
    if domain_sid and sid.startswith(domain_sid + "-"):
        return sid_to_rid(sid) in (513, 515)
    return False


def is_expected_privileged(sid: str, domain_sid: Optional[str] = None) -> bool:
    """True if this trustee holding elevated rights is expected/benign.

    Critically, a domain-relative privileged RID only counts when the SID
    actually belongs to the audited domain. A foreign domain's RID-512 group
    is NOT expected and must stay reportable.
    """
    if not sid:
        return False
    if sid in UNIVERSAL_PRIVILEGED_SIDS:
        return True
    if domain_sid and sid.startswith(domain_sid + "-"):
        return sid_to_rid(sid) in PRIVILEGED_DOMAIN_RIDS
    return False


def _ace_matches_mask(ace, mask: int) -> bool:
    return bool(ace.mask & mask)


def effective_dangerous_aces(
    sd,
    domain_sid: Optional[str] = None,
    mask: int = DANGEROUS_RIGHTS_MASK_EXTENDED,
    skip_expected_privileged: bool = True,
    include_inherited: bool = True,
) -> List[Dict]:
    """Return dangerous ALLOW ACEs, with DENY precedence applied.

    Windows evaluates a DACL in order and an explicit DENY that precedes an
    ALLOW for the same trustee/right wins. We approximate that faithfully
    enough for auditing: an ALLOW is suppressed if any DENY ACE earlier in
    the DACL covers the same trustee and overlapping access bits.
    """
    results: List[Dict] = []
    seen_denies: List[Tuple[str, int, Optional[str]]] = []

    for ace in sd.dacl:
        if not ace.is_allow:
            seen_denies.append((ace.trustee_sid, ace.mask, ace.object_type))
            continue
        if not include_inherited and ace.is_inherited:
            continue
        if not _ace_matches_mask(ace, mask):
            continue
        if skip_expected_privileged and is_expected_privileged(ace.trustee_sid, domain_sid):
            continue

        # DENY precedence: suppress if an earlier DENY covers this trustee and
        # overlaps the granted bits (object-scoped denies must match the GUID,
        # or be un-scoped, which covers everything).
        suppressed = False
        for d_sid, d_mask, d_obj in seen_denies:
            if d_sid != ace.trustee_sid:
                continue
            if not (d_mask & ace.mask & mask):
                continue
            if d_obj is None or d_obj == ace.object_type:
                suppressed = True
                break
        if suppressed:
            continue

        results.append(_describe_ace(ace))
    return results


def _describe_ace(ace) -> Dict:
    """Human-readable summary of why an ACE is interesting -- this is what
    lands in the report's evidence table, so it must name the actual right."""
    rights = []
    for name in ("GENERIC_ALL", "GENERIC_WRITE", "WRITE_OWNER", "WRITE_DACL",
                 "WRITE_PROP", "SELF_WRITE", "CONTROL_ACCESS", "CREATE_CHILD"):
        if ace.mask & ACCESS_MASK[name]:
            rights.append(name)

    detail = None
    if ace.object_type:
        guid = ace.object_type.lower()
        if guid in DCSYNC_GUIDS:
            detail = f"DCSync-related extended right ({EXTENDED_RIGHTS.get(guid, guid)})"
        elif guid in EXTENDED_RIGHTS:
            detail = f"extended right: {EXTENDED_RIGHTS[guid]}"
        elif guid in DANGEROUS_WRITE_PROP_GUIDS:
            detail = f"attribute write: {DANGEROUS_WRITE_PROP_GUIDS[guid]}"
        else:
            detail = f"scoped to object/attribute GUID {ace.object_type}"

    return {
        "trustee_sid": ace.trustee_sid,
        "rights": ",".join(rights) or hex(ace.mask),
        "mask": hex(ace.mask),
        "detail": detail or "applies to the whole object",
        "inherited": ace.is_inherited,
    }


def has_dcsync_rights(sd, domain_sid: Optional[str] = None) -> List[Dict]:
    """Trustees holding BOTH DS-Replication-Get-Changes and -Get-Changes-All
    (or GENERIC_ALL), which together permit a DCSync-style replication pull.
    Requiring the pair avoids flagging the many principals that legitimately
    hold only one of them."""
    per_trustee: Dict[str, set] = {}
    generic_all: Dict[str, object] = {}
    for ace in sd.dacl:
        if not ace.is_allow:
            continue
        if is_expected_privileged(ace.trustee_sid, domain_sid):
            continue
        if ace.mask & ACCESS_MASK["GENERIC_ALL"]:
            generic_all[ace.trustee_sid] = ace
        if ace.object_type and ace.object_type.lower() in DCSYNC_GUIDS:
            per_trustee.setdefault(ace.trustee_sid, set()).add(ace.object_type.lower())

    out = []
    for sid, guids in per_trustee.items():
        if guids >= DCSYNC_GUIDS:
            out.append({"trustee_sid": sid, "via": "both DS-Replication-Get-Changes{,-All} extended rights"})
    for sid in generic_all:
        if sid not in {o["trustee_sid"] for o in out}:
            out.append({"trustee_sid": sid, "via": "GENERIC_ALL over the object"})
    return out
