"""
Anomalies / NetworkSniffing subcategory: protocol-negotiation and
network-hardening checks. A few of these (`A-DCLdapSign`, `A-SMB2Signature*`)
observe what a DC actually negotiates rather than reading a config value --
still purely passive (a normal bind/connect), never a relay or MITM attempt.
"""
from __future__ import annotations

from ..models import rule, not_implemented, Finding, Status
from ..secdesc import parse_security_descriptor
from ..utils import get_attr, get_attr_list

CATEGORY = "Anomalies"
SUB = "NetworkSniffing"


@rule("A-DCLdapSign", CATEGORY, SUB, "DC does not require LDAP signing")
def r_dc_ldap_sign(ctx) -> Finding:
    # ctx.conn already completed a successful simple/NTLM bind without a sign/seal
    # requirement (see connection.py) -- if that bind succeeded and returned data,
    # the DC is not enforcing LDAP signing on unsigned binds.
    try:
        ok = ctx.conn.bound and bool(ctx.search(ctx.base_dn, "(objectClass=domainDNS)", attributes=["distinguishedName"]))
    except Exception:
        ok = False
    status = Status.TRIGGERED if ok else Status.CLEAN
    return Finding("A-DCLdapSign", CATEGORY, SUB, "DC does not require LDAP signing", status,
                    "An unsigned LDAP bind completed a successful search, so LDAP signing is not being enforced."
                    if ok else "Unsigned LDAP operations did not succeed as expected (inconclusive).")


@rule("A-LMHashAuthorized", CATEGORY, SUB, "Domain still allows storage of the LM hash", requires=("ldap", "smb"))
def r_lm_hash(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    disabled_somewhere = False
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        val = gpomod.find_reg_value(entries, r"control\lsa", "NoLMHash")
        if val is not None and str(val) == "1":
            disabled_somewhere = True
    status = Status.CLEAN if disabled_somewhere else Status.TRIGGERED
    return Finding("A-LMHashAuthorized", CATEGORY, SUB, "Domain still allows storage of the LM hash", status,
                    "NoLMHash=1 found in at least one GPO." if disabled_somewhere else
                    "No GPO sets NoLMHash; LM hash storage may still be possible on older systems.")


@rule("A-LDAPSigningDisabled", CATEGORY, SUB, "LDAP signing disabled via GPO", requires=("ldap", "smb"))
def r_ldap_signing_disabled(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    out = []
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        # PingCastle inspects LDAPClientIntegrity == 0 (LSA policy), NOT
        # LDAPServerIntegrity. Different setting, different key -- the previous
        # value is the server-side requirement and is configured elsewhere.
        val = gpomod.find_reg_value(entries, r"services\ldap", "LDAPClientIntegrity")
        if val is None:
            tmpl = gpomod.fetch_gpttmpl(ctx, g)
            if tmpl:
                for k, v in tmpl.get("Registry Values", {}).items():
                    if k.lower().endswith("ldapclientintegrity"):
                        val = str(v).split(",")[-1]
        if val is not None and str(val).strip() == "0":
            out.append({"gpo": g.display_name, "LDAPClientIntegrity": val})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-LDAPSigningDisabled", CATEGORY, SUB, "LDAP signing disabled via GPO", status,
                    f"{len(out)} GPO(s) set LDAPClientIntegrity to 0 (no signing requirement).", out)


@rule("A-SMB2SignatureNotEnabled", CATEGORY, SUB, "SMB signing not enabled", requires=("ldap", "smb"))
def r_smb2_sig_not_enabled(ctx) -> Finding:
    return _smb_signing_check(ctx, "A-SMB2SignatureNotEnabled", "SMB signing not enabled", require_signing=False)


@rule("A-SMB2SignatureNotRequired", CATEGORY, SUB, "SMB signing not required", requires=("ldap", "smb"))
def r_smb2_sig_not_required(ctx) -> Finding:
    return _smb_signing_check(ctx, "A-SMB2SignatureNotRequired", "SMB signing not required", require_signing=True)


def _smb_signing_check(ctx, rule_id, title, require_signing):
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError:
        return Finding(rule_id, CATEGORY, SUB, title, Status.REQUIRES_SMB, "impacket not installed.")
    out = []
    for dc in ctx.dc_hostnames:
        try:
            smb = SMBConnection(dc, dc, timeout=5)
            signing_active = smb.isSigningRequired() if hasattr(smb, "isSigningRequired") else None
            smb.close()
            if require_signing and not signing_active:
                out.append({"dc": dc, "signing_required": bool(signing_active)})
            elif not require_signing and signing_active is False:
                out.append({"dc": dc, "signing_active": bool(signing_active)})
        except Exception:
            continue
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding(rule_id, CATEGORY, SUB, title, status, f"{len(out)} DC(s) flagged.", out)


@rule("A-NTFRSOnSysvol", CATEGORY, SUB, "SYSVOL still replicated via legacy FRS instead of DFSR")
def r_ntfrs_sysvol(ctx) -> Finding:
    entries = ctx.search(f"CN=System,{ctx.base_dn}", "(objectClass=nTFRSSubscriptions)", attributes=["cn"])
    dfsr_entries = ctx.search(f"CN=DFSR-GlobalSettings,CN=System,{ctx.base_dn}", "(objectClass=*)",
                               attributes=["cn"])
    using_frs = bool(entries) and not bool(dfsr_entries)
    status = Status.TRIGGERED if using_frs else Status.CLEAN
    return Finding("A-NTFRSOnSysvol", CATEGORY, SUB, "SYSVOL still replicated via legacy FRS instead of DFSR",
                    status, "NTFRS subscription objects found with no DFSR global settings object." if using_frs
                    else "No indication SYSVOL still uses legacy FRS.")


def _dns_zone_dn(ctx, zone_name=None):
    zone_name = zone_name or ctx.domain
    # Modern AD stores app-partition DNS zones under DC=DomainDnsZones,<base>
    return f"DC={zone_name},CN=MicrosoftDNS,DC=DomainDnsZones,{ctx.base_dn}"


@rule("A-DnsZoneAUCreateChild", CATEGORY, SUB, "DNS zone allows Authenticated Users to create child objects")
def r_dns_zone_au_create_child(ctx) -> Finding:
    dn = _dns_zone_dn(ctx)
    entries = ctx.search_with_sd(dn, "(objectClass=*)", attributes=["distinguishedName"], scope="BASE")
    out = []
    if entries:
        raw = ctx.get_raw_sd_bytes(entries[0])
        if raw:
            sd = parse_security_descriptor(raw)
            for ace in sd.dacl:
                if ace.is_allow and ace.trustee_sid == "S-1-5-11" and (ace.mask & 0x1):  # CREATE_CHILD
                    out.append({"trustee_sid": ace.trustee_sid, "mask": hex(ace.mask)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-DnsZoneAUCreateChild", CATEGORY, SUB,
                    "DNS zone allows Authenticated Users to create child objects", status,
                    f"{len(out)} matching ACE(s) on the zone container "
                    "(lets any authenticated user create arbitrary DNS records, e.g. for WPAD abuse).", out)


@rule("A-DCLdapsChannelBinding", CATEGORY, SUB, "LDAP channel binding not enforced via GPO",
      requires=("ldap", "smb"))
def r_dc_ldaps_channel_binding(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    strictest = None  # LdapEnforceChannelBinding: 0=Never, 1=When supported, 2=Always
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        val = gpomod.find_reg_value(entries, r"services\ntds\parameters", "LdapEnforceChannelBinding")
        if val is not None:
            try:
                ival = int(val)
                strictest = ival if strictest is None else max(strictest, ival)
            except (TypeError, ValueError):
                continue
    if strictest is None:
        status = Status.TRIGGERED
        summary = ("No GPO sets LdapEnforceChannelBinding under NTDS\\Parameters; DCs use the platform default, "
                   "which does not require channel binding on LDAPS/LDAP-with-signing binds "
                   "(relevant to the 2020/2021 Microsoft LDAP-relay hardening advisories).")
    else:
        status = Status.CLEAN if strictest >= 2 else Status.TRIGGERED
        summary = f"Strictest configured LdapEnforceChannelBinding = {strictest} (0=Never, 1=When supported, 2=Always)."
    return Finding("A-DCLdapsChannelBinding", CATEGORY, SUB, "LDAP channel binding not enforced via GPO",
                    status, summary)


not_implemented("A-DnsZoneUpdate1", CATEGORY, SUB, "DNS zone allows unsecured dynamic updates (variant 1)",
                 "The update-type setting lives in the zone's binary `dNSProperty` attribute (a packed "
                 "DNS_RPC_ZONE property list), not a simple LDAP attribute; a dedicated binary parser for that "
                 "format was not built in this pass.")
not_implemented("A-DnsZoneUpdate2", CATEGORY, SUB, "DNS zone allows unsecured dynamic updates (variant 2)",
                 "Same dependency as A-DnsZoneUpdate1.")


@rule("A-HardenedPaths", CATEGORY, SUB, "GPO UNC hardened paths not configured for SYSVOL/NETLOGON",
      requires=("ldap", "smb"))
def r_hardened_paths(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    configured = False
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        for key, vname, _t, _d in entries:
            if key.lower().endswith(r"policies\microsoft\windows\netlogon") and "sysvol" in vname.lower():
                configured = True
    status = Status.CLEAN if configured else Status.TRIGGERED
    return Finding("A-HardenedPaths", CATEGORY, SUB,
                    "GPO UNC hardened paths not configured for SYSVOL/NETLOGON", status,
                    "Hardened UNC paths for SYSVOL/NETLOGON found." if configured else
                    "No GPO configures hardened UNC paths for \\\\*\\SYSVOL or \\\\*\\NETLOGON.")


@rule("A-NoGPOLLMNR", CATEGORY, SUB, "No GPO disables LLMNR", requires=("ldap", "smb"))
def r_no_gpo_llmnr(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    disabled = False
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        val = gpomod.find_reg_value(entries, r"policies\microsoft\windows nt\dnsclient", "EnableMulticast")
        if val is not None and str(val) == "0":
            disabled = True
    status = Status.CLEAN if disabled else Status.TRIGGERED
    return Finding("A-NoGPOLLMNR", CATEGORY, SUB, "No GPO disables LLMNR", status,
                    "LLMNR disabled by at least one GPO." if disabled else
                    "No GPO disables LLMNR (EnableMulticast); network open to LLMNR-poisoning credential capture.")
