"""
Stale Objects rules (PingCastle category `S-*`).

All rules here are read-only LDAP searches, plus a handful that read GPO
content from SYSVOL (marked `requires=("ldap", "smb")`) or observe SMB
dialect negotiation. Nothing here writes to AD or to any target host.
"""
from __future__ import annotations

import datetime as _dt
import re

from ..constants import (
    OBSOLETE_OS_PATTERNS, RECOMMENDED_MIN_FUNCTIONAL_LEVEL, FUNCTIONAL_LEVELS,
    ENCTYPE_AES128, ENCTYPE_AES256, ENCTYPE_DES_CBC_CRC, ENCTYPE_DES_CBC_MD5,
    UAC_ACCOUNTDISABLE, UAC_DONT_REQUIRE_PREAUTH, UAC_DONT_EXPIRE_PASSWORD,
    UAC_USE_DES_KEY_ONLY, UAC_ENCRYPTED_TEXT_PWD_ALLOWED,
    UAC_PASSWD_NOTREQD, UAC_SERVER_TRUST_ACCOUNT, UAC_WORKSTATION_TRUST_ACCOUNT,
    UAC_TRUSTED_FOR_DELEGATION, UAC_PARTIAL_SECRETS_ACCOUNT,
    DEFAULT_PRIMARY_GROUP_IDS,
)
from ..models import rule, not_implemented, Finding, Status
from ..utils import (filetime_to_datetime, days_since, has_uac_flag, get_attr, get_attr_list,
                     sid_to_rid, bin_sid_to_str)

CATEGORY = "StaleObjects"

# ---------------------------------------------------------------------------
# Inactive User or Computer
# ---------------------------------------------------------------------------

def _inactive_search(ctx, obj_filter, threshold_days=180):
    filt = f"(&{obj_filter}(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))"
    entries = ctx.search(ctx.base_dn, filt, attributes=["sAMAccountName", "lastLogonTimestamp", "distinguishedName"])
    stale = []
    for e in entries:
        last = filetime_to_datetime(get_attr(e, "lastLogonTimestamp"))
        d = days_since(last)
        if d is None or d >= threshold_days:
            stale.append({"account": str(e["sAMAccountName"]), "days_inactive": d if d is not None else "never logged on"})
    return stale


@rule("S-Inactive", CATEGORY, "InactiveUserOrComputer", "Inactive user accounts")
def r_s_inactive(ctx) -> Finding:
    stale = _inactive_search(ctx, "(&(objectCategory=person)(objectClass=user))")
    total = len(ctx.search(ctx.base_dn, "(&(objectCategory=person)(objectClass=user))",
                            attributes=["sAMAccountName"]))
    # PingCastle scores this as a PERCENTAGE of all user accounts (threshold 25%),
    # not a raw count -- a flat ">=25 accounts" fires on any mid-size domain.
    pct = (len(stale) * 100 / total) if total else 0
    status = Status.TRIGGERED if pct >= 25 else Status.CLEAN
    return Finding("S-Inactive", CATEGORY, "InactiveUserOrComputer", "Inactive user accounts",
                    status, f"{len(stale)} of {total} user account(s) inactive >=180 days ({pct:.1f}%). "
                    "Triggers at 25%.", stale[:200])


@rule("S-C-Inactive", CATEGORY, "InactiveUserOrComputer", "Inactive computer accounts")
def r_s_c_inactive(ctx) -> Finding:
    stale = _inactive_search(ctx, "(objectCategory=computer)")
    total = len(ctx.search(ctx.base_dn, "(objectCategory=computer)", attributes=["sAMAccountName"]))
    # Percentage-based in PingCastle too: thresholds 15/20/30% for escalating severity.
    pct = (len(stale) * 100 / total) if total else 0
    status = Status.TRIGGERED if pct >= 15 else Status.CLEAN
    return Finding("S-C-Inactive", CATEGORY, "InactiveUserOrComputer", "Inactive computer accounts",
                    status, f"{len(stale)} of {total} computer account(s) inactive >=180 days ({pct:.1f}%). "
                    "Triggers at 15% (20%/30% = higher severity).", stale[:200])


@rule("S-DC-Inactive", CATEGORY, "InactiveUserOrComputer", "Inactive Domain Controllers")
def r_s_dc_inactive(ctx) -> Finding:
    stale = _inactive_search(ctx, "(&(objectCategory=computer)(primaryGroupID=516))", threshold_days=45)
    status = Status.TRIGGERED if stale else Status.CLEAN
    return Finding("S-DC-Inactive", CATEGORY, "InactiveUserOrComputer", "Inactive Domain Controllers",
                    status, f"{len(stale)} DC(s) appear inactive.", stale)


def _pwdlastset_search(ctx, obj_filter, min_days, max_days=None):
    entries = ctx.search(ctx.base_dn, f"(&{obj_filter}(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))",
                          attributes=["sAMAccountName", "pwdLastSet", "lastLogonTimestamp"])
    out = []
    for e in entries:
        pls = filetime_to_datetime(get_attr(e, "pwdLastSet"))
        d = days_since(pls)
        if d is None:
            continue
        if d >= min_days and (max_days is None or d < max_days):
            out.append({"account": str(e["sAMAccountName"]), "password_age_days": d})
    return out


@rule("S-PwdLastSet-45", CATEGORY, "InactiveUserOrComputer", "Computer password not changed (45-90 days)")
def r_pwdlastset_45(ctx) -> Finding:
    out = _pwdlastset_search(ctx, "(&(objectCategory=computer)(!(primaryGroupID=516)))", 45, 90)
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-PwdLastSet-45", CATEGORY, "InactiveUserOrComputer",
                    "Computer password not changed (45-90 days)", status,
                    f"{len(out)} computer account(s) with password 45-90 days old.", out[:200])


@rule("S-PwdLastSet-90", CATEGORY, "InactiveUserOrComputer", "Computer password not changed (90+ days)")
def r_pwdlastset_90(ctx) -> Finding:
    out = _pwdlastset_search(ctx, "(&(objectCategory=computer)(!(primaryGroupID=516)))", 90)
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-PwdLastSet-90", CATEGORY, "InactiveUserOrComputer",
                    "Computer password not changed (90+ days)", status,
                    f"{len(out)} computer account(s) with password 90+ days old.", out[:200])


@rule("S-PwdLastSet-DC", CATEGORY, "InactiveUserOrComputer", "DC password not changed (45+ days)")
def r_pwdlastset_dc(ctx) -> Finding:
    out = _pwdlastset_search(ctx, "(&(objectCategory=computer)(primaryGroupID=516))", 45)
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-PwdLastSet-DC", CATEGORY, "InactiveUserOrComputer",
                    "DC password not changed (45+ days)", status,
                    f"{len(out)} DC(s) with password 45+ days old.", out)


@rule("S-PwdLastSet-Cluster", CATEGORY, "InactiveUserOrComputer", "Cluster account password not rotated (3+ years)")
def r_pwdlastset_cluster(ctx) -> Finding:
    # Heuristic matching PingCastle: account created 3+ yrs ago, used within 45
    # days, but password not changed in 3+ years -- suggests a cluster VCO.
    entries = ctx.search(ctx.base_dn, "(&(objectCategory=computer)(!(primaryGroupID=516)))",
                          attributes=["sAMAccountName", "pwdLastSet", "whenCreated", "lastLogonTimestamp"])
    out = []
    for e in entries:
        created = get_attr(e, "whenCreated")
        last = filetime_to_datetime(get_attr(e, "lastLogonTimestamp"))
        pls = filetime_to_datetime(get_attr(e, "pwdLastSet"))
        if not created or not last or not pls:
            continue
        created_days = days_since(created)  # days_since now normalises tz-aware ldap3 datetimes
        last_days = days_since(last)
        pls_days = days_since(pls)
        if (created_days is not None and created_days >= 1095
                and last_days is not None and last_days <= 45
                and pls_days is not None and pls_days >= 1095):
            out.append({"account": str(e["sAMAccountName"]), "password_age_days": pls_days})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-PwdLastSet-Cluster", CATEGORY, "InactiveUserOrComputer",
                    "Cluster account password not rotated (3+ years)", status,
                    f"{len(out)} likely cluster account(s) with 3+ year old password.", out)


# ---------------------------------------------------------------------------
# Network Topography
# ---------------------------------------------------------------------------

@rule("S-DC-SubnetMissing", CATEGORY, "NetworkTopography", "DC IP not covered by a declared AD subnet")
def r_subnet_missing(ctx) -> Finding:
    import ipaddress
    import socket

    subnets = ctx.search(f"CN=Subnets,CN=Sites,{ctx.config_nc}", "(objectClass=subnet)", attributes=["cn"])
    nets = []
    for s in subnets:
        try:
            nets.append(ipaddress.ip_network(str(s["cn"]), strict=False))
        except ValueError:
            continue
    missing = []
    for host in ctx.dc_hostnames:
        try:
            ip = socket.gethostbyname(host)
        except Exception:
            continue
        addr = ipaddress.ip_address(ip)
        if not any(addr in n for n in nets):
            missing.append({"dc": host, "ip": ip})
    status = Status.TRIGGERED if missing else Status.CLEAN
    return Finding("S-DC-SubnetMissing", CATEGORY, "NetworkTopography",
                    "DC IP not covered by a declared AD subnet", status,
                    f"{len(missing)} DC(s) with an IP outside declared subnets.", missing)


@rule("S-FirewallScript", CATEGORY, "NetworkTopography", "No outbound firewall block for script engines",
      requires=("ldap", "smb"))
def r_firewall_script(ctx) -> Finding:
    from .. import gpo as gpomod
    script_engines = ("wscript.exe", "cscript.exe", "mshta.exe", "powershell.exe")
    gpos = gpomod.list_gpos(ctx)
    blocked = set()
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        for key, _vname, _t, data in entries:
            if "windowsfirewall" not in key.lower() or "firewallrules" not in key.lower():
                continue
            rule_str = str(data).lower()
            if "dir=out" in rule_str and "action=block" in rule_str:
                for engine in script_engines:
                    if engine in rule_str:
                        blocked.add(engine)
    missing = [e for e in script_engines if e not in blocked]
    status = Status.TRIGGERED if missing else Status.CLEAN
    return Finding("S-FirewallScript", CATEGORY, "NetworkTopography",
                    "No outbound firewall block for script engines", status,
                    f"Outbound-block firewall rule found for: {sorted(blocked) or 'none'}. "
                    f"Missing for: {missing}. Parses Windows Firewall with Advanced Security rules from "
                    "Registry.pol (WindowsFirewall\\...\\FirewallRules values); older-style basic Windows "
                    "Firewall GPO settings are not checked.", [{"engine": e} for e in missing])

# ---------------------------------------------------------------------------
# Object Configuration
# ---------------------------------------------------------------------------

def _primary_group_check(ctx, is_computer, rule_id, title):
    """primaryGroupID can be used to hide effective group membership.

    The allowed set differs by object type, and both were previously wrong here
    (a single shared set {513,514,515,516,521} was applied to users and
    computers alike):

      USERS     -- 513 (Domain Users) and 514 (Domain Guests) are normal; the
                   built-in Guest account is exempt; 515 is allowed only for
                   (g)MSA objects. Anything else is a finding.
      COMPUTERS -- 515 (Domain Computers) and 514 are normal; 516/521 (RW/RO
                   Domain Controllers) are allowed ONLY for objects actually in
                   the Domain Controllers OU. Anything else is a finding.

    Disabled accounts are excluded, matching PingCastle.
    """
    obj_filter = "(objectCategory=computer)" if is_computer else "(&(objectCategory=person)(objectClass=user))"
    entries = ctx.search(
        ctx.base_dn,
        f"(&{obj_filter}(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))",
        attributes=["sAMAccountName", "primaryGroupID", "distinguishedName", "objectClass", "objectSid"])
    out = []
    for e in entries:
        try:
            pgid = int(get_attr(e, "primaryGroupID"))
        except (TypeError, ValueError):
            continue
        dn = str(get_attr(e, "distinguishedName", ""))
        classes = [str(x).lower() for x in get_attr_list(e, "objectClass")]
        sid = get_attr(e, "objectSid")
        if is_computer:
            ok = pgid in (515, 514)
            if not ok and pgid in (516, 521):
                ok = "ou=domain controllers,dc=" in dn.lower()
        else:
            ok = pgid in (513, 514)
            if not ok and pgid == 515:
                ok = any(k in classes for k in
                         ("msds-groupmanagedserviceaccount", "msds-managedserviceaccount"))
            if not ok and sid is not None and sid_to_rid(str(sid)) == 501:
                ok = True  # built-in Guest account
        if not ok:
            out.append({"account": str(e["sAMAccountName"]), "primaryGroupID": pgid})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding(rule_id, CATEGORY, "ObjectConfig", title, status,
                    f"{len(out)} enabled account(s) with a non-default primary group.", out)


@rule("S-PrimaryGroup", CATEGORY, "ObjectConfig", "Hidden group membership via primaryGroupID (users)")
def r_primary_group_user(ctx):
    return _primary_group_check(ctx, False, "S-PrimaryGroup",
                                 "Hidden group membership via primaryGroupID (users)")


@rule("S-C-PrimaryGroup", CATEGORY, "ObjectConfig", "Hidden group membership via primaryGroupID (computers)")
def r_primary_group_computer(ctx):
    return _primary_group_check(ctx, True, "S-C-PrimaryGroup",
                                 "Hidden group membership via primaryGroupID (computers)")


def _reversible_check(ctx, obj_filter, rule_id, title):
    """Accounts storing passwords with reversible encryption. Enabled accounts
    only, matching PingCastle."""
    entries = ctx.search(ctx.base_dn,
                          f"(&{obj_filter}"
                          f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE}))"
                          f"(userAccountControl:1.2.840.113556.1.4.803:={UAC_ENCRYPTED_TEXT_PWD_ALLOWED}))",
                          attributes=["sAMAccountName"])
    out = [{"account": str(e["sAMAccountName"])} for e in entries]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding(rule_id, CATEGORY, "ObjectConfig", title, status,
                    f"{len(out)} enabled account(s) store the password with reversible encryption.", out)


@rule("S-Reversible", CATEGORY, "ObjectConfig", "Reversible password encryption (users)")
def r_reversible_user(ctx):
    return _reversible_check(ctx, "(&(objectCategory=person)(objectClass=user))",
                              "S-Reversible", "Reversible password encryption (users)")


@rule("S-C-Reversible", CATEGORY, "ObjectConfig", "Reversible password encryption (computers)")
def r_reversible_computer(ctx):
    return _reversible_check(ctx, "(objectCategory=computer)",
                              "S-C-Reversible", "Reversible password encryption (computers)")


@rule("S-DefaultOUChanged", CATEGORY, "ObjectConfig", "Default user/computer container redirected")
def r_default_ou_changed(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(objectClass=domainDNS)", attributes=["wellKnownObjects"])
    out = []
    if entries:
        for v in get_attr_list(entries[0], "wellKnownObjects"):
            sval = str(v)
            # format: GUID:DN ; default DNs contain CN=Users / CN=Computers literally
            if ":" in sval:
                guid_part, dn_part = sval.split(":", 1)
                if "cn=users" not in dn_part.lower() and "cn=computers" not in dn_part.lower() \
                        and ("users" in guid_part.lower() or "computers" in guid_part.lower()):
                    pass  # heuristic only; real detection needs the fixed GUID map
    status = Status.NOT_APPLICABLE
    return Finding("S-DefaultOUChanged", CATEGORY, "ObjectConfig",
                    "Default user/computer container redirected", status,
                    "Requires comparing wellKnownObjects GUIDs against the fixed default set; "
                    "informative-only rule in PingCastle, left as manual review.", out)


@rule("S-JavaSchema", CATEGORY, "ObjectConfig", "Java/JNDI schema extension present")
def r_java_schema(ctx) -> Finding:
    java_attrs = ["javaClassName", "javaCodeBase", "javaFactory", "javaRemoteLocation", "javaSerializedData"]
    filt = "(|" + "".join(f"(lDAPDisplayName={a})" for a in java_attrs) + ")"
    entries = ctx.search(ctx.schema_nc, filt, attributes=["lDAPDisplayName"])
    found_attrs = [str(e["lDAPDisplayName"]) for e in entries]
    users_with = []
    if found_attrs:
        user_filt = "(&(objectCategory=person)(objectClass=user)(|" + "".join(f"({a}=*)" for a in found_attrs) + "))"
        users_with = [str(u["sAMAccountName"]) for u in ctx.search(ctx.base_dn, user_filt, attributes=["sAMAccountName"])]
    status = Status.TRIGGERED if found_attrs else Status.CLEAN
    return Finding("S-JavaSchema", CATEGORY, "ObjectConfig", "Java/JNDI schema extension present", status,
                    f"Java schema attributes present: {found_attrs}. Active users using them: {len(users_with)}.",
                    [{"account": u} for u in users_with])


def _preauth_check(ctx, privileged_only, rule_id, title):
    """AS-REP roastable accounts. PingCastle splits these into two disjoint
    rules: S-NoPreAuthAdmin covers PRIVILEGED accounts, and S-NoPreAuth covers
    everyone else -- it explicitly excludes admins. Previously S-NoPreAuth
    counted admins too, double-reporting them across both rules.
    Disabled accounts are excluded (they cannot be roasted)."""
    entries = ctx.search(
        ctx.base_dn,
        f"(&(objectCategory=person)(objectClass=user)"
        f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE}))"
        f"(userAccountControl:1.2.840.113556.1.4.803:={UAC_DONT_REQUIRE_PREAUTH}))",
        attributes=["sAMAccountName", "adminCount"])
    out = []
    for e in entries:
        is_priv = str(get_attr(e, "adminCount", "0")) == "1"
        if is_priv != privileged_only:
            continue
        out.append({"account": str(e["sAMAccountName"])})
    status = Status.TRIGGERED if out else Status.CLEAN
    scope = "privileged" if privileged_only else "non-privileged"
    return Finding(rule_id, CATEGORY, "ObjectConfig", title, status,
                    f"{len(out)} enabled {scope} account(s) do not require Kerberos pre-authentication "
                    "(AS-REP roastable). Privileged status approximated via adminCount=1.", out)


@rule("S-NoPreAuth", CATEGORY, "ObjectConfig", "Kerberos pre-authentication disabled (non-admin)")
def r_no_preauth(ctx):
    return _preauth_check(ctx, False, "S-NoPreAuth",
                           "Kerberos pre-authentication disabled (non-admin)")


@rule("S-NoPreAuthAdmin", CATEGORY, "ObjectConfig", "Kerberos pre-authentication disabled (admin accounts)")
def r_no_preauth_admin(ctx):
    return _preauth_check(ctx, True, "S-NoPreAuthAdmin",
                           "Kerberos pre-authentication disabled (admin accounts)")


@rule("S-PwdNeverExpires", CATEGORY, "ObjectConfig", "Accounts with non-expiring passwords")
def r_pwd_never_expires(ctx) -> Finding:
    # PingCastle only counts ENABLED accounts, requires the password to be at
    # least 30 days old, and exempts Exchange HealthMailbox accounts whose
    # password rotated in the last 40 days (they self-rotate by design).
    entries = ctx.search(ctx.base_dn,
                          f"(&(objectCategory=person)(objectClass=user)"
                          f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE}))"
                          f"(userAccountControl:1.2.840.113556.1.4.803:={UAC_DONT_EXPIRE_PASSWORD}))",
                          attributes=["sAMAccountName", "pwdLastSet"])
    out = []
    for e in entries:
        name = str(e["sAMAccountName"])
        age = days_since(filetime_to_datetime(get_attr(e, "pwdLastSet")))
        if name.lower().startswith("healthmailbox") and age is not None and age < 40:
            continue
        if age is not None and age < 30:
            continue
        out.append({"account": name, "password_age_days": age})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-PwdNeverExpires", CATEGORY, "ObjectConfig", "Accounts with non-expiring passwords",
                    status, f"{len(out)} account(s) with non-expiring password.", out[:200])


@rule("S-PwdNotRequired", CATEGORY, "ObjectConfig", "Accounts that do not require a password")
def r_pwd_not_required(ctx) -> Finding:
    # Enabled accounts only; Exchange monitoring mailboxes are exempt.
    entries = ctx.search(ctx.base_dn,
                          f"(&(objectCategory=person)(objectClass=user)"
                          f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE}))"
                          f"(userAccountControl:1.2.840.113556.1.4.803:={UAC_PASSWD_NOTREQD}))",
                          attributes=["sAMAccountName", "distinguishedName"])
    out = [{"account": str(e["sAMAccountName"])} for e in entries
           if ",CN=Monitoring Mailboxes," not in str(get_attr(e, "distinguishedName", ""))]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-PwdNotRequired", CATEGORY, "ObjectConfig", "Accounts that do not require a password",
                    status, f"{len(out)} enabled account(s) flagged PASSWD_NOTREQD "
                    "(Exchange monitoring mailboxes excluded).", out)


@rule("S-SIDHistory", CATEGORY, "ObjectConfig", "Leftover SIDHistory from a migration")
def r_sidhistory(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(sidHistory=*)", attributes=["sAMAccountName"])
    out = [{"account": str(e["sAMAccountName"])} for e in entries]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-SIDHistory", CATEGORY, "ObjectConfig", "Leftover SIDHistory from a migration",
                    status, f"{len(out)} object(s) still carry a sidHistory value.", out)


def _gpo_registry_rule(ctx, rule_id, title, key_suffix, value_name, bad_predicate, description, scope="MACHINE"):
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    hits = []
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g, scope=scope)
        val = gpomod.find_reg_value(entries, key_suffix, value_name)
        if val is not None and bad_predicate(val):
            hits.append({"gpo": g.display_name, "value": val})
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding(rule_id, CATEGORY, "ObjectConfig", title, status, description.format(n=len(hits)), hits)


@rule("S-DefenderASR", CATEGORY, "ObjectConfig", "Defender ASR rules not configured", requires=("ldap", "smb"))
def r_defender_asr(ctx):
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    any_configured = False
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        if any(k.lower().endswith("windows defender exploit guard\\asr\\rules") for k, *_ in entries):
            any_configured = True
            break
    status = Status.CLEAN if any_configured else Status.TRIGGERED
    return Finding("S-DefenderASR", CATEGORY, "ObjectConfig", "Defender ASR rules not configured", status,
                    "ASR rules found in at least one GPO." if any_configured else "No GPO configures ASR rules.")


@rule("S-FolderOptions", CATEGORY, "ObjectConfig", "Script extensions not redirected away from their default handler",
      requires=("ldap", "smb"))
def r_folder_options(ctx) -> Finding:
    from .. import gpo as gpomod
    import re as _re
    target_exts = ("vbs", "vbe", "js", "jse", "wsf", "wsh", "hta")
    gpos = gpomod.list_gpos(ctx)
    redirected = set()
    found_file = False
    for g in gpos:
        for scope in ("MACHINE", "USER"):
            raw = gpomod._smb_read(ctx, gpomod.gpo_relative_path(g, f"{scope}\\Preferences\\FolderOptions\\FolderOptions.xml"))
            if not raw:
                continue
            found_file = True
            text = raw.decode("utf-8", errors="ignore")
            for ext in target_exts:
                # Heuristic: an explicit <FileExtension ... name="ext" ...> entry present means this
                # extension's association was touched by policy at all (redirecting it away from its
                # default script-host handler is the common reason to touch it via GPP).
                if _re.search(rf'name=["\']{ext}["\']', text, flags=_re.IGNORECASE):
                    redirected.add(ext)
    missing = [e for e in target_exts if e not in redirected]
    status = Status.TRIGGERED if missing else Status.CLEAN
    return Finding("S-FolderOptions", CATEGORY, "ObjectConfig",
                    "Script extensions not redirected away from their default handler", status,
                    f"FolderOptions.xml file{'s' if found_file else ''} found: {found_file}. "
                    f"Extensions with an explicit association entry: {sorted(redirected) or 'none'}. "
                    f"Not covered: {missing}. Confidence note: this checks for the *presence* of a GPP file-"
                    "association entry for each extension as a proxy for redirection (a value flowing through this "
                    "policy area at all is uncommon unless someone intentionally changed it) -- it does not verify "
                    "the entry actually points at notepad.exe/a safe handler. Treat a 'clean' result here as a "
                    "signal to spot-check manually, not a guarantee.", [{"extension": e} for e in missing])


@rule("S-KerberosArmoring", CATEGORY, "ObjectConfig", "Kerberos Armoring (FAST) not enabled for clients",
      requires=("ldap", "smb"))
def r_kerb_armoring(ctx):
    return _gpo_registry_rule(
        ctx, "S-KerberosArmoring", "Kerberos Armoring (FAST) not enabled for clients",
        r"software\policies\microsoft\windows\kerberos\parameters", "EnableCbacAndArmor",
        lambda v: str(v) in ("0", ""), "{n} GPO(s) leave Kerberos client armoring unconfigured/disabled.")


@rule("S-KerberosArmoringDC", CATEGORY, "ObjectConfig", "Kerberos Armoring (FAST) not enabled on DCs",
      requires=("ldap", "smb"))
def r_kerb_armoring_dc(ctx):
    return _gpo_registry_rule(
        ctx, "S-KerberosArmoringDC", "Kerberos Armoring (FAST) not enabled on DCs",
        r"system\currentcontrolset\services\kdc", "EnableKdcArmor",
        lambda v: str(v) in ("0", ""), "{n} GPO(s) leave KDC support for armoring unconfigured/disabled.")


@rule("S-TerminalServicesGPO", CATEGORY, "ObjectConfig", "RDS session/printer-redirection hardening not applied",
      requires=("ldap", "smb"))
def r_terminal_services_gpo(ctx):
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    ok = False
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        max_disc = gpomod.find_reg_value(entries, r"windows nt\terminal services", "MaxDisconnectionTime")
        fdis = gpomod.find_reg_value(entries, r"windows nt\terminal services", "fDisableCpm")
        if max_disc and str(fdis) == "1":
            ok = True
    status = Status.CLEAN if ok else Status.TRIGGERED
    return Finding("S-TerminalServicesGPO", CATEGORY, "ObjectConfig",
                    "RDS session/printer-redirection hardening not applied", status,
                    "Recommended RDS hardening found." if ok else "No GPO sets session timeout + disables printer redirection.")


# ---------------------------------------------------------------------------
# Obsolete OS
# ---------------------------------------------------------------------------

@rule("S-FunctionalLevel1", CATEGORY, "ObsoleteOS", "Domain/forest functional level below recommended")
def r_functional_level(ctx) -> Finding:
    entries = ctx.conn.server.info.other if ctx.conn.server.info else {}
    dfl = entries.get("domainFunctionality", [None])[0]
    ffl = entries.get("forestFunctionality", [None])[0]
    try:
        dfl, ffl = int(dfl), int(ffl)
    except (TypeError, ValueError):
        return Finding("S-FunctionalLevel1", CATEGORY, "ObsoleteOS",
                        "Domain/forest functional level below recommended", Status.ERROR,
                        "Could not read functional level from RootDSE.")
    below = dfl < RECOMMENDED_MIN_FUNCTIONAL_LEVEL or ffl < RECOMMENDED_MIN_FUNCTIONAL_LEVEL
    status = Status.TRIGGERED if below else Status.CLEAN
    return Finding("S-FunctionalLevel1", CATEGORY, "ObsoleteOS",
                    "Domain/forest functional level below recommended", status,
                    f"Domain FL={FUNCTIONAL_LEVELS.get(dfl, dfl)}, Forest FL={FUNCTIONAL_LEVELS.get(ffl, ffl)} "
                    f"(recommended >= {FUNCTIONAL_LEVELS[RECOMMENDED_MIN_FUNCTIONAL_LEVEL]}).")


# ---------------------------------------------------------------------------
# Obsolete OS
#
# Audited against PingCastle's OperatingSystemHelper + HeatlcheckRuleStaledObsolete*.
# Three things matter and were previously wrong here:
#
#  1. NORMALISATION. PingCastle maps the raw `operatingSystem` string through an
#     ORDERED, first-match-wins regex table and then compares with EXACT equality.
#     Naive substring matching gets edge cases wrong -- most importantly
#     "Windows XP Embedded", which normalises to "Windows Embedded" and is NOT
#     reported as XP, and Server SKUs, which must match the `windows server(.*) N`
#     pattern before the bare-number patterns are considered.
#  2. COUNTING. PingCastle counts NumberActive = enabled AND not stale. A
#     decommissioned XP box that hasn't authenticated in a year is not counted.
#     Counting every non-disabled object over-reports.
#  3. SEVERITY TIERS. Most of these rules trigger on PRESENCE (so triggered/clean
#     polarity was already right) but carry 15/6 count tiers that change severity.
#     Those tiers are surfaced in the summary for the human reviewer.
# ---------------------------------------------------------------------------

# Ordered, first-match-wins -- mirrors PingCastle's OperatingSystemHelper table.
# Order is load-bearing: server patterns and "Embedded" must precede the bare
# version patterns.
_OS_NORMALISE = [
    (re.compile(r"windows(.*) 2000", re.I), "Windows 2000"),
    (re.compile(r"windows server(.*) 2003", re.I), "Windows 2003"),
    (re.compile(r"windows server(.*) 2008", re.I), "Windows 2008"),
    (re.compile(r"windows server(.*) 2012", re.I), "Windows 2012"),
    (re.compile(r"windows server(.*) 2016", re.I), "Windows 2016"),
    (re.compile(r"windows server(.*) 2019", re.I), "Windows 2019"),
    (re.compile(r"windows server(.*) 2022", re.I), "Windows 2022"),
    (re.compile(r"windows server(.*) 2025", re.I), "Windows 2025"),
    (re.compile(r"windows(.*) Embedded", re.I), "Windows Embedded"),
    (re.compile(r"windows(.*) 7", re.I), "Windows 7"),
    (re.compile(r"windows(.*) 8", re.I), "Windows 8"),
    (re.compile(r"windows(.*) XP", re.I), "Windows XP"),
    (re.compile(r"windows(.*) 10", re.I), "Windows 10"),
    (re.compile(r"windows(.*) 11", re.I), "Windows 11"),
    (re.compile(r"windows(.*) Vista", re.I), "Windows Vista"),
    (re.compile(r"windows(.*) NT", re.I), "Windows NT"),
]

# Count tiers from PingCastle: (threshold, severity-label). Presence alone still
# triggers; these only describe how bad it is.
_OS_TIERS = [(15, "high"), (6, "medium")]

# Windows Server 2012 rules are date-gated in PingCastle (2012 left support
# 2023-10-10); before that date the rule returns "not applicable".
_WS2012_EOL = _dt.date(2023, 10, 10)


def normalise_os(raw: str) -> str:
    """PingCastle-compatible OS normalisation (ordered, first match wins)."""
    if not raw:
        return "OperatingSystem not set"
    raw = raw.replace("\u00a0", " ")
    for pattern, label in _OS_NORMALISE:
        if pattern.search(raw):
            return label
    return raw


def _os_scan(ctx):
    """One LDAP pass over computer objects, shared by every obsolete-OS rule.

    `active` mirrors PingCastle's NumberActive: enabled AND authenticated within
    the inactivity window. Only active machines are counted toward findings.
    """
    if "os_scan" in ctx._cache:
        return ctx._cache["os_scan"]
    entries = ctx.search(
        ctx.base_dn,
        f"(&(objectCategory=computer)(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))",
        attributes=["sAMAccountName", "operatingSystem", "operatingSystemVersion",
                    "primaryGroupID", "lastLogonTimestamp"])
    result = []
    for e in entries:
        raw_os = get_attr(e, "operatingSystem") or ""
        inactive_days = days_since(filetime_to_datetime(get_attr(e, "lastLogonTimestamp")))
        result.append({
            "account": str(e["sAMAccountName"]),
            "os_raw": raw_os,
            "os": normalise_os(raw_os),
            "os_version": str(get_attr(e, "operatingSystemVersion") or ""),
            "is_dc": str(get_attr(e, "primaryGroupID")) in ("516", "521"),
            "active": inactive_days is not None and inactive_days < 180,
        })
    ctx._cache["os_scan"] = result
    return result


def _obsolete_os_rule(ctx, os_label, want_dc, rule_id, title):
    hits = [r for r in _os_scan(ctx)
            if r["is_dc"] == want_dc and r["os"] == os_label and r["active"]]
    inactive_same = [r for r in _os_scan(ctx)
                     if r["is_dc"] == want_dc and r["os"] == os_label and not r["active"]]

    # Windows Server 2012 rules are not applicable before its EOL date.
    if os_label == "Windows 2012" and _dt.date.today() < _WS2012_EOL:
        return Finding(rule_id, CATEGORY, "ObsoleteOS", title, Status.NOT_APPLICABLE,
                        f"Windows Server 2012 remains in support until {_WS2012_EOL}.")

    severity = "low"
    for threshold, label in _OS_TIERS:
        if len(hits) >= threshold:
            severity = label
            break

    status = Status.TRIGGERED if hits else Status.CLEAN
    noun = "DC" if want_dc else "computer"
    extra = (f" A further {len(inactive_same)} inactive/stale {noun}(s) run this OS and are excluded "
             "from the count, matching PingCastle's active-only counting.") if inactive_same else ""
    return Finding(rule_id, CATEGORY, "ObsoleteOS", title, status,
                    f"{len(hits)} active {noun}(s) running {os_label} "
                    f"(severity tier: {severity}; PingCastle escalates at 6 and 15).{extra}",
                    [{"account": h["account"], "os": h["os_raw"]} for h in hits[:200]])


# (normalised OS label, is_dc, rule id, title)
_OS_RULES = [
    ("Windows NT", False, "S-OS-NT", "Obsolete OS: Windows NT"),
    ("Windows 2000", False, "S-OS-2000", "Obsolete OS: Windows 2000"),
    ("Windows 2000", True, "S-DC-2000", "Obsolete DC OS: Windows 2000"),
    ("Windows XP", False, "S-OS-XP", "Obsolete OS: Windows XP"),
    ("Windows Vista", False, "S-OS-Vista", "Obsolete OS: Windows Vista"),
    ("Windows 2003", False, "S-OS-2003", "Obsolete OS: Windows Server 2003"),
    ("Windows 2003", True, "S-DC-2003", "Obsolete DC OS: Windows Server 2003"),
    ("Windows 2008", False, "S-OS-2008", "Obsolete OS: Windows Server 2008/R2"),
    ("Windows 2008", True, "S-DC-2008", "Obsolete DC OS: Windows Server 2008/R2"),
    ("Windows 7", False, "S-OS-Win7", "Obsolete OS: Windows 7"),
    ("Windows 8", False, "S-OS-Win8", "Obsolete OS: Windows 8/8.1"),
    ("Windows 2012", False, "S-OS-2012", "Obsolete OS: Windows Server 2012/R2"),
    ("Windows 2012", True, "S-DC-2012", "Obsolete DC OS: Windows Server 2012/R2"),
]

for _os_label, _is_dc, _rid, _title in _OS_RULES:
    def _make(os_label=_os_label, is_dc=_is_dc, rid=_rid, title=_title):
        @rule(rid, CATEGORY, "ObsoleteOS", title)
        def _r(ctx):
            return _obsolete_os_rule(ctx, os_label, is_dc, rid, title)
        return _r
    _make()


# Windows 10/11 build numbers that have passed end-of-servicing. PingCastle
# checks the parsed build from operatingSystemVersion against Microsoft's
# release-health data with per-build EOL dates; this is the equivalent set of
# consumer/enterprise builds that are out of support as of the tool's knowledge.
# Builds NOT in this table are treated as supported (conservative: we would
# rather miss a newly-expired build than invent an EOL date).
_W10_EOL_BUILDS = {
    10240: "Windows 10 1507", 10586: "Windows 10 1511", 14393: "Windows 10 1607",
    15063: "Windows 10 1703", 16299: "Windows 10 1709", 17134: "Windows 10 1803",
    17763: "Windows 10 1809", 18362: "Windows 10 1903", 18363: "Windows 10 1909",
    19041: "Windows 10 2004", 19042: "Windows 10 20H2", 19043: "Windows 10 21H1",
    19044: "Windows 10 21H2", 19045: "Windows 10 22H2",
    22000: "Windows 11 21H2", 22621: "Windows 11 22H2",
}


@rule("S-OS-W10", CATEGORY, "ObsoleteOS", "Windows 10/11 build past end of servicing")
def r_os_w10(ctx) -> Finding:
    """Unlike the other OS rules, PingCastle does not flag "Windows 10" as a
    whole -- it parses the BUILD from operatingSystemVersion ("10.0 (19045)")
    and flags builds whose servicing has ended. Flagging every Windows 10
    machine, as this rule previously did, is simply wrong: a current build is
    fully supported.
    """
    hits = []
    unparsed = 0
    for r in _os_scan(ctx):
        if r["is_dc"] or not r["active"]:
            continue
        if r["os"] not in ("Windows 10", "Windows 11"):
            continue
        m = re.search(r"(\d+)\.(\d+)\s*\((\d+)\)", r["os_version"])
        if not m:
            unparsed += 1
            continue
        major, minor, build = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if major == 10 and minor == 0 and build in _W10_EOL_BUILDS:
            hits.append({"account": r["account"], "build": build,
                         "release": _W10_EOL_BUILDS[build]})
    severity = "low"
    for threshold, label in _OS_TIERS:
        if len(hits) >= threshold:
            severity = label
            break
    status = Status.TRIGGERED if hits else Status.CLEAN
    note = (f" {unparsed} machine(s) had an operatingSystemVersion that could not be parsed "
            "and were skipped.") if unparsed else ""
    return Finding("S-OS-W10", CATEGORY, "ObsoleteOS", "Windows 10/11 build past end of servicing",
                    status,
                    f"{len(hits)} active machine(s) run a Windows 10/11 build past end of servicing "
                    f"(severity tier: {severity}). Builds not in the tool's EOL table are treated as "
                    f"supported, so a very recently expired build may not be flagged.{note}", hits[:200])


@rule("S-FunctionalLevel3", CATEGORY, "ObsoleteOS", "Domain functional level below recommended")
def r_functional_level_domain(ctx) -> Finding:
    info = ctx.conn.server.info.other if ctx.conn.server.info else {}
    dfl = info.get("domainFunctionality", [None])[0]
    try:
        dfl = int(dfl)
    except (TypeError, ValueError):
        return Finding("S-FunctionalLevel3", CATEGORY, "ObsoleteOS", "Domain functional level below recommended",
                        Status.ERROR, "Could not read domainFunctionality from RootDSE.")
    status = Status.TRIGGERED if dfl < RECOMMENDED_MIN_FUNCTIONAL_LEVEL else Status.CLEAN
    return Finding("S-FunctionalLevel3", CATEGORY, "ObsoleteOS", "Domain functional level below recommended",
                    status, f"Domain functional level = {FUNCTIONAL_LEVELS.get(dfl, dfl)} "
                    f"(recommended >= {FUNCTIONAL_LEVELS[RECOMMENDED_MIN_FUNCTIONAL_LEVEL]}).")


@rule("S-FunctionalLevel4", CATEGORY, "ObsoleteOS", "Forest functional level below recommended")
def r_functional_level_forest(ctx) -> Finding:
    info = ctx.conn.server.info.other if ctx.conn.server.info else {}
    ffl = info.get("forestFunctionality", [None])[0]
    try:
        ffl = int(ffl)
    except (TypeError, ValueError):
        return Finding("S-FunctionalLevel4", CATEGORY, "ObsoleteOS", "Forest functional level below recommended",
                        Status.ERROR, "Could not read forestFunctionality from RootDSE.")
    status = Status.TRIGGERED if ffl < RECOMMENDED_MIN_FUNCTIONAL_LEVEL else Status.CLEAN
    return Finding("S-FunctionalLevel4", CATEGORY, "ObsoleteOS", "Forest functional level below recommended",
                    status, f"Forest functional level = {FUNCTIONAL_LEVELS.get(ffl, ffl)} "
                    f"(recommended >= {FUNCTIONAL_LEVELS[RECOMMENDED_MIN_FUNCTIONAL_LEVEL]}). "
                    "Note: S-FunctionalLevel1 above already reports both; this and S-FunctionalLevel3 split "
                    "them into individual domain-only / forest-only rules matching PingCastle's separate rule IDs.")

# ---------------------------------------------------------------------------
# Old Authentication Protocols
# ---------------------------------------------------------------------------

@rule("S-AesNotEnabled", CATEGORY, "OldAuthenticationProtocols", "Accounts without AES Kerberos support")
def r_aes_not_enabled(ctx) -> Finding:
    """PingCastle flags an account as "not AES enabled" on either of two
    conditions, and covers BOTH users and computers (this rule previously
    checked only SPN-bearing USERS, missing the larger population):

      a) The account's password predates the first Windows 2008 DC install, so
         its stored keys were generated before AES was available at all; or
      b) It has an SPN and msDS-SupportedEncryptionTypes lacks both AES bits
         (0x8 AES128 / 0x10 AES256).

    The whole rule is gated on a Win2008+ DC existing; before that AES was not
    available and the finding would be meaningless.
    """
    dcs = ctx.search(ctx.base_dn, "(&(objectCategory=computer)(primaryGroupID=516))",
                      attributes=["operatingSystem", "whenCreated"])
    if not dcs:
        return Finding("S-AesNotEnabled", CATEGORY, "OldAuthenticationProtocols",
                        "Accounts without AES Kerberos support", Status.ERROR,
                        "No Domain Controllers found; cannot establish the Win2008 baseline this rule needs.")

    # Approximate PingCastle's DCWin2008Install: the earliest creation date among
    # DCs running Windows 2008 or later. PingCastle derives this from replication
    # metadata; whenCreated is the closest LDAP-only equivalent.
    win2008_plus = []
    for d in dcs:
        os_label = normalise_os(get_attr(d, "operatingSystem") or "")
        if os_label in ("Windows 2008", "Windows 2012", "Windows 2016",
                        "Windows 2019", "Windows 2022", "Windows 2025"):
            wc = get_attr(d, "whenCreated")
            if wc is not None:
                win2008_plus.append(wc)
    if not win2008_plus:
        return Finding("S-AesNotEnabled", CATEGORY, "OldAuthenticationProtocols",
                        "Accounts without AES Kerberos support", Status.NOT_APPLICABLE,
                        "No Windows Server 2008 or later Domain Controller found; AES Kerberos "
                        "encryption is not available in this domain, so the check does not apply.")
    baseline = min(win2008_plus)
    baseline_days = days_since(baseline)

    entries = ctx.search(
        ctx.base_dn,
        f"(&(|(&(objectCategory=person)(objectClass=user))(objectCategory=computer))"
        f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))",
        attributes=["sAMAccountName", "pwdLastSet", "servicePrincipalName",
                    "msDS-SupportedEncryptionTypes"])
    out = []
    for e in entries:
        pwd_age = days_since(filetime_to_datetime(get_attr(e, "pwdLastSet")))
        spns = get_attr_list(e, "servicePrincipalName")
        try:
            etypes = int(get_attr(e, "msDS-SupportedEncryptionTypes", 0) or 0)
        except (TypeError, ValueError):
            etypes = 0
        # (a) password older than the Win2008 baseline
        if pwd_age is not None and baseline_days is not None and pwd_age > baseline_days:
            out.append({"account": str(e["sAMAccountName"]),
                        "reason": "password predates the first Windows 2008+ DC",
                        "password_age_days": pwd_age})
        # (b) SPN-bearing account without either AES bit
        elif spns and not (etypes & (ENCTYPE_AES128 | ENCTYPE_AES256)):
            out.append({"account": str(e["sAMAccountName"]),
                        "reason": "has an SPN but no AES bit in msDS-SupportedEncryptionTypes",
                        "supportedEncryptionTypes": etypes})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-AesNotEnabled", CATEGORY, "OldAuthenticationProtocols",
                    "Accounts without AES Kerberos support", status,
                    f"{len(out)} enabled user/computer account(s) lack usable AES Kerberos keys. "
                    "Baseline for condition (a) approximated from the earliest Windows 2008+ DC's "
                    "whenCreated, since the exact install date needs replication metadata.",
                    out[:200])


@rule("S-DesEnabled", CATEGORY, "OldAuthenticationProtocols", "Accounts allowing DES Kerberos encryption")
def r_des_enabled(ctx) -> Finding:
    # PingCastle triggers on EITHER the USE_DES_KEY_ONLY UAC flag OR the DES bits
    # (0x1 DES-CBC-CRC / 0x2 DES-CBC-MD5) in msDS-SupportedEncryptionTypes. Checking
    # only the UAC flag missed every account configured the second way.
    entries = ctx.search(ctx.base_dn,
                          f"(&(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE}))"
                          f"(|(userAccountControl:1.2.840.113556.1.4.803:={UAC_USE_DES_KEY_ONLY})"
                          f"(msDS-SupportedEncryptionTypes:1.2.840.113556.1.4.804:={ENCTYPE_DES_CBC_CRC | ENCTYPE_DES_CBC_MD5})))",
                          attributes=["sAMAccountName", "userAccountControl", "msDS-SupportedEncryptionTypes"])
    out = []
    for e in entries:
        uac = int(get_attr(e, "userAccountControl", 0) or 0)
        etypes = int(get_attr(e, "msDS-SupportedEncryptionTypes", 0) or 0)
        why = []
        if uac & UAC_USE_DES_KEY_ONLY:
            why.append("USE_DES_KEY_ONLY")
        if etypes & (ENCTYPE_DES_CBC_CRC | ENCTYPE_DES_CBC_MD5):
            why.append("msDS-SupportedEncryptionTypes DES bit")
        out.append({"account": str(e["sAMAccountName"]), "reason": ", ".join(why)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-DesEnabled", CATEGORY, "OldAuthenticationProtocols",
                    "Accounts allowing DES Kerberos encryption", status,
                    f"{len(out)} enabled account(s) permit DES.", out)


@rule("S-OldNtlm", CATEGORY, "OldAuthenticationProtocols", "NTLMv1/LM authentication still accepted",
      requires=("ldap", "smb"))
def r_old_ntlm(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    best_level = None
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        reg_values = tmpl.get("Registry Values", {})
        for k, v in reg_values.items():
            if k.lower().endswith("lmcompatibilitylevel"):
                try:
                    level = int(v.split(",")[-1])
                    best_level = level if best_level is None else max(best_level, level)
                except ValueError:
                    continue
    if best_level is None:
        return Finding("S-OldNtlm", CATEGORY, "OldAuthenticationProtocols",
                        "NTLMv1/LM authentication still accepted", Status.TRIGGERED,
                        "No GPO sets LmCompatibilityLevel; DCs fall back to the insecure default (NTLMv1/LM accepted).")
    status = Status.CLEAN if best_level >= 5 else Status.TRIGGERED
    return Finding("S-OldNtlm", CATEGORY, "OldAuthenticationProtocols",
                    "NTLMv1/LM authentication still accepted", status,
                    f"Highest configured LmCompatibilityLevel = {best_level} (5 = NTLMv2-only, refuse LM/NTLMv1).")


@rule("S-SMB-v1", CATEGORY, "OldAuthenticationProtocols", "SMBv1 enabled on Domain Controllers",
      requires=("ldap", "smb"))
def r_smb_v1(ctx) -> Finding:
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError:
        return Finding("S-SMB-v1", CATEGORY, "OldAuthenticationProtocols", "SMBv1 enabled on Domain Controllers",
                        Status.REQUIRES_SMB, "impacket not installed.")
    hits = []
    for dc in ctx.dc_hostnames:
        try:
            smb = SMBConnection(dc, dc, timeout=5, preferredDialect=None)
            dialect = smb.getDialect()
            smb.close()
            # impacket's SMB_DIALECT constant for SMBv1 is 0xFF (SMB, not SMB2+)
            if dialect in (0xFF,) or str(dialect).upper().startswith("SMB "):
                hits.append({"dc": dc, "dialect": str(dialect)})
        except Exception:
            continue
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding("S-SMB-v1", CATEGORY, "OldAuthenticationProtocols", "SMBv1 enabled on Domain Controllers",
                    status, f"{len(hits)} DC(s) negotiated SMBv1.", hits)


# ---------------------------------------------------------------------------
# Provisioning
# ---------------------------------------------------------------------------

@rule("S-ADRegistration", CATEGORY, "Provisioning", "Unrestricted computer join (ms-DS-MachineAccountQuota)")
def r_ad_registration(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(objectClass=domainDNS)", attributes=["ms-DS-MachineAccountQuota"])
    quota = get_attr(entries[0], "ms-DS-MachineAccountQuota") if entries else None
    try:
        quota = int(quota)
    except (TypeError, ValueError):
        quota = 10  # AD default
    status = Status.TRIGGERED if quota > 0 else Status.CLEAN
    return Finding("S-ADRegistration", CATEGORY, "Provisioning",
                    "Unrestricted computer join (ms-DS-MachineAccountQuota)", status,
                    f"ms-DS-MachineAccountQuota = {quota} (0 = restricted to admins).")


@rule("S-ADRegistrationSchema", CATEGORY, "Provisioning", "Schema class allows arbitrary object creation")
def r_ad_registration_schema(ctx) -> Finding:
    hits = []
    for cls in ("computer", "user"):
        entries = ctx.search(ctx.schema_nc, f"(&(objectClass=classSchema)(possSuperiors={cls}))",
                              attributes=["lDAPDisplayName", "subClassOf"])
        for e in entries:
            hits.append({"class": str(e["lDAPDisplayName"]), "poss_superior": cls})
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding("S-ADRegistrationSchema", CATEGORY, "Provisioning",
                    "Schema class allows arbitrary object creation", status,
                    f"{len(hits)} schema class(es) list computer/user as a possible superior.", hits)


@rule("S-DCRegistration", CATEGORY, "Provisioning", "DC userAccountControl does not match expected value")
def r_dc_registration(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(&(objectCategory=computer)(|(primaryGroupID=516)(primaryGroupID=521)))",
                          attributes=["sAMAccountName", "userAccountControl", "primaryGroupID"])
    expected_rw = UAC_SERVER_TRUST_ACCOUNT | UAC_TRUSTED_FOR_DELEGATION  # 0x00082000
    expected_rodc = UAC_PARTIAL_SECRETS_ACCOUNT | 0x01000000 | UAC_WORKSTATION_TRUST_ACCOUNT  # 0x05001000
    out = []
    for e in entries:
        try:
            uac = int(get_attr(e, "userAccountControl"))
        except (TypeError, ValueError):
            continue
        is_rodc = str(get_attr(e, "primaryGroupID")) == "521"
        expected = expected_rodc if is_rodc else expected_rw
        if uac != expected:
            out.append({"account": str(e["sAMAccountName"]), "uac": hex(uac), "expected": hex(expected)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-DCRegistration", CATEGORY, "Provisioning",
                    "DC userAccountControl does not match expected value", status,
                    f"{len(out)} DC object(s) with unexpected userAccountControl.", out)


# ---------------------------------------------------------------------------
# Replication
# ---------------------------------------------------------------------------

@rule("S-Duplicate", CATEGORY, "Replication", "Duplicate objects from replication conflicts")
def r_duplicate(ctx) -> Finding:
    # Two distinct replication-conflict signatures: a "CNF:" mangled DN, and a
    # sAMAccountName prefixed "$duplicate-". Only the first was checked before.
    entries = ctx.search(ctx.base_dn, "(|(cn=*CNF:*)(sAMAccountName=$duplicate-*))",
                          attributes=["distinguishedName", "sAMAccountName"])
    out = [{"dn": str(e["distinguishedName"])} for e in entries]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-Duplicate", CATEGORY, "Replication", "Duplicate objects from replication conflicts",
                    status, f"{len(out)} duplicate (CNF:) object(s) found.", out)


# ---------------------------------------------------------------------------
# Vulnerability Management
# ---------------------------------------------------------------------------

@rule("S-DC-NotUpdated", CATEGORY, "VulnerabilityManagement", "DC not rebooted in ~6 months (patch-recency heuristic)")
def r_dc_not_updated(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(&(objectCategory=computer)(primaryGroupID=516))",
                          attributes=["dNSHostName", "lastLogonTimestamp"])
    out = []
    for e in entries:
        last = filetime_to_datetime(get_attr(e, "lastLogonTimestamp"))
        d = days_since(last)
        if d is not None and d >= 180:
            out.append({"dc": str(e["dNSHostName"]), "days_since_activity": d})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-DC-NotUpdated", CATEGORY, "VulnerabilityManagement",
                    "DC not rebooted in ~6 months (patch-recency heuristic)", status,
                    "Heuristic only (uses lastLogonTimestamp as an activity proxy, same limitation "
                    "PingCastle documents for this rule; a precise uptime check needs "
                    "'net statistics workstation' or WMI, which requires local admin on the DC).", out)


def _cve_heuristic(rule_id, title, min_days=730):
    def _r(ctx):
        entries = ctx.search(ctx.base_dn, "(&(objectCategory=computer)(primaryGroupID=516))",
                              attributes=["dNSHostName", "lastLogonTimestamp"])
        out = []
        for e in entries:
            d = days_since(filetime_to_datetime(get_attr(e, "lastLogonTimestamp")))
            if d is not None and d >= min_days:
                out.append({"dc": str(e["dNSHostName"]), "days_since_activity": d})
        status = Status.TRIGGERED if out else Status.CLEAN
        return Finding(rule_id, CATEGORY, "VulnerabilityManagement", title, status,
                        "Heuristic only: flags DCs with very stale activity as 'possibly unpatched for years'. "
                        "This tool does not attempt to trigger MS14-068/MS17-010 (that would be exploitation, "
                        "out of scope for a read-only auditor). Confirm patch level via WSUS/SCCM/vendor scanner.",
                        out)
    return _r


rule("S-Vuln-MS14-068", CATEGORY, "VulnerabilityManagement", "DC possibly vulnerable to MS14-068 (heuristic)")(
    _cve_heuristic("S-Vuln-MS14-068", "DC possibly vulnerable to MS14-068 (heuristic)"))
rule("S-Vuln-MS17_010", CATEGORY, "VulnerabilityManagement", "DC possibly vulnerable to MS17-010 (heuristic)")(
    _cve_heuristic("S-Vuln-MS17_010", "DC possibly vulnerable to MS17-010 (heuristic)"))


def _wsus_rule(rule_id, title, check_fn, description):
    def _r(ctx):
        from .. import gpo as gpomod
        gpos = gpomod.list_gpos(ctx)
        hits = []
        for g in gpos:
            entries = gpomod.fetch_registry_pol(ctx, g)
            server = gpomod.find_reg_value(entries, r"policies\microsoft\windows\windowsupdate", "WUServer")
            proxy_behavior = gpomod.find_reg_value(entries, r"policies\microsoft\windows\windowsupdate",
                                                     "SetProxyBehaviorForUpdateDetection")
            no_pin = gpomod.find_reg_value(entries, r"policies\microsoft\windows\windowsupdate",
                                            "DoNotEnforceEnterpriseTLSCertPinningForUpdateDetection")
            if check_fn(server, proxy_behavior, no_pin):
                hits.append({"gpo": g.display_name, "wu_server": server})
        status = Status.TRIGGERED if hits else Status.CLEAN
        return Finding(rule_id, CATEGORY, "VulnerabilityManagement", title, status, description.format(n=len(hits)), hits)
    return _r


rule("S-WSUS-HTTP", CATEGORY, "VulnerabilityManagement", "WSUS configured over HTTP", requires=("ldap", "smb"))(
    _wsus_rule("S-WSUS-HTTP", "WSUS configured over HTTP",
               lambda server, proxy, pin: server and str(server).lower().startswith("http://"),
               "{n} GPO(s) point WSUS clients at an http:// server."))
rule("S-WSUS-UserProxy", CATEGORY, "VulnerabilityManagement", "WSUS user-proxy fallback enabled", requires=("ldap", "smb"))(
    _wsus_rule("S-WSUS-UserProxy", "WSUS user-proxy fallback enabled",
               lambda server, proxy, pin: proxy is not None and str(proxy) != "0"
               and server and str(server).lower().startswith("http://"),
               "{n} GPO(s) allow a user proxy fallback combined with an HTTP WSUS server."))
rule("S-WSUS-NoPinning", CATEGORY, "VulnerabilityManagement", "WSUS certificate pinning disabled", requires=("ldap", "smb"))(
    _wsus_rule("S-WSUS-NoPinning", "WSUS certificate pinning disabled",
               lambda server, proxy, pin: pin is not None and str(pin) == "1",
               "{n} GPO(s) disable WSUS certificate pinning."))
