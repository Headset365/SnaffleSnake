"""
Privileged Accounts rules (PingCastle category `P-*`).

ACL-based rules parse `nTSecurityDescriptor` with the pure-Python parser in
`adaudit.secdesc` -- read-only decoding of bytes already retrieved via a
normal authenticated LDAP search. Nothing here writes an ACE or modifies any
object.
"""
from __future__ import annotations

from ..constants import (
    UAC_ACCOUNTDISABLE, UAC_NOT_DELEGATED, UAC_TRUSTED_FOR_DELEGATION,
    PRIVILEGED_RID_SUFFIXES, DCSYNC_GUIDS, EXTENDED_RIGHTS, DANGEROUS_RIGHTS_MASK,
    UAC_TRUSTED_TO_AUTH_FOR_DELEGATION,
    DANGEROUS_RIGHTS_MASK_EXTENDED,
    ACCESS_MASK,
)
from ..models import rule, not_implemented, Finding, Status
from ..secdesc import parse_security_descriptor
from ..acl import (
    effective_dangerous_aces, is_expected_privileged as _acl_is_expected_privileged,
    is_broad_trustee, has_dcsync_rights,
)
from ..utils import filetime_to_datetime, days_since, get_attr, get_attr_list, sid_to_rid, bin_sid_to_str

CATEGORY = "PrivilegedAccounts"

PRIVILEGED_GROUP_RIDS = {512: "Domain Admins", 519: "Enterprise Admins", 518: "Schema Admins",
                          544: "Administrators (BUILTIN)", 551: "Backup Operators (BUILTIN, RID varies)"}

WELL_KNOWN_ADMIN_SIDS_SUFFIX = ("-512", "-519", "-518")  # Domain/Enterprise/Schema Admins
BUILTIN_ADMINS = "S-1-5-32-544"
EVERYONE = "S-1-1-0"
AUTHENTICATED_USERS = "S-1-5-11"
DOMAIN_USERS_SUFFIX = "-513"


def _privileged_accounts(ctx):
    """Members of Domain Admins, Enterprise Admins, Schema Admins, BUILTIN
    Administrators -- resolved recursively via LDAP_MATCHING_RULE_IN_CHAIN."""
    if "priv_accounts" in ctx._cache:
        return ctx._cache["priv_accounts"]
    domain_sid = ctx.domain_sid
    group_dns = []
    for rid in (512, 519, 518):
        entries = ctx.search(ctx.base_dn, f"(objectSid={domain_sid}-{rid})", attributes=["distinguishedName"])
        if entries:
            group_dns.append(str(entries[0]["distinguishedName"]))
    entries = ctx.search(f"CN=Administrators,CN=Builtin,{ctx.base_dn}", "(cn=Administrators)",
                          attributes=["distinguishedName"])
    if entries:
        group_dns.append(str(entries[0]["distinguishedName"]))

    members = {}
    for gdn in group_dns:
        filt = f"(memberOf:1.2.840.113556.1.4.1941:={gdn})"
        for e in ctx.search(ctx.base_dn, filt, attributes=[
                "sAMAccountName", "userAccountControl", "pwdLastSet", "lastLogonTimestamp",
                "servicePrincipalName", "adminCount", "mail", "distinguishedName", "objectSid", "scriptPath"]):
            dn = str(get_attr(e, "distinguishedName", ""))
            members[dn] = e
    result = list(members.values())
    ctx._cache["priv_accounts"] = result
    return result


@rule("P-AdminNum", CATEGORY, "AdminControl", "Excessive number of privileged accounts")
def r_admin_num(ctx) -> Finding:
    members = _privileged_accounts(ctx)
    # PingCastle's actual test is proportional, not a flat count: trigger when
    # privileged accounts exceed 10% of ACTIVE users, or exceed 50 outright.
    # A flat ">10" (the previous logic here) fires on almost any real domain.
    active_users = ctx.search(ctx.base_dn,
                               f"(&(objectCategory=person)(objectClass=user)"
                               f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))",
                               attributes=["sAMAccountName"])
    n_active = len(active_users)
    n_priv = len(members)
    pct = (n_priv * 100 / n_active) if n_active else 0
    triggered = (pct > 10) or (n_priv > 50)
    status = Status.TRIGGERED if triggered else Status.CLEAN
    return Finding("P-AdminNum", CATEGORY, "AdminControl", "Excessive number of privileged accounts",
                    status, f"{n_priv} privileged account(s) out of {n_active} active user(s) "
                    f"({pct:.1f}%). Triggers above 10% or above 50 accounts.",
                    [{"account": str(get_attr(m, "sAMAccountName", ""))} for m in members])


@rule("P-Inactive", CATEGORY, "AdminControl", "Stale privileged accounts")
def r_p_inactive(ctx) -> Finding:
    members = _privileged_accounts(ctx)
    out = []
    for m in members:
        d = days_since(filetime_to_datetime(get_attr(m, "lastLogonTimestamp")))
        if d is None or d >= 90:
            out.append({"account": str(get_attr(m, "sAMAccountName", "")), "days_inactive": d})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-Inactive", CATEGORY, "AdminControl", "Stale privileged accounts", status,
                    f"{len(out)} privileged account(s) inactive 90+ days.", out)


@rule("P-AdminLogin", CATEGORY, "AdminControl", "Privileged account logon exposure")
def r_p_admin_login(ctx) -> Finding:
    # Without 4624 event log correlation we cannot see *where* admins log on;
    # report presence of privileged accounts without the anti-delegation
    # protections that limit blast radius if they do log on to a lower tier.
    members = _privileged_accounts(ctx)
    exposed = [m for m in members if not get_attr(m, "userAccountControl") or
               not (int(get_attr(m, "userAccountControl", 0)) & UAC_NOT_DELEGATED)]
    status = Status.TRIGGERED if exposed else Status.CLEAN
    return Finding("P-AdminLogin", CATEGORY, "AdminControl", "Privileged account logon exposure", status,
                    f"{len(exposed)} privileged account(s) lack delegation protection "
                    "(proxy indicator for tier-exposure risk; full answer needs DC security event log 4624/4672 correlation).",
                    [{"account": str(get_attr(m, "sAMAccountName", ""))} for m in exposed])


@rule("P-OperatorsEmpty", CATEGORY, "AdminControl", "Legacy Operator groups should be empty")
def r_operators_empty(ctx) -> Finding:
    out = []
    # PingCastle checks only these two -- Backup/Print Operators are NOT part of
    # this rule upstream, and including them produced findings PingCastle never raises.
    for cn in ("Account Operators", "Server Operators"):
        entries = ctx.search(f"CN=Builtin,{ctx.base_dn}", f"(cn={cn})", attributes=["member"])
        if entries:
            members = get_attr_list(entries[0], "member")
            if members:
                out.append({"group": cn, "member_count": len(members)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-OperatorsEmpty", CATEGORY, "AdminControl", "Legacy Operator groups should be empty",
                    status, f"{len(out)} legacy operator group(s) have members.", out)


@rule("P-AdminPwdTooOld", CATEGORY, "AccountTakeOver", "Privileged account password too old")
def r_admin_pwd_too_old(ctx) -> Finding:
    members = _privileged_accounts(ctx)
    out = []
    for m in members:
        d = days_since(filetime_to_datetime(get_attr(m, "pwdLastSet")))
        if d is not None and d >= 1095:
            out.append({"account": str(get_attr(m, "sAMAccountName", "")), "password_age_days": d})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-AdminPwdTooOld", CATEGORY, "AccountTakeOver", "Privileged account password too old",
                    status, f"{len(out)} privileged account(s) with password 3+ years old.", out)


@rule("P-Delegated", CATEGORY, "AccountTakeOver", "Privileged account missing anti-delegation protection")
def r_p_delegated(ctx) -> Finding:
    members = _privileged_accounts(ctx)
    protected_dns = {str(get_attr(e, "distinguishedName", "")) for e in ctx.search(
        ctx.base_dn, f"(memberOf:1.2.840.113556.1.4.1941:=CN=Protected Users,CN=Users,{ctx.base_dn})",
        attributes=["distinguishedName"])}
    out = []
    for m in members:
        uac = int(get_attr(m, "userAccountControl", 0) or 0)
        dn = str(get_attr(m, "distinguishedName", ""))
        # gMSAs are excluded upstream: their passwords are AD-managed and rotated,
        # so the delegation concern does not apply the same way.
        classes = [str(x).lower() for x in get_attr_list(m, "objectClass")]
        if "msds-groupmanagedserviceaccount" in classes:
            continue
        if not (uac & UAC_NOT_DELEGATED) and dn not in protected_dns:
            out.append({"account": str(get_attr(m, "sAMAccountName", ""))})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-Delegated", CATEGORY, "AccountTakeOver",
                    "Privileged account missing anti-delegation protection", status,
                    f"{len(out)} privileged account(s) can be delegated (no NOT_DELEGATED flag, not in Protected Users).", out)


@rule("P-Kerberoasting", CATEGORY, "AccountTakeOver", "Privileged accounts vulnerable to Kerberoasting")
def r_p_kerberoasting(ctx) -> Finding:
    members = _privileged_accounts(ctx)
    out = []
    for m in members:
        spns = get_attr_list(m, "servicePrincipalName")
        if spns:
            pls = filetime_to_datetime(get_attr(m, "pwdLastSet"))
            d = days_since(pls)
            if d is None or d > 40:  # PingCastle ignores recently-rotated SPN accounts
                out.append({"account": str(get_attr(m, "sAMAccountName", "")), "spn_count": len(spns)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-Kerberoasting", CATEGORY, "AccountTakeOver",
                    "Privileged accounts vulnerable to Kerberoasting", status,
                    f"{len(out)} privileged account(s) carry an SPN.", out)


@rule("P-ProtectedUsers", CATEGORY, "AccountTakeOver", "Privileged accounts outside Protected Users group")
def r_p_protected_users(ctx) -> Finding:
    members = _privileged_accounts(ctx)
    protected_dns = {str(get_attr(e, "distinguishedName", "")) for e in ctx.search(
        ctx.base_dn, f"(memberOf:1.2.840.113556.1.4.1941:=CN=Protected Users,CN=Users,{ctx.base_dn})",
        attributes=["distinguishedName"])}
    out = [{"account": str(get_attr(m, "sAMAccountName", ""))} for m in members if str(get_attr(m, "distinguishedName", "")) not in protected_dns]
    status = Status.TRIGGERED if len(out) >= 2 else Status.CLEAN  # PingCastle allows 1 exception
    return Finding("P-ProtectedUsers", CATEGORY, "AccountTakeOver",
                    "Privileged accounts outside Protected Users group", status,
                    f"{len(out)} privileged account(s) not in Protected Users.", out)


@rule("P-DisplaySpecifier", CATEGORY, "AccountTakeOver", "Admin UI customization scripts stored outside SYSVOL")
def r_display_specifier(ctx) -> Finding:
    entries = ctx.search(f"CN=DisplaySpecifiers,{ctx.config_nc}", "(adminContextMenu=*)",
                          attributes=["adminContextMenu", "distinguishedName"])
    # adminContextMenu is "order,name,path". PingCastle inspects field [2] and
    # flags it when it is a UNC path (contains \\\\) -- i.e. an admin-console script
    # loaded from a remote share. The previous logic flagged anything not
    # containing "sysvol", which both missed local-path abuse and fired on
    # perfectly normal non-UNC entries.
    out = []
    for e in entries:
        for v in get_attr_list(e, "adminContextMenu"):
            parts = str(v).split(",")
            if len(parts) < 3:
                continue
            path = parts[2].strip().strip('"')
            if "\\\\" in path:
                out.append({"dn": str(get_attr(e, "distinguishedName", "")), "path": path})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DisplaySpecifier", CATEGORY, "AccountTakeOver",
                    "Admin UI customization scripts stored outside SYSVOL", status,
                    f"{len(out)} adminContextMenu entr(y/ies) reference a path outside SYSVOL.", out)


@rule("P-LogonDenied", CATEGORY, "AccountTakeOver", "No tier-isolation deny-logon GPO for Domain Admins",
      requires=("ldap", "smb"))
def r_logon_denied(ctx) -> Finding:
    from .. import gpo as gpomod
    domain_admins_sid = f"{ctx.domain_sid}-512"
    gpos = gpomod.list_gpos(ctx)
    hits = []
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        priv = tmpl.get("Privilege Rights", {})
        for right in ("SeDenyInteractiveLogonRight", "SeDenyRemoteInteractiveLogonRight"):
            v = priv.get(right, "")
            if v and domain_admins_sid.lower() in v.lower():
                hits.append({"gpo": g.display_name, "right": right})
    status = Status.CLEAN if hits else Status.TRIGGERED
    return Finding("P-LogonDenied", CATEGORY, "AccountTakeOver",
                    "No tier-isolation deny-logon GPO for Domain Admins", status,
                    f"{len(hits)} GPO right(s) deny interactive/remote-interactive logon to Domain Admins "
                    "(tier isolation)." if hits else
                    "No GPO denies interactive/remote-interactive logon rights for Domain Admins anywhere "
                    "(no evidence of tier isolation preventing admin logon to lower-tier systems).", hits)


def _get_sd(ctx, dn):
    entries = ctx.search_with_sd(dn, "(objectClass=*)", attributes=["distinguishedName"], scope="BASE")
    if not entries:
        return None
    raw = ctx.get_raw_sd_bytes(entries[0])
    if raw is None:
        return None
    return parse_security_descriptor(raw)


def _is_expected_privileged(sid, domain_sid=None):
    """Domain-aware wrapper. A privileged RID only counts as 'expected' when the
    SID actually belongs to the audited domain -- a FOREIGN domain's RID-512
    group holding rights here is a real finding, not something to skip."""
    return _acl_is_expected_privileged(sid, domain_sid)


@rule("P-DCOwner", CATEGORY, "ACLCheck", "Domain Controller object not owned by a privileged group")
def r_dc_owner(ctx) -> Finding:
    entries = ctx.search_with_sd(ctx.base_dn, "(&(objectCategory=computer)(primaryGroupID=516))",
                                  attributes=["sAMAccountName"])
    out = []
    for e in entries:
        raw = ctx.get_raw_sd_bytes(e)
        if not raw:
            continue
        sd = parse_security_descriptor(raw)
        if sd.owner_sid and not _is_expected_privileged(sd.owner_sid, ctx.domain_sid):
            out.append({"account": str(get_attr(e, "sAMAccountName", "")), "owner": sd.owner_sid})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DCOwner", CATEGORY, "ACLCheck", "Domain Controller object not owned by a privileged group",
                    status, f"{len(out)} DC object(s) with an unexpected ACL owner.", out)


@rule("P-DNSAdmin", CATEGORY, "ACLCheck", "DNSAdmins group has members")
def r_dns_admin(ctx) -> Finding:
    """PingCastle DEACTIVATED this rule upstream -- its body is now literally
    `// rule is not active anymore  return 0;`, so it never fires there. The
    DNSAdmins DLL-injection path was mitigated by Microsoft, and membership
    alone is no longer treated as a finding.

    We keep the enumeration because it is useful review context, but report it
    as NOT_APPLICABLE rather than TRIGGERED so it does not create a finding
    PingCastle itself would not raise.
    """
    entries = ctx.search(f"CN=Users,{ctx.base_dn}", "(cn=DnsAdmins)", attributes=["member"])
    members = get_attr_list(entries[0], "member") if entries else []
    return Finding("P-DNSAdmin", CATEGORY, "ACLCheck", "DNSAdmins group has members",
                    Status.NOT_APPLICABLE,
                    f"{len(members)} member(s) in DnsAdmins. Reported for context only: PingCastle "
                    "deactivated this rule, so this is not scored as a finding.",
                    [{"member_dn": m} for m in members])


@rule("P-DangerousExtendedRight", CATEGORY, "ACLCheck", "Dangerous extended rights delegated to non-admins")
def r_dangerous_extended_right(ctx) -> Finding:
    dangerous_guids = {
        "45ec5156-db7e-47bb-b53f-dbeb2d03c40f": "Reanimate-Tombstone",
        "ccc2dc7d-a6ad-4a7a-8846-c04e3cc53501": "Unexpire-Password",
    }
    sd = _get_sd(ctx, ctx.base_dn)
    out = []
    if sd:
        for ace in sd.dacl:
            if ace.is_allow and ace.object_type in dangerous_guids and not _is_expected_privileged(ace.trustee_sid, ctx.domain_sid):
                out.append({"trustee_sid": ace.trustee_sid, "right": dangerous_guids[ace.object_type]})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DangerousExtendedRight", CATEGORY, "ACLCheck",
                    "Dangerous extended rights delegated to non-admins", status,
                    f"{len(out)} non-admin trustee(s) hold a dangerous extended right at the domain root.", out)


@rule("P-DelegationKeyAdmin", CATEGORY, "ACLCheck",
      "Enterprise Key Admins holds a delegation on the domain root")
def r_delegation_key_admin(ctx) -> Finding:
    """Upstream this checks for a delegation ACE on the DOMAIN ROOT whose
    trustee SID ends in -527 (Enterprise Key Admins) -- not group membership.
    The previous implementation enumerated Key Admins / Enterprise Key Admins
    membership, which is a different (and much noisier) question: those groups
    having members is normal, whereas them holding rights over the domain root
    is the Shadow-Credentials-adjacent misconfiguration worth reporting.
    """
    out = [d for d in _enumerate_delegations(ctx)
           if d.get("dn", "").upper().startswith("DC=") and d.get("trustee_sid", "").endswith("-527")]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DelegationKeyAdmin", CATEGORY, "ACLCheck",
                    "Enterprise Key Admins holds a delegation on the domain root", status,
                    f"{len(out)} delegation(s) grant Enterprise Key Admins (RID 527) dangerous rights "
                    "over the domain root object -- a path to writing msDS-KeyCredentialLink on "
                    "privileged accounts (Shadow Credentials).", out)


@rule("P-DsHeuristicsAdminSDExMask", CATEGORY, "ACLCheck", "AdminSDHolder exclusion mask modified")
def r_ds_heuristics_adminsd(ctx) -> Finding:
    entries = ctx.search(f"CN=Directory Service,CN=Windows NT,CN=Services,{ctx.config_nc}",
                          "(objectClass=*)", attributes=["dSHeuristics"])
    val = get_attr(entries[0], "dSHeuristics") if entries else None
    # AdminSDHolder exclusion mask is character 16 (0-based index 15), NOT index 2.
    # Index 2 is dsHeuristicsDoListObject -- the two rules had their positions crossed.
    modified = bool(val) and len(str(val)) >= 16 and str(val)[15] != "0"
    status = Status.TRIGGERED if modified else Status.CLEAN
    return Finding("P-DsHeuristicsAdminSDExMask", CATEGORY, "ACLCheck", "AdminSDHolder exclusion mask modified",
                    status, f"dSHeuristics = {val!r}.")


@rule("P-DsHeuristicsDoListObject", CATEGORY, "ACLCheck", "dSHeuristics List Object mode changed")
def r_ds_heuristics_list_object(ctx) -> Finding:
    entries = ctx.search(f"CN=Directory Service,CN=Windows NT,CN=Services,{ctx.config_nc}",
                          "(objectClass=*)", attributes=["dSHeuristics"])
    val = get_attr(entries[0], "dSHeuristics") if entries else None
    # List Object mode is character 3 (0-based index 2), NOT index 9.
    changed = bool(val) and len(str(val)) >= 3 and str(val)[2] != "0"
    status = Status.TRIGGERED if changed else Status.CLEAN
    return Finding("P-DsHeuristicsDoListObject", CATEGORY, "ACLCheck", "dSHeuristics List Object mode changed",
                    status, f"dSHeuristics = {val!r}.")


@rule("P-LoginDCEveryone", CATEGORY, "ACLCheck", "Broad group granted direct logon rights on DCs",
      requires=("ldap", "smb"))
def r_login_dc_everyone(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    out = []
    broad_names = ("everyone", "authenticated users", "domain users")
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        priv = tmpl.get("Privilege Rights", {})
        for k, v in priv.items():
            if k.lower() == "seinteractivelogonright" and any(b in v.lower() for b in broad_names):
                out.append({"gpo": g.display_name, "value": v})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-LoginDCEveryone", CATEGORY, "ACLCheck", "Broad group granted direct logon rights on DCs",
                    status, f"{len(out)} GPO(s) grant SeInteractiveLogonRight to a broad group.", out)


@rule("P-DNSDelegation", CATEGORY, "ACLCheck", "DNS application-partition ACL grants excessive rights")
def r_dns_delegation(ctx) -> Finding:
    out = []
    for base in (f"DC=DomainDnsZones,{ctx.base_dn}", f"DC=ForestDnsZones,{ctx.base_dn}"):
        try:
            entries = ctx.search_with_sd(base, "(objectClass=domainDNS)", attributes=["distinguishedName"], scope="BASE")
        except Exception:
            continue  # partition may not exist (e.g. ForestDnsZones on some setups) -- not an error
        if not entries:
            continue
        raw = ctx.get_raw_sd_bytes(entries[0])
        if not raw:
            continue
        sd = parse_security_descriptor(raw)
        for hit in effective_dangerous_aces(sd, ctx.domain_sid, skip_expected_privileged=True):
            if is_broad_trustee(hit["trustee_sid"], ctx.domain_sid):
                out.append({"partition": base, **hit})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DNSDelegation", CATEGORY, "ACLCheck",
                    "DNS application-partition ACL grants excessive rights", status,
                    f"{len(out)} DNS application-partition object(s) grant a broad principal (Everyone/"
                    "Authenticated Users/Domain Users) dangerous rights. This checks the partition container's "
                    "own ACL only; per-record dnsNode ACL sampling across every DNS record is not performed.", out)


not_implemented("P-DelegationFileDeployed", CATEGORY, "ACLCheck", "Delegated file deployment writable by non-admins",
                 "Requires walking arbitrary file-deployment mechanisms (e.g. software installation GPOs) and "
                 "checking NTFS ACLs over SMB; out of scope for a first pass.", requires=("ldap", "smb"))


@rule("P-DelegationGPOData", CATEGORY, "ACLCheck", "GPO AD object writable by a non-admin")
def r_delegation_gpo_data(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    out = []
    malformed = 0
    for g in gpos:
        gpo_dn = f"CN={g.gpo_id},CN=Policies,CN=System,{ctx.base_dn}"
        try:
            entries = ctx.search_with_sd(gpo_dn, "(objectClass=groupPolicyContainer)", attributes=["distinguishedName"], scope="BASE")
        except Exception:
            continue
        if not entries:
            continue
        raw = ctx.get_raw_sd_bytes(entries[0])
        if not raw:
            continue
        sd = parse_security_descriptor(raw)
        if sd.malformed_ace_count:
            malformed += sd.malformed_ace_count
        for hit in effective_dangerous_aces(sd, ctx.domain_sid):
            out.append({"gpo": g.display_name, **hit})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DelegationGPOData", CATEGORY, "ACLCheck", "GPO AD object writable by a non-admin", status,
                    f"{len(out)} GPO(s) grant a non-admin principal write-level rights on the GPO's AD object. "
                    "Note: this proxies the SYSVOL NTFS ACL check via the AD object ACL -- GPMC keeps the two in "
                    "sync under normal delegation, so this catches the common case, but won't catch SYSVOL "
                    "permissions tampered with directly at the filesystem level, bypassing GPMC.", out)


@rule("P-DelegationLoginScript", CATEGORY, "ACLCheck", "Privileged account logon script writable by non-admins",
      requires=("ldap", "smb"))
def r_delegation_login_script(ctx) -> Finding:
    from ..smb_acl import get_smb_file_security_descriptor
    members = _privileged_accounts(ctx)
    checked = 0
    errors = 0
    out = []
    for m in members:
        script = m["scriptPath"].value if "scriptPath" in m and m["scriptPath"].value else None
        if not script:
            continue
        path = str(script).replace("/", "\\").lstrip("\\")  # relative to the NETLOGON share
        raw = get_smb_file_security_descriptor(ctx, "NETLOGON", path)
        if raw is None:
            errors += 1
            continue
        checked += 1
        sd = parse_security_descriptor(raw)
        for hit in effective_dangerous_aces(sd, ctx.domain_sid):
            out.append({"account": str(get_attr(m, "sAMAccountName", "")), "script": str(script), **hit})
    if checked == 0 and errors > 0:
        return Finding("P-DelegationLoginScript", CATEGORY, "ACLCheck",
                        "Privileged account logon script writable by non-admins", Status.ERROR,
                        f"Found {errors} privileged account(s) with a scriptPath set, but could not retrieve the "
                        "NTFS security descriptor for any of them over SMB (SMB dialect below SMB2, permissions, "
                        "or path issue). Not reporting Clean, since that would risk masking a real finding -- "
                        "verify manually with `icacls \\\\<dc>\\NETLOGON\\<script>`.")
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DelegationLoginScript", CATEGORY, "ACLCheck",
                    "Privileged account logon script writable by non-admins", status,
                    f"Checked {checked} logon script(s) referenced by privileged accounts "
                    f"({errors} could not be checked); {len(out)} finding(s) of non-admin write-level NTFS access.",
                    out)


def _domain_root_sd(ctx):
    if "domain_root_sd" in ctx._cache:
        return ctx._cache["domain_root_sd"]
    entries = ctx.search_with_sd(ctx.base_dn, "(objectClass=domainDNS)", attributes=["distinguishedName"], scope="BASE")
    sd = None
    if entries:
        raw = ctx.get_raw_sd_bytes(entries[0])
        if raw:
            sd = parse_security_descriptor(raw)
    ctx._cache["domain_root_sd"] = sd
    return sd


@rule("P-ExchangeAdminSDHolder", CATEGORY, "ACLCheck", "Exchange group holds dangerous rights on AdminSDHolder")
def r_exchange_adminsdholder(ctx) -> Finding:
    exch_group = ctx.search(ctx.base_dn, "(cn=Exchange Windows Permissions)", attributes=["objectSid"])
    if not exch_group:
        return Finding("P-ExchangeAdminSDHolder", CATEGORY, "ACLCheck",
                        "Exchange group holds dangerous rights on AdminSDHolder", Status.NOT_APPLICABLE,
                        "No 'Exchange Windows Permissions' group found; Exchange does not appear to be/have been "
                        "installed in this domain.")
    raw = exch_group[0]["objectSid"].raw_values
    exch_sid = bin_sid_to_str(raw[0]) if raw else None
    dn = f"CN=AdminSDHolder,CN=System,{ctx.base_dn}"
    entries = ctx.search_with_sd(dn, "(objectClass=*)", attributes=["distinguishedName"], scope="BASE")
    out = []
    if entries:
        sdraw = ctx.get_raw_sd_bytes(entries[0])
        if sdraw:
            sd = parse_security_descriptor(sdraw)
            for ace in sd.dacl:
                if ace.is_allow and ace.trustee_sid == exch_sid and (ace.mask & DANGEROUS_RIGHTS_MASK_EXTENDED):
                    out.append({"trustee": "Exchange Windows Permissions", "mask": hex(ace.mask)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-ExchangeAdminSDHolder", CATEGORY, "ACLCheck",
                    "Exchange group holds dangerous rights on AdminSDHolder", status,
                    f"{len(out)} dangerous ACE(s) held by 'Exchange Windows Permissions' on AdminSDHolder "
                    "(this group's membership is often loosely controlled, so broad rights here are a known "
                    "escalation path -- CVE-2019-1040-adjacent research).", out)


@rule("P-ExchangePrivEsc", CATEGORY, "ACLCheck", "Exchange group holds dangerous rights on the domain root")
def r_exchange_privesc(ctx) -> Finding:
    exch_group = ctx.search(ctx.base_dn, "(cn=Exchange Windows Permissions)", attributes=["objectSid"])
    if not exch_group:
        return Finding("P-ExchangePrivEsc", CATEGORY, "ACLCheck",
                        "Exchange group holds dangerous rights on the domain root", Status.NOT_APPLICABLE,
                        "No 'Exchange Windows Permissions' group found; Exchange does not appear to be/have been "
                        "installed in this domain.")
    raw = exch_group[0]["objectSid"].raw_values
    exch_sid = bin_sid_to_str(raw[0]) if raw else None
    sd = _domain_root_sd(ctx)
    out = []
    if sd:
        for ace in sd.dacl:
            if ace.is_allow and ace.trustee_sid == exch_sid and (ace.mask & DANGEROUS_RIGHTS_MASK_EXTENDED):
                out.append({"trustee": "Exchange Windows Permissions", "mask": hex(ace.mask)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-ExchangePrivEsc", CATEGORY, "ACLCheck",
                    "Exchange group holds dangerous rights on the domain root", status,
                    f"{len(out)} dangerous ACE(s) held by 'Exchange Windows Permissions' on the domain root object "
                    "(the classic pre-2019-patch Exchange privilege-escalation chain: WriteDacl on the domain, "
                    "combined with loose membership control of this group, allows escalation to Domain Admin).",
                    out)


not_implemented("P-RecoveryModeUnprotected", CATEGORY, "ACLCheck", "DSRM local admin not hardened",
                 "DSRM behavior lives in DC-local registry (not LDAP/SYSVOL); needs WMI/remote registry access to "
                 "each DC, which requires local admin rights on that host -- out of scope for a directory-read-only "
                 "account.")


def _dc_delegation_scan(ctx):
    """Domain Controllers carrying any form of Kerberos delegation config.

    PingCastle splits this three ways by delegation TYPE, and all three were
    previously mapped to the wrong attribute here:
      * a2d2        -> msDS-AllowedToDelegateTo WITHOUT protocol transition
      * t2a4d       -> msDS-AllowedToDelegateTo WITH protocol transition
                       (TRUSTED_TO_AUTH_FOR_DELEGATION set)
      * sourcedeleg -> msDS-AllowedToActOnBehalfOfOtherIdentity (RBCD on the DC)
    """
    if "dc_deleg" in ctx._cache:
        return ctx._cache["dc_deleg"]
    entries = ctx.search(ctx.base_dn,
                          "(&(objectCategory=computer)(|(primaryGroupID=516)(primaryGroupID=521)))",
                          attributes=["sAMAccountName", "userAccountControl",
                                      "msDS-AllowedToDelegateTo",
                                      "msDS-AllowedToActOnBehalfOfOtherIdentity"])
    scan = []
    for e in entries:
        uac = int(get_attr(e, "userAccountControl", 0) or 0)
        scan.append({
            "account": str(get_attr(e, "sAMAccountName", "")),
            "targets": [str(t) for t in get_attr_list(e, "msDS-AllowedToDelegateTo")],
            "protocol_transition": bool(uac & UAC_TRUSTED_TO_AUTH_FOR_DELEGATION),
            "has_rbcd": bool(get_attr(e, "msDS-AllowedToActOnBehalfOfOtherIdentity")),
        })
    ctx._cache["dc_deleg"] = scan
    return scan


def _enumerate_delegations(ctx):
    """PingCastle's "Delegations" collection: dangerous ACEs (GenericAll,
    WriteDacl, WriteOwner, GenericWrite) granted on OU / container /
    domain-root / builtinDomain objects, plus the Configuration NC root.

    This is a DIFFERENT thing from resource-based constrained delegation
    (msDS-AllowedToActOnBehalfOfOtherIdentity); two rules previously conflated
    the two and inspected RBCD instead of object ACLs.
    """
    if "delegations" in ctx._cache:
        return ctx._cache["delegations"]
    results = []
    scopes = [
        (ctx.base_dn,
         "(|(objectCategory=organizationalUnit)(objectCategory=container)"
         "(objectCategory=domain)(objectCategory=builtinDomain))", "SUBTREE"),
        (ctx.config_nc, "(objectCategory=configuration)", "BASE"),
    ]
    for base, filt, scope in scopes:
        try:
            entries = ctx.search_with_sd(base, filt, attributes=["distinguishedName"], scope=scope)
        except Exception:
            continue
        for e in entries:
            raw = ctx.get_raw_sd_bytes(e)
            if not raw:
                continue
            sd = parse_security_descriptor(raw)
            dn = str(get_attr(e, "distinguishedName", ""))
            for hit in effective_dangerous_aces(sd, ctx.domain_sid, mask=DANGEROUS_RIGHTS_MASK):
                results.append({"dn": dn, **hit})
    ctx._cache["delegations"] = results
    return results


@rule("P-DelegationDCa2d2", CATEGORY, "DelegationCheck",
      "DC has constrained delegation without protocol transition")
def r_delegation_dc_a2d2(ctx) -> Finding:
    out = [{"account": d["account"], "targets": d["targets"]}
           for d in _dc_delegation_scan(ctx) if d["targets"] and not d["protocol_transition"]]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DelegationDCa2d2", CATEGORY, "DelegationCheck",
                    "DC has constrained delegation without protocol transition", status,
                    f"{len(out)} DC(s) have msDS-AllowedToDelegateTo set without "
                    "TRUSTED_TO_AUTH_FOR_DELEGATION (Kerberos-only constrained delegation).", out)


@rule("P-DelegationDCt2a4d", CATEGORY, "DelegationCheck",
      "DC has constrained delegation with protocol transition")
def r_delegation_dc_t2a4d(ctx) -> Finding:
    out = [{"account": d["account"], "targets": d["targets"]}
           for d in _dc_delegation_scan(ctx) if d["targets"] and d["protocol_transition"]]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DelegationDCt2a4d", CATEGORY, "DelegationCheck",
                    "DC has constrained delegation with protocol transition", status,
                    f"{len(out)} DC(s) have msDS-AllowedToDelegateTo set WITH "
                    "TRUSTED_TO_AUTH_FOR_DELEGATION -- protocol transition lets the DC obtain "
                    "tickets for arbitrary users to the delegated service.", out)


@rule("P-DelegationDCsourcedeleg", CATEGORY, "DelegationCheck",
      "DC is configured as a resource-based delegation target")
def r_delegation_dc_source_deleg(ctx) -> Finding:
    out = [{"account": d["account"]} for d in _dc_delegation_scan(ctx) if d["has_rbcd"]]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DelegationDCsourcedeleg", CATEGORY, "DelegationCheck",
                    "DC is configured as a resource-based delegation target", status,
                    f"{len(out)} DC(s) have msDS-AllowedToActOnBehalfOfOtherIdentity set, letting the "
                    "listed principals act on behalf of others against the DC itself.", out)


@rule("P-DelegationEveryone", CATEGORY, "DelegationCheck",
      "A broad group holds a delegation on an OU/container/domain object")
def r_delegation_everyone(ctx) -> Finding:
    """Upstream this inspects OBJECT delegations (dangerous ACEs on OUs,
    containers and the domain root) whose trustee is an everyone-equivalent
    principal. It previously checked msDS-AllowedToActOnBehalfOfOtherIdentity
    (resource-based constrained delegation) -- a completely different subject,
    so this rule was neither finding what it should nor reporting what it
    claimed.
    """
    broad_exact = {"S-1-1-0", "S-1-5-11", "S-1-5-7", "S-1-5-32-545"}
    out = []
    for d in _enumerate_delegations(ctx):
        sid = d.get("trustee_sid", "")
        if sid in broad_exact or sid.endswith("-513") or sid.endswith("-515"):
            out.append(d)
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-DelegationEveryone", CATEGORY, "DelegationCheck",
                    "A broad group holds a delegation on an OU/container/domain object", status,
                    f"{len(out)} delegation(s) grant Everyone / Authenticated Users / Anonymous / "
                    "BUILTIN Users / Domain Users / Domain Computers dangerous rights over a "
                    "container object.", out[:200])


@rule("P-UnconstrainedDelegation", CATEGORY, "DelegationCheck", "Non-DC account with unconstrained delegation")
def r_unconstrained_delegation(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn,
                          f"(&(!(primaryGroupID=516))(!(primaryGroupID=521))"
                          f"(userAccountControl:1.2.840.113556.1.4.803:={UAC_TRUSTED_FOR_DELEGATION}))",
                          attributes=["sAMAccountName", "objectClass"])
    out = [{"account": str(get_attr(e, "sAMAccountName", "")), "type": "computer" if "computer" in get_attr_list(e, "objectClass") else "user"}
           for e in entries]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-UnconstrainedDelegation", CATEGORY, "DelegationCheck",
                    "Non-DC account with unconstrained delegation", status,
                    f"{len(out)} non-DC account(s) configured for unconstrained delegation.", out)


@rule("P-UnkownDelegation", CATEGORY, "DelegationCheck", "Delegation target SPN cannot be resolved")
def r_unknown_delegation(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(msDS-AllowedToDelegateTo=*)",
                          attributes=["sAMAccountName", "msDS-AllowedToDelegateTo"])
    # Resolve every host ONCE up front instead of issuing an LDAP search per SPN
    # (previously O(number of delegation targets) round-trips against the DC).
    known_hosts = set()
    for h in ctx.search(ctx.base_dn, "(dNSHostName=*)", attributes=["dNSHostName"]):
        v = get_attr(h, "dNSHostName")
        if v:
            known_hosts.add(str(v).lower())
    out = []
    for e in entries:
        for target in get_attr_list(e, "msDS-AllowedToDelegateTo"):
            spn_service_host = str(target).split("/", 1)
            if len(spn_service_host) != 2:
                continue
            host = spn_service_host[1].split(":")[0].split("/")[0].lower()
            if host not in known_hosts:
                out.append({"account": str(get_attr(e, "sAMAccountName", "")), "unresolved_target": str(target)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-UnkownDelegation", CATEGORY, "DelegationCheck", "Delegation target SPN cannot be resolved",
                    status, f"{len(out)} delegation target(s) point at a host that no longer exists in AD.", out)


@rule("P-RecycleBin", CATEGORY, "IrreversibleChange", "AD Recycle Bin not enabled")
def r_recycle_bin(ctx) -> Finding:
    # Attribute is msDS-EnabledFeature (not ...BL) and it lives on the Partitions
    # container itself, read at BASE scope -- matching PingCastle's own collector.
    partitions_dn = f"CN=Partitions,{ctx.config_nc}"
    entries = ctx.search(partitions_dn, "(objectClass=*)", scope="BASE",
                          attributes=["msDS-EnabledFeature"])
    enabled = False
    if entries:
        for v in get_attr_list(entries[0], "msDS-EnabledFeature"):
            if "recycle bin" in str(v).lower():
                enabled = True
    status = Status.CLEAN if enabled else Status.TRIGGERED
    return Finding("P-RecycleBin", CATEGORY, "IrreversibleChange", "AD Recycle Bin not enabled", status,
                    "Recycle Bin optional feature is enabled." if enabled else "Recycle Bin optional feature is NOT enabled.")


@rule("P-SchemaAdmin", CATEGORY, "IrreversibleChange", "Schema Admins group has active members")
def r_schema_admin(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, f"(objectSid={ctx.domain_sid}-518)", attributes=["member"])
    members = get_attr_list(entries[0], "member") if entries else []
    status = Status.TRIGGERED if members else Status.CLEAN
    return Finding("P-SchemaAdmin", CATEGORY, "IrreversibleChange", "Schema Admins group has active members",
                    status, f"{len(members)} member(s) in Schema Admins (should normally be empty).",
                    [{"member_dn": m} for m in members])


@rule("P-UnprotectedOU", CATEGORY, "IrreversibleChange", "OU not protected from accidental deletion")
def r_unprotected_ou(ctx) -> Finding:
    entries = ctx.search_with_sd(ctx.base_dn, "(objectClass=organizationalUnit)", attributes=["distinguishedName"])
    out = []
    for e in entries:
        raw = ctx.get_raw_sd_bytes(e)
        if not raw:
            continue
        sd = parse_security_descriptor(raw)
        protected = any(
            not ace.is_allow and ace.trustee_sid == EVERYONE
            and (ace.mask & (ACCESS_MASK["DELETE"] | ACCESS_MASK["DELETE_CHILD"] if "DELETE_CHILD" in ACCESS_MASK else ACCESS_MASK["DELETE"]))
            for ace in sd.dacl
        )
        if not protected:
            out.append({"ou": str(get_attr(e, "distinguishedName", ""))})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-UnprotectedOU", CATEGORY, "IrreversibleChange", "OU not protected from accidental deletion",
                    status, f"{len(out)} OU(s) lack the 'protect from accidental deletion' deny-ACE.", out[:200])


@rule("P-PrivilegeEveryone", CATEGORY, "PrivilegeControl", "Dangerous user right assigned to a broad group",
      requires=("ldap", "smb"))
def r_privilege_everyone(ctx) -> Finding:
    from .. import gpo as gpomod
    dangerous_privileges = [
        "SeLoadDriverPrivilege", "SeTcbPrivilege", "SeDebugPrivilege", "SeRestorePrivilege",
        "SeBackupPrivilege", "SeTakeOwnershipPrivilege", "SeCreateTokenPrivilege",
        "SeImpersonatePrivilege", "SeAssignPrimaryTokenPrivilege",
    ]
    broad_names = ("everyone", "authenticated users", "domain users", "s-1-1-0", "s-1-5-11")
    gpos = gpomod.list_gpos(ctx)
    out = []
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        priv = tmpl.get("Privilege Rights", {})
        for k, v in priv.items():
            if k in dangerous_privileges and any(b in v.lower() for b in broad_names):
                out.append({"gpo": g.display_name, "privilege": k, "value": v})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-PrivilegeEveryone", CATEGORY, "PrivilegeControl",
                    "Dangerous user right assigned to a broad group", status,
                    f"{len(out)} GPO(s) assign a dangerous privilege to a broad group.", out)


@rule("P-TrustedCredManAccessPrivilege", CATEGORY, "PrivilegeControl", "Credential Manager trusted-access right too broad",
      requires=("ldap", "smb"))
def r_trusted_credman(ctx) -> Finding:
    from .. import gpo as gpomod
    broad_names = ("everyone", "authenticated users", "domain users")
    gpos = gpomod.list_gpos(ctx)
    out = []
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        priv = tmpl.get("Privilege Rights", {})
        v = priv.get("SeTrustedCredManAccessPrivilege", "")
        if v and any(b in v.lower() for b in broad_names):
            out.append({"gpo": g.display_name, "value": v})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-TrustedCredManAccessPrivilege", CATEGORY, "PrivilegeControl",
                    "Credential Manager trusted-access right too broad", status,
                    f"{len(out)} GPO(s) grant SeTrustedCredManAccessPrivilege broadly.", out)


not_implemented("P-ServiceDomainAdmin", CATEGORY, "PrivilegeControl", "A service runs using Domain Admin credentials",
                 "Requires enumerating installed services via SCM/WMI on every host, which needs local admin "
                 "rights per-host -- out of scope for a directory-read-only account.")

@rule("P-AdminEmailOn", CATEGORY, "ControlPath", "Privileged account has an email attribute set")
def r_admin_email_on(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn,
                          f"(&(objectCategory=person)(objectClass=user)(adminCount=1)(mail=*)"
                          f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))",
                          attributes=["sAMAccountName", "mail"])
    out = [{"account": str(get_attr(e, "sAMAccountName", "")), "mail": str(get_attr(e, "mail", ""))} for e in entries]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-AdminEmailOn", CATEGORY, "ControlPath", "Privileged account has an email attribute set",
                    status, f"{len(out)} adminCount=1 account(s) have a mail attribute set "
                    "(phishing/OSINT exposure for a privileged identity).", out)


def _transitive_member(ctx, group_dn, candidate_dn):
    """True if candidate_dn is a member of group_dn, directly or nested, via the
    LDAP_MATCHING_RULE_IN_CHAIN transitive operator (a normal, read-only search)."""
    entries = ctx.search(group_dn, f"(member:1.2.840.113556.1.4.1941:={candidate_dn})",
                          attributes=["distinguishedName"], scope="BASE")
    return bool(entries)


def _broad_group_privileged_paths(ctx):
    """Nested-membership-only check: does a broad, everyone-equivalent group
    (Domain Users) sit inside a privileged group's transitive membership?
    This covers ONE class of indirect control path (nested group membership);
    it does not cover ACL-based indirect paths (WriteDacl/GenericAll chains
    several hops deep), which need a full BloodHound-style graph traversal
    that is out of scope for this pass."""
    if "broad_priv_paths" in ctx._cache:
        return ctx._cache["broad_priv_paths"]
    domain_users = ctx.search(ctx.base_dn, f"(objectSid={ctx.domain_sid}-513)", attributes=["distinguishedName"])
    broad_dn = str(domain_users[0]["distinguishedName"]) if domain_users else None
    targets = []
    for rid, name in ((512, "Domain Admins"), (519, "Enterprise Admins"), (518, "Schema Admins")):
        e = ctx.search(ctx.base_dn, f"(objectSid={ctx.domain_sid}-{rid})", attributes=["distinguishedName"])
        if e:
            targets.append((name, str(e[0]["distinguishedName"])))
    admins = ctx.search(f"CN=Administrators,CN=Builtin,{ctx.base_dn}", "(cn=Administrators)",
                         attributes=["distinguishedName"])
    if admins:
        targets.append(("Administrators (BUILTIN)", str(admins[0]["distinguishedName"])))

    out = []
    if broad_dn:
        for name, gdn in targets:
            if _transitive_member(ctx, gdn, broad_dn):
                out.append({"broad_group": "Domain Users", "privileged_group": name})
    ctx._cache["broad_priv_paths"] = out
    return out


@rule("P-ControlPathIndirectEveryone", CATEGORY, "ControlPath",
      "Broad group has an indirect (nested-membership) path to a privileged group")
def r_control_path_indirect_everyone(ctx) -> Finding:
    out = _broad_group_privileged_paths(ctx)
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-ControlPathIndirectEveryone", CATEGORY, "ControlPath",
                    "Broad group has an indirect (nested-membership) path to a privileged group", status,
                    f"{len(out)} case(s) where Domain Users is nested (directly or transitively) inside a "
                    "privileged group. Scope note: this covers nested-group-membership paths only, not "
                    "ACL-based indirect paths (WriteDacl/GenericAll chains) -- a full BloodHound-style graph "
                    "traversal would be needed to also cover those.", out)


@rule("P-ControlPathIndirectMany", CATEGORY, "ControlPath",
      "Multiple indirect (nested-membership) paths reach privileged groups")
def r_control_path_indirect_many(ctx) -> Finding:
    out = _broad_group_privileged_paths(ctx)
    status = Status.TRIGGERED if len(out) >= 2 else Status.CLEAN
    return Finding("P-ControlPathIndirectMany", CATEGORY, "ControlPath",
                    "Multiple indirect (nested-membership) paths reach privileged groups", status,
                    f"{len(out)} privileged group(s) reachable from Domain Users via nested membership "
                    "(threshold: 2+). Same nested-membership-only scope note as P-ControlPathIndirectEveryone.",
                    out)

# ---------------------------------------------------------------------------
# Read-Only Domain Controllers
# ---------------------------------------------------------------------------

def _rodc_list(ctx):
    return ctx.search(ctx.base_dn, "(&(objectCategory=computer)(primaryGroupID=521))",
                       attributes=["sAMAccountName", "msDS-RevealOnDemandGroup", "msDS-NeverRevealGroup",
                                   "msDS-RevealedUsers", "distinguishedName", "dNSHostName"])


@rule("P-RODCAllowedGroup", CATEGORY, "RODC", "RODC allowed-to-replicate list includes unexpected groups")
def r_rodc_allowed_group(ctx) -> Finding:
    out = []
    for r in _rodc_list(ctx):
        allowed = get_attr_list(r, "msDS-RevealOnDemandGroup")
        unexpected = [a for a in allowed if not any(x in a.lower() for x in ("rodc", "allowed"))]
        if unexpected:
            out.append({"rodc": str(get_attr(r, "sAMAccountName", "")), "unexpected": unexpected})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-RODCAllowedGroup", CATEGORY, "RODC",
                    "RODC allowed-to-replicate list includes unexpected groups", status,
                    f"{len(out)} RODC(s) with unexpected entries in the allowed-replication list.", out)


@rule("P-RODCDeniedGroup", CATEGORY, "RODC", "RODC denied-replication list missing expected privileged groups")
def r_rodc_denied_group(ctx) -> Finding:
    out = []
    for r in _rodc_list(ctx):
        denied_text = " ".join(get_attr_list(r, "msDS-NeverRevealGroup")).lower()
        missing = [g for g in ("domain admins", "enterprise admins", "schema admins", "administrators")
                   if g not in denied_text]
        if missing:
            out.append({"rodc": str(get_attr(r, "sAMAccountName", "")), "missing_from_deny_list": missing})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-RODCDeniedGroup", CATEGORY, "RODC",
                    "RODC denied-replication list missing expected privileged groups", status,
                    f"{len(out)} RODC(s) missing an expected privileged group from the deny list.", out)


rule("P-RODCNeverReveal", CATEGORY, "RODC", "RODC never-reveal policy incomplete (alias of P-RODCDeniedGroup)")(
    r_rodc_denied_group)


@rule("P-RODCAdminRevealed", CATEGORY, "RODC", "A privileged account's password was cached to an RODC")
def r_rodc_admin_revealed(ctx) -> Finding:
    info = ctx.conn.server.info.other if ctx.conn.server.info else {}
    try:
        if int(info.get("domainFunctionality", ["0"])[0]) < 3:
            return Finding("P-RODCAdminRevealed", CATEGORY, "RODC", "A privileged account's password was cached to an RODC", Status.NOT_APPLICABLE,
                            "Domain functional level is below Windows 2008; RODCs are not supported.")
    except (TypeError, ValueError):
        pass
    priv_dns = {str(get_attr(m, "distinguishedName", "")) for m in _privileged_accounts(ctx)}
    out = []
    for r in _rodc_list(ctx):
        revealed = get_attr_list(r, "msDS-RevealedUsers")
        for entry in revealed:
            # msDS-RevealedUsers values are binary; here we only get a DN-ish repr in most ldap3 configs
            for pdn in priv_dns:
                if pdn.lower() in str(entry).lower():
                    out.append({"rodc": str(get_attr(r, "sAMAccountName", "")), "revealed_account_dn": pdn})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-RODCAdminRevealed", CATEGORY, "RODC",
                    "A privileged account's password was cached to an RODC", status,
                    f"{len(out)} case(s) of a privileged account's secrets cached to an RODC.", out)


@rule("P-RODCRevealOnDemand", CATEGORY, "RODC", "Accounts flagged for on-demand RODC password caching")
def r_rodc_reveal_on_demand(ctx) -> Finding:
    out = []
    for r in _rodc_list(ctx):
        allowed = get_attr_list(r, "msDS-RevealOnDemandGroup")
        if allowed:
            out.append({"rodc": str(get_attr(r, "sAMAccountName", "")), "entries": len(allowed)})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-RODCRevealOnDemand", CATEGORY, "RODC",
                    "Accounts flagged for on-demand RODC password caching", status,
                    f"{len(out)} RODC(s) have a non-empty reveal-on-demand list (review membership).", out)


@rule("P-RODCKrbtgtOrphan", CATEGORY, "RODC", "Orphaned RODC krbtgt account")
def r_rodc_krbtgt_orphan(ctx) -> Finding:
    info = ctx.conn.server.info.other if ctx.conn.server.info else {}
    try:
        if int(info.get("domainFunctionality", ["0"])[0]) < 3:
            return Finding("P-RODCKrbtgtOrphan", CATEGORY, "RODC", "Orphaned RODC krbtgt account", Status.NOT_APPLICABLE,
                            "Domain functional level is below Windows 2008; RODCs are not supported.")
    except (TypeError, ValueError):
        pass
    krbtgt_accounts = ctx.search(ctx.base_dn, "(sAMAccountName=krbtgt_*)", attributes=["sAMAccountName"])
    rodc_names = {str(get_attr(r, "sAMAccountName", "")).rstrip("$").lower() for r in _rodc_list(ctx)}
    out = []
    for k in krbtgt_accounts:
        name = str(get_attr(k, "sAMAccountName", ""))
        # krbtgt_<RODCNAME> heuristic; if no RODC by that name exists, likely orphaned
        suffix = name.split("_", 1)[-1].lower()
        if not any(suffix in rn for rn in rodc_names):
            out.append({"krbtgt_account": name})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-RODCKrbtgtOrphan", CATEGORY, "RODC", "Orphaned RODC krbtgt account", status,
                    f"{len(out)} RODC krbtgt account(s) with no matching active RODC.", out)


@rule("P-RODCSYSVOLWrite", CATEGORY, "RODC", "Non-admins can write to an RODC's local SYSVOL",
      requires=("ldap", "smb"))
def r_rodc_sysvol_write(ctx) -> Finding:
    from ..smb_acl import get_smb_file_security_descriptor
    checked = 0
    errors = 0
    out = []
    for r in _rodc_list(ctx):
        host = str(get_attr(r, "dNSHostName", "")) or None
        if not host:
            continue
        raw = get_smb_file_security_descriptor(ctx, "SYSVOL", "", target=host, is_directory=True)
        if raw is None:
            errors += 1
            continue
        checked += 1
        sd = parse_security_descriptor(raw)
        for hit in effective_dangerous_aces(sd, ctx.domain_sid):
            out.append({"rodc": str(get_attr(r, "sAMAccountName", "")), **hit})
    if checked == 0 and errors > 0:
        return Finding("P-RODCSYSVOLWrite", CATEGORY, "RODC", "Non-admins can write to an RODC's local SYSVOL",
                        Status.ERROR, f"Found {errors} RODC(s) but could not retrieve the SYSVOL root NTFS "
                        "security descriptor from any of them (reachability, SMB dialect, or path issue) -- "
                        "not reporting Clean since that would risk masking a real finding.")
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("P-RODCSYSVOLWrite", CATEGORY, "RODC", "Non-admins can write to an RODC's local SYSVOL", status,
                    f"Checked {checked} RODC(s) ({errors} unreachable/skipped); {len(out)} finding(s) of "
                    "non-admin write-level NTFS access on an RODC's local SYSVOL share root.", out)
