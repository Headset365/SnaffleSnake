"""
Anomalies / CertificateTakeOver subcategory: AD CS (PKI) misconfiguration
checks. All read-only: LDAP reads of CA/template objects in the Configuration
partition, plus a passive TLS handshake against the DC's LDAPS port to see
what protocol/cipher it negotiates (the same kind of observation `openssl
s_client` or `testssl.sh` would make -- no data is sent beyond the standard
TLS ClientHello).
"""
from __future__ import annotations

import socket
import ssl

from ..models import rule, not_implemented, Finding, Status
from ..secdesc import parse_security_descriptor
from ..acl import is_broad_trustee
from ..constants import ACCESS_MASK
from ..utils import get_attr, get_attr_list

CATEGORY = "Anomalies"
SUB = "CertificateTakeOver"

OID_ANY_PURPOSE = "2.5.29.37.0"
OID_CERT_REQUEST_AGENT = "1.3.6.1.4.1.311.20.2.1"
OID_CLIENT_AUTH = "1.3.6.1.5.5.7.3.2"
ENROLLEE_SUPPLIES_SUBJECT = 0x1
CT_FLAG_NO_SECURITY_EXTENSION = 0x80000
CT_FLAG_PEND_ALL_REQUESTS = 0x2
EXTENDED_RIGHT_ENROLL = "0e10c968-78fb-11d2-90d4-00c04f79dc55"
EXTENDED_RIGHT_AUTOENROLL = "a05b8cc2-17bc-4802-a710-e7c15ab866a2"
BROAD_SIDS_HINT = ("domain users", "authenticated users", "everyone", "-513", "s-1-1-0", "s-1-5-11")


def _pki_base(ctx):
    return f"CN=Public Key Services,CN=Services,{ctx.config_nc}"


def _cas(ctx):
    """PingCastle's TrustedCertificates set.

    Source corrected: upstream reads CN=NTAuthCertificates (the NTAuth store,
    which is what actually governs whether a cert is trusted for client
    authentication) and GPO-deployed certificate stores. This module previously
    read CN=Certification Authorities -- a different container holding a
    different set, so every certificate rule was evaluating the wrong
    population.
    """
    if "cas" in ctx._cache:
        return ctx._cache["cas"]
    out = []
    ntauth_dn = f"CN=NTAuthCertificates,CN=Public Key Services,CN=Services,{ctx.config_nc}"
    try:
        entries = ctx.search(ntauth_dn, "(objectClass=*)", scope="BASE",
                              attributes=["cACertificate"])
    except Exception:
        entries = []
    for e in entries:
        raw = e["cACertificate"].raw_values if "cACertificate" in e else []
        for der in raw:
            out.append({"name": "NTAuthCertificates", "source": "NTAuthStore", "der": der})
    # Also include the CA container: not part of upstream's TrustedCertificates,
    # but useful evidence and harmless for these read-only checks. Tagged so a
    # reviewer can tell the two sources apart.
    try:
        ca_entries = ctx.search(f"CN=Certification Authorities,{_pki_base(ctx)}",
                                 "(objectClass=certificationAuthority)",
                                 attributes=["cn", "cACertificate"])
    except Exception:
        ca_entries = []
    for e in ca_entries:
        raw = e["cACertificate"].raw_values if "cACertificate" in e else []
        for der in raw:
            out.append({"name": str(get_attr(e, "cn", "")), "source": "CertificationAuthorities", "der": der})
    ctx._cache["cas"] = out
    return out


def _templates(ctx):
    if "templates" in ctx._cache:
        entries = ctx._cache["templates"]
    else:
        entries = ctx.search_with_sd(f"CN=Certificate Templates,{_pki_base(ctx)}",
                                      "(objectClass=pKICertificateTemplate)",
                                      attributes=["cn", "msPKI-Certificate-Name-Flag", "msPKI-Enrollment-Flag",
                                                  "pKIExtendedKeyUsage"])
        ctx._cache["templates"] = entries
    return entries


from cryptography import x509  # noqa: E402


def _load_cert(der_bytes):
    try:
        from cryptography import x509
        return x509.load_der_x509_certificate(der_bytes)
    except Exception:
        return None


def _template_has_broad_enroll(ctx, entry):
    raw = ctx.get_raw_sd_bytes(entry)
    if not raw:
        return False
    sd = parse_security_descriptor(raw)
    domain_sid = getattr(ctx, "domain_sid", None)
    for ace in sd.dacl:
        if not ace.is_allow:
            continue
        if not is_broad_trustee(ace.trustee_sid, domain_sid):
            continue
        # An object-scoped ACE counts only when it is actually scoped to the
        # Enroll/AutoEnroll extended right AND grants CONTROL_ACCESS.
        if ace.object_type and ace.object_type.lower() in (EXTENDED_RIGHT_ENROLL, EXTENDED_RIGHT_AUTOENROLL):
            if ace.mask & ACCESS_MASK["CONTROL_ACCESS"]:
                return True
        # An un-scoped ACE counts only if it confers all extended rights or
        # full control. Previously ANY un-scoped allow ACE matched here, which
        # made a plain default Read ACE look like enrollment rights and fired
        # this check on essentially every template in a normal domain.
        elif ace.object_type is None:
            if ace.mask & (ACCESS_MASK["GENERIC_ALL"] | ACCESS_MASK["CONTROL_ACCESS"]):
                return True
    return False


@rule("A-CertTempCustomSubject", CATEGORY, SUB, "Certificate template allows requester-supplied subject (ESC1)")
def r_cert_temp_custom_subject(ctx) -> Finding:
    out = []
    for t in _templates(ctx):
        flag = int(get_attr(t, "msPKI-Certificate-Name-Flag", 0) or 0)
        ekus = get_attr_list(t, "pKIExtendedKeyUsage")
        client_auth_capable = not ekus or OID_CLIENT_AUTH in ekus or OID_ANY_PURPOSE in ekus
        if flag & ENROLLEE_SUPPLIES_SUBJECT and client_auth_capable and _template_has_broad_enroll(ctx, t):
            out.append({"template": str(get_attr(t, "cn", ""))})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-CertTempCustomSubject", CATEGORY, SUB,
                    "Certificate template allows requester-supplied subject (ESC1)", status,
                    f"{len(out)} template(s) let a low-privileged enrollee supply an arbitrary SAN with a "
                    "client-auth-capable EKU (classic ESC1 impersonation path).", out)


@rule("A-CertTempAnyone", CATEGORY, SUB, "Low-privileged users can enroll for a client-auth-capable certificate")
def r_cert_temp_anyone(ctx) -> Finding:
    out = []
    for t in _templates(ctx):
        ekus = get_attr_list(t, "pKIExtendedKeyUsage")
        client_auth_capable = not ekus or OID_CLIENT_AUTH in ekus or OID_ANY_PURPOSE in ekus
        enrollment_flag = int(get_attr(t, "msPKI-Enrollment-Flag", 0) or 0)
        needs_approval = bool(enrollment_flag & CT_FLAG_PEND_ALL_REQUESTS)
        if client_auth_capable and not needs_approval and _template_has_broad_enroll(ctx, t):
            out.append({"template": str(get_attr(t, "cn", ""))})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-CertTempAnyone", CATEGORY, SUB,
                    "Low-privileged users can enroll for a client-auth-capable certificate", status,
                    f"{len(out)} template(s) allow broad, no-approval enrollment for client authentication.", out)


@rule("A-CertTempAnyPurpose", CATEGORY, SUB, "Certificate template has the Any Purpose EKU")
def r_cert_temp_any_purpose(ctx) -> Finding:
    out = []
    for t in _templates(ctx):
        ekus = get_attr_list(t, "pKIExtendedKeyUsage")
        if not ekus or OID_ANY_PURPOSE in ekus:
            out.append({"template": str(get_attr(t, "cn", ""))})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-CertTempAnyPurpose", CATEGORY, SUB, "Certificate template has the Any Purpose EKU", status,
                    f"{len(out)} template(s) have no EKU restriction or explicit Any Purpose.", out)


@rule("A-CertTempAgent", CATEGORY, SUB, "Certificate template allows enrollment as a request agent (ESC3)")
def r_cert_temp_agent(ctx) -> Finding:
    out = []
    for t in _templates(ctx):
        ekus = get_attr_list(t, "pKIExtendedKeyUsage")
        if OID_CERT_REQUEST_AGENT in ekus and _template_has_broad_enroll(ctx, t):
            out.append({"template": str(get_attr(t, "cn", ""))})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-CertTempAgent", CATEGORY, SUB,
                    "Certificate template allows enrollment as a request agent (ESC3)", status,
                    f"{len(out)} template(s) grant the Certificate Request Agent EKU broadly.", out)


@rule("A-CertTempNoSecurity", CATEGORY, SUB, "Certificate template omits the security-extension (ESC9-style)")
def r_cert_temp_no_security(ctx) -> Finding:
    out = []
    for t in _templates(ctx):
        flag = int(get_attr(t, "msPKI-Enrollment-Flag", 0) or 0)
        if flag & CT_FLAG_NO_SECURITY_EXTENSION:
            out.append({"template": str(get_attr(t, "cn", ""))})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-CertTempNoSecurity", CATEGORY, SUB,
                    "Certificate template omits the security-extension (ESC9-style)", status,
                    f"{len(out)} template(s) set CT_FLAG_NO_SECURITY_EXTENSION "
                    "(issued certs omit the szOID_NTDS_CA_SECURITY_EXT binding).", out)


# signature-algorithm OID -> PingCastle's FriendlyName
_SIG_OID = {
    "1.2.840.113549.1.1.2": "md2",
    "1.2.840.113549.1.1.3": "md4",
    "1.2.840.113549.1.1.4": "md5",
    "1.3.14.3.2.15": "sha0",   # OIW shaRSA == SHA-0, its own OID
    "1.2.840.113549.1.1.5": "sha1",
    "1.3.14.3.2.29": "sha1",
}


def _weak_hash_rules(ctx):
    """One pass over the trusted certificates, classified by signature OID,
    root/intermediate, RSA modulus band and DSA usage."""
    if "cert_hash_scan" in ctx._cache:
        return ctx._cache["cert_hash_scan"]
    result = {"md2": [], "md4": [], "md5": [], "sha0": [], "sha1": [],
              "rsa_lt1024": [], "rsa_1024_2048": [], "dsa_signing": []}
    for ca in _cas(ctx):
        cert = _load_cert(ca["der"])
        if cert is None:
            continue
        is_root = cert.issuer == cert.subject
        entry = {"source": ca["source"], "ca": ca["name"],
                 "subject": cert.subject.rfc4514_string()[:120],
                 "type": "root" if is_root else "intermediate"}
        oid = getattr(cert.signature_algorithm_oid, "dotted_string", "")
        label = _SIG_OID.get(oid)
        if label:
            result[label].append(entry)
        try:
            pub = cert.public_key()
            size = getattr(pub, "key_size", None)
            algo = type(pub).__name__
            if "RSA" in algo and size:
                # Upstream bands: <1024 is A-WeakRSARootCert; 1024..2047 (and
                # <3072 expiring after 2031) is A-WeakRSARootCert2. These are
                # SIZE bands over ALL trusted certs -- NOT root vs intermediate,
                # which is how this file previously (incorrectly) split them.
                not_after = getattr(cert, "not_valid_after", None)
                if size < 1024:
                    result["rsa_lt1024"].append({**entry, "key_size": size})
                elif size < 2048:
                    result["rsa_1024_2048"].append({**entry, "key_size": size})
                elif size < 3072 and not_after is not None and not_after.year > 2031:
                    result["rsa_1024_2048"].append(
                        {**entry, "key_size": size,
                         "note": "under 3072 bits and valid beyond 2031"})
            if "DSA" in algo:
                # Upstream flags DSA certs usable for DIGITAL SIGNATURE -- there
                # is no key-size test at all (this file previously used <2048).
                usage_signing = False
                try:
                    ku = cert.extensions.get_extension_for_oid(
                        x509.oid.ExtensionOID.KEY_USAGE).value
                    usage_signing = bool(ku.digital_signature)
                except Exception:
                    usage_signing = False
                if usage_signing:
                    result["dsa_signing"].append({**entry, "key_size": size})
        except Exception:
            pass
    ctx._cache["cert_hash_scan"] = result
    return result


def _make_hash_rule(rule_id, bucket, want_root, title):
    def _r(ctx):
        scan = _weak_hash_rules(ctx)
        want = "root" if want_root else "intermediate"
        hits = [h for h in scan[bucket] if h["type"] == want]
        status = Status.TRIGGERED if hits else Status.CLEAN
        return Finding(rule_id, CATEGORY, SUB, title, status,
                        f"{len(hits)} trusted {want} certificate(s) signed with "
                        f"{bucket.upper()}.", hits)
    return _r


# Every weak-hash rule follows the same shape: (bucket, root rule id, intermediate rule id).
# SHA-0 is included: contrary to a previous note in this file claiming it could
# not be distinguished from SHA-1, it has its own signature OID (1.3.14.3.2.15,
# the OIW "shaRSA"), which is exactly how PingCastle tells them apart.
for _bucket, _rid_root, _rid_int in (
        ("md2", "A-MD2RootCert", "A-MD2IntermediateCert"),
        ("md4", "A-MD4RootCert", "A-MD4IntermediateCert"),
        ("md5", "A-MD5RootCert", "A-MD5IntermediateCert"),
        ("sha0", "A-SHA0RootCert", "A-SHA0IntermediateCert"),
        ("sha1", "A-SHA1RootCert", "A-SHA1IntermediateCert"),
):
    _t_root = f"Trusted root certificate signed with {_bucket.upper()}"
    _t_int = f"Trusted intermediate certificate signed with {_bucket.upper()}"
    rule(_rid_root, CATEGORY, SUB, _t_root)(_make_hash_rule(_rid_root, _bucket, True, _t_root))
    rule(_rid_int, CATEGORY, SUB, _t_int)(_make_hash_rule(_rid_int, _bucket, False, _t_int))


not_implemented("A-CertROCA", CATEGORY, SUB, "CA certificate vulnerable to the ROCA weak-key flaw",
                 "Requires the Infineon ROCA fingerprinting algorithm against the RSA modulus; no "
                 "vetted reference implementation was available to build on, and hand-rolled "
                 "cryptographic pattern matching risks confident false results either way.")


@rule("A-WeakRSARootCert", CATEGORY, SUB, "Trusted certificate with an RSA key under 1024 bits")
def r_weak_rsa_root(ctx) -> Finding:
    """Upstream threshold is modulus < 1024 bits, applied to ALL trusted
    certificates. This file previously used <2048 AND filtered to root-only --
    both wrong: the root/intermediate split belongs to the hash rules, not these.
    """
    hits = _weak_hash_rules(ctx)["rsa_lt1024"]
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding("A-WeakRSARootCert", CATEGORY, SUB,
                    "Trusted certificate with an RSA key under 1024 bits", status,
                    f"{len(hits)} trusted certificate(s) use an RSA key smaller than 1024 bits.", hits)


@rule("A-WeakRSARootCert2", CATEGORY, SUB, "Trusted certificate with an RSA key under 2048 bits")
def r_weak_rsa_root2(ctx) -> Finding:
    """The companion band to A-WeakRSARootCert: 1024 <= modulus < 2048, plus
    certificates under 3072 bits that remain valid beyond 2031. This is a SIZE
    band, not the "intermediate certificate" rule it was previously implemented
    as.
    """
    hits = _weak_hash_rules(ctx)["rsa_1024_2048"]
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding("A-WeakRSARootCert2", CATEGORY, SUB,
                    "Trusted certificate with an RSA key under 2048 bits", status,
                    f"{len(hits)} trusted certificate(s) fall in the 1024-2047 bit band, or are "
                    "under 3072 bits while valid beyond 2031.", hits)


not_implemented("A-CertWeakRsaComponent", CATEGORY, SUB, "CA certificate RSA key has a weak component",
                 "Refers to weak-modulus-component research beyond plain key size; not implemented.")


@rule("A-CertWeakDSA", CATEGORY, SUB, "Trusted certificate uses a DSA key for digital signature")
def r_cert_weak_dsa(ctx) -> Finding:
    """Upstream flags any trusted certificate with a DSA public key whose Key
    Usage permits Digital Signature. There is NO key-size threshold -- this file
    previously required <2048 bits, which is a different (and much narrower)
    test.
    """
    hits = _weak_hash_rules(ctx)["dsa_signing"]
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding("A-CertWeakDSA", CATEGORY, SUB,
                    "Trusted certificate uses a DSA key for digital signature", status,
                    f"{len(hits)} trusted certificate(s) carry a DSA key with the Digital Signature "
                    "key usage set.", hits)


def _ldaps_protocol_scan(ctx):
    """Which legacy TLS/SSL versions each DC will still negotiate on port 636.

    Upstream splits these across two rules by VERSION:
      A-DCLdapsProtocol         -> SSL2 / SSL3
      A-DCLdapsProtocolAdvanced -> TLS 1.0 / TLS 1.1
    This module previously had the first rule flag everything below TLS 1.2
    (overlapping both) and the second do a cipher-suite sweep, which is not a
    protocol check at all.
    """
    if "ldaps_protocols" in ctx._cache:
        return ctx._cache["ldaps_protocols"]
    versions = [
        ("SSLv3", getattr(ssl.TLSVersion, "SSLv3", None)),
        ("TLSv1", ssl.TLSVersion.TLSv1),
        ("TLSv1.1", ssl.TLSVersion.TLSv1_1),
    ]
    found = {}
    for dc in ctx.dc_hostnames:
        offered = []
        for label, ver in versions:
            if ver is None:
                continue
            try:
                sctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                sctx.check_hostname = False
                sctx.verify_mode = ssl.CERT_NONE
                sctx.set_ciphers("ALL:@SECLEVEL=0")
                sctx.minimum_version = ver
                sctx.maximum_version = ver
                with socket.create_connection((dc, 636), timeout=5) as sock:
                    with sctx.wrap_socket(sock, server_hostname=dc) as ss:
                        if ss.version():
                            offered.append(label)
            except Exception:
                continue
        if offered:
            found[dc] = offered
    ctx._cache["ldaps_protocols"] = found
    return found


@rule("A-DCLdapsProtocol", CATEGORY, SUB, "DC LDAPS accepts SSLv2/SSLv3")
def r_dc_ldaps_protocol(ctx) -> Finding:
    scan = _ldaps_protocol_scan(ctx)
    out = [{"dc": dc, "protocols": [p for p in v if p.startswith("SSL")]}
           for dc, v in scan.items() if any(p.startswith("SSL") for p in v)]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-DCLdapsProtocol", CATEGORY, SUB, "DC LDAPS accepts SSLv2/SSLv3", status,
                    f"{len(out)} DC(s) still negotiate SSLv2 or SSLv3 on port 636. "
                    "(Python's ssl module cannot offer SSLv2 at all on modern OpenSSL, so an "
                    "SSLv2-only server may not be detectable here.)", out)


@rule("A-DCLdapsProtocolAdvanced", CATEGORY, SUB, "DC LDAPS accepts TLS 1.0 / TLS 1.1")
def r_dc_ldaps_protocol_advanced(ctx) -> Finding:
    scan = _ldaps_protocol_scan(ctx)
    out = [{"dc": dc, "protocols": [p for p in v if p.startswith("TLS")]}
           for dc, v in scan.items() if any(p.startswith("TLS") for p in v)]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-DCLdapsProtocolAdvanced", CATEGORY, SUB,
                    "DC LDAPS accepts TLS 1.0 / TLS 1.1", status,
                    f"{len(out)} DC(s) still negotiate TLS 1.0 or TLS 1.1 on port 636.", out)


not_implemented("A-CertEnrollChannelBinding", CATEGORY, SUB, "Web enrollment lacks channel binding",
                 "Requires probing IIS Extended Protection configuration on the CA's web enrollment endpoint; "
                 "not yet implemented.")


@rule("A-CertEnrollHttp", CATEGORY, SUB, "Certificate web enrollment reachable over plain HTTP")
def r_cert_enroll_http(ctx) -> Finding:
    import urllib.request

    entries = ctx.search(f"CN=Enrollment Services,{_pki_base(ctx)}", "(objectClass=pKIEnrollmentService)",
                          attributes=["dNSHostName", "cn"])
    out = []
    for e in entries:
        host = str(get_attr(e, "dNSHostName", ""))
        if not host:
            continue
        try:
            req = urllib.request.Request(f"http://{host}/certsrv/", method="HEAD")
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status < 500:
                    out.append({"ca": str(get_attr(e, "cn", "")), "host": host})
        except Exception:
            continue
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-CertEnrollHttp", CATEGORY, SUB, "Certificate web enrollment reachable over plain HTTP",
                    status, f"{len(out)} CA(s) expose /certsrv/ over unencrypted HTTP.", out)


@rule("A-WSUS-SslProtocol", CATEGORY, SUB, "WSUS HTTPS endpoint accepts weak/outdated TLS", requires=("ldap", "smb"))
def r_wsus_ssl_protocol(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    servers = set()
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        s = gpomod.find_reg_value(entries, r"policies\microsoft\windows\windowsupdate", "WUServer")
        if s and str(s).lower().startswith("https://"):
            host = str(s).split("//", 1)[1].split("/")[0].split(":")[0]
            servers.add(host)
    out = []
    for host in servers:
        try:
            ctx_ssl = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx_ssl.check_hostname = False
            ctx_ssl.verify_mode = ssl.CERT_NONE
            ctx_ssl.set_ciphers("ALL:@SECLEVEL=0")
            with socket.create_connection((host, 443), timeout=5) as sock:
                with ctx_ssl.wrap_socket(sock, server_hostname=host) as ssock:
                    version = ssock.version()
            if version in ("TLSv1", "TLSv1.1", "SSLv3"):
                out.append({"wsus_host": host, "negotiated_version": version})
        except Exception:
            continue
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-WSUS-SslProtocol", CATEGORY, SUB, "WSUS HTTPS endpoint accepts weak/outdated TLS", status,
                    f"{len(out)} WSUS server(s) negotiate TLS below 1.2.", out)
