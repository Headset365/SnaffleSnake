"""
Importing this package registers every rule (real implementation or documented
stub) into `adaudit.models.REGISTRY`. Import order doesn't matter -- the
registry is a flat list built by decorator side-effects.
"""
from . import stale_objects       # noqa: F401
from . import privileged_accounts  # noqa: F401
from . import trusts               # noqa: F401
from . import anomalies            # noqa: F401
from . import anomalies_certs      # noqa: F401
from . import anomalies_network    # noqa: F401
from . import anomalies_ptc        # noqa: F401
