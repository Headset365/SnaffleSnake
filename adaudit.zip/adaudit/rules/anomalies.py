"""
Anomalies rules (PingCastle category `A-*`). Split logically within this one
file by subcategory since PingCastle itself groups them this way.
"""
from __future__ import annotations

from ..constants import (UAC_ACCOUNTDISABLE, UAC_SMARTCARD_REQUIRED, EXTENDED_RIGHTS,
                          DCSYNC_GUIDS, ACCESS_MASK)
from ..models import rule, not_implemented, Finding, Status
from ..secdesc import parse_security_descriptor
from ..acl import effective_dangerous_aces, is_broad_trustee
from ..utils import filetime_to_datetime, days_since, get_attr, get_attr_list, sid_to_rid

CATEGORY = "Anomalies"
EVERYONE = "S-1-1-0"
AUTHENTICATED_USERS = "S-1-5-11"
ANONYMOUS = "S-1-5-7"
BROAD_SIDS = (EVERYONE, AUTHENTICATED_USERS, ANONYMOUS)


# ---------------------------------------------------------------------------
# Weak Password
# ---------------------------------------------------------------------------

@rule("A-Guest", CATEGORY, "WeakPassword", "Built-in Guest account is enabled")
def r_guest(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(objectSid=" + ctx.domain_sid + "-501)", attributes=["userAccountControl"])
    if not entries:
        return Finding("A-Guest", CATEGORY, "WeakPassword", "Built-in Guest account is enabled", Status.ERROR,
                        "Could not locate Guest account (RID 501).")
    uac = int(get_attr(entries[0], "userAccountControl", 0) or 0)
    enabled = not (uac & UAC_ACCOUNTDISABLE)
    status = Status.TRIGGERED if enabled else Status.CLEAN
    return Finding("A-Guest", CATEGORY, "WeakPassword", "Built-in Guest account is enabled", status,
                    "Guest account is ENABLED." if enabled else "Guest account is disabled.")


@rule("A-MinPwdLen", CATEGORY, "WeakPassword", "Minimum password length policy too low")
def r_min_pwd_len(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(objectClass=domainDNS)", attributes=["minPwdLength"])
    val = get_attr(entries[0], "minPwdLength") if entries else None
    try:
        val = int(val)
    except (TypeError, ValueError):
        val = None
    status = Status.TRIGGERED if val is not None and val < 8 else Status.CLEAN
    return Finding("A-MinPwdLen", CATEGORY, "WeakPassword", "Minimum password length policy too low", status,
                    f"minPwdLength = {val} (recommended >= 8, ideally 14+).")


@rule("A-NoServicePolicy", CATEGORY, "WeakPassword",
      "No password policy strong enough for service accounts", requires=("ldap", "smb"))
def r_no_service_policy(ctx) -> Finding:
    """Upstream test: does ANY password policy -- GPO-delivered or a
    fine-grained PSO -- set MinimumPasswordLength >= 20? That length is the
    marker of a policy intended for service accounts.

    The previous implementation only asked whether any PSO *existed*, so a PSO
    with an 8-character minimum satisfied it.
    """
    strongest = 0
    sources = []
    for e in ctx.search(f"CN=Password Settings Container,CN=System,{ctx.base_dn}",
                         "(objectClass=msDS-PasswordSettings)",
                         attributes=["cn", "msDS-MinimumPasswordLength"]):
        try:
            length = int(get_attr(e, "msDS-MinimumPasswordLength", 0) or 0)
        except (TypeError, ValueError):
            continue
        sources.append({"policy": str(get_attr(e, "cn", "")), "type": "PSO", "min_length": length})
        strongest = max(strongest, length)
    from .. import gpo as gpomod
    for g in gpomod.list_gpos(ctx):
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        val = tmpl.get("System Access", {}).get("MinimumPasswordLength")
        if val is None:
            continue
        try:
            length = int(str(val).strip())
        except ValueError:
            continue
        sources.append({"policy": g.display_name, "type": "GPO", "min_length": length})
        strongest = max(strongest, length)
    status = Status.CLEAN if strongest >= 20 else Status.TRIGGERED
    return Finding("A-NoServicePolicy", CATEGORY, "WeakPassword",
                    "No password policy strong enough for service accounts", status,
                    f"Strongest minimum password length across all GPO and PSO policies: {strongest}. "
                    "At least 20 characters marks a service-account-grade policy.", sources)


@rule("A-LimitBlankPasswordUse", CATEGORY, "WeakPassword",
      "Blank-password accounts not restricted to console logon", requires=("ldap", "smb"))
def r_limit_blank_password(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    restricted_somewhere = False
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        reg_values = tmpl.get("Registry Values", {})
        for k, v in reg_values.items():
            if k.lower().endswith("limitblankpassworduse") and str(v).split(",")[-1] == "1":
                restricted_somewhere = True
    status = Status.CLEAN if restricted_somewhere else Status.TRIGGERED
    return Finding("A-LimitBlankPasswordUse", CATEGORY, "WeakPassword",
                    "Blank-password accounts not restricted to console logon", status,
                    "LimitBlankPasswordUse=1 found in at least one GPO." if restricted_somewhere else
                    "No GPO sets LimitBlankPasswordUse=1; an account with a blank password could log on over "
                    "the network, not just at the local console.")

# ---------------------------------------------------------------------------
# Golden Ticket
# ---------------------------------------------------------------------------

@rule("A-Krbtgt", CATEGORY, "GoldenTicket", "krbtgt password age enables long-lived Golden Tickets")
def r_krbtgt(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(sAMAccountName=krbtgt)", attributes=["pwdLastSet"])
    d = days_since(filetime_to_datetime(get_attr(entries[0], "pwdLastSet"))) if entries else None
    # PingCastle's lowest krbtgt threshold is 366 days (then 732/1098/1464 for
    # escalating severity). 180 (the previous value here) over-reported.
    status = Status.TRIGGERED if d is None or d >= 366 else Status.CLEAN
    return Finding("A-Krbtgt", CATEGORY, "GoldenTicket", "krbtgt password age enables long-lived Golden Tickets",
                    status, f"krbtgt password age = {d} days (PingCastle thresholds: 366/732/1098/1464 days for escalating severity; rotate twice, consecutively, to fully invalidate Golden Tickets).")


# ---------------------------------------------------------------------------
# Password Retrieval
# ---------------------------------------------------------------------------

@rule("A-ReversiblePwd", CATEGORY, "PasswordRetrieval", "Domain policy allows reversible password encryption")
def r_reversible_policy(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(objectClass=domainDNS)", attributes=["pwdProperties"])
    try:
        props = int(get_attr(entries[0], "pwdProperties", 0) or 0) if entries else 0
    except (TypeError, ValueError):
        props = 0
    reversible = bool(props & 0x10)  # DOMAIN_PASSWORD_STORE_CLEARTEXT
    status = Status.TRIGGERED if reversible else Status.CLEAN
    return Finding("A-ReversiblePwd", CATEGORY, "PasswordRetrieval",
                    "Domain policy allows reversible password encryption", status,
                    f"pwdProperties = {props:#x} (bit 0x10 DOMAIN_PASSWORD_STORE_CLEARTEXT {'SET' if reversible else 'not set'}).")


@rule("A-UnixPwd", CATEGORY, "PasswordRetrieval", "Unix/NIS password attributes populated in AD")
def r_unix_pwd(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(unixUserPassword=*)", attributes=["sAMAccountName"])
    out = [{"account": str(get_attr(e, "sAMAccountName", ""))} for e in entries]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-UnixPwd", CATEGORY, "PasswordRetrieval", "Unix/NIS password attributes populated in AD",
                    status, f"{len(out)} account(s) have a unixUserPassword value set.", out)


@rule("A-PwdGPO", CATEGORY, "PasswordRetrieval", "Password embedded in a Group Policy Preference file",
      requires=("ldap", "smb"))
def r_pwd_gpo(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    pref_files = ["Groups.xml", "Services.xml", "ScheduledTasks.xml", "DataSources.xml", "Printers.xml", "Drives.xml"]
    out = []
    for g in gpos:
        for scope in ("MACHINE", "USER"):
            for fname in pref_files:
                raw = gpomod._smb_read(ctx, gpomod.gpo_relative_path(g, f"{scope}\\Preferences\\{fname.split('.')[0]}\\{fname}"))
                if raw and b"cpassword=" in raw:
                    out.append({"gpo": g.display_name, "file": f"{scope}\\{fname}"})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-PwdGPO", CATEGORY, "PasswordRetrieval",
                    "Password embedded in a Group Policy Preference file", status,
                    f"{len(out)} preference file(s) contain a cpassword field (these are trivially decryptable "
                    "with Microsoft's published AES key).", out)


# ---------------------------------------------------------------------------
# Reconnaissance
# ---------------------------------------------------------------------------

def _ds_heuristics(ctx):
    if "dsh" in ctx._cache:
        return ctx._cache["dsh"]
    entries = ctx.search(f"CN=Directory Service,CN=Windows NT,CN=Services,{ctx.config_nc}",
                          "(objectClass=*)", attributes=["dSHeuristics"])
    val = str(get_attr(entries[0], "dSHeuristics", "")) if entries else ""
    ctx._cache["dsh"] = val
    return val


def _dsh_char(val, index):
    return val[index] if len(val) > index else "0"


@rule("A-DsHeuristicsAnonymous", CATEGORY, "Reconnaissance", "dSHeuristics allows anonymous LDAP access")
def r_dsh_anonymous(ctx) -> Finding:
    val = _ds_heuristics(ctx)
    # index 6 (7th char), value "2" == anonymous LDAP bind permitted.
    bad = len(val) >= 7 and _dsh_char(val, 6) == "2"
    status = Status.TRIGGERED if bad else Status.CLEAN
    return Finding("A-DsHeuristicsAnonymous", CATEGORY, "Reconnaissance",
                    "dSHeuristics allows anonymous LDAP access", status, f"dSHeuristics={val!r}.")


@rule("A-DsHeuristicsAllowAnonNSPI", CATEGORY, "Reconnaissance", "dSHeuristics allows anonymous NSPI access")
def r_dsh_anon_nspi(ctx) -> Finding:
    val = _ds_heuristics(ctx)
    # index 7 (8th char), any non-"0" enables anonymous NSPI.
    bad = len(val) >= 8 and _dsh_char(val, 7) != "0"
    status = Status.TRIGGERED if bad else Status.CLEAN
    return Finding("A-DsHeuristicsAllowAnonNSPI", CATEGORY, "Reconnaissance",
                    "dSHeuristics allows anonymous NSPI access", status, f"dSHeuristics={val!r}.")


@rule("A-DsHeuristicsDoNotVerifyUniqueness", CATEGORY, "Reconnaissance", "dSHeuristics disables uniqueness verification")
def r_dsh_uniqueness(ctx) -> Finding:
    val = _ds_heuristics(ctx)
    # index 20 (21st char), any non-"0" disables uniqueness verification.
    bad = len(val) >= 21 and _dsh_char(val, 20) != "0"
    status = Status.TRIGGERED if bad else Status.CLEAN
    return Finding("A-DsHeuristicsDoNotVerifyUniqueness", CATEGORY, "Reconnaissance",
                    "dSHeuristics disables uniqueness verification", status, f"dSHeuristics={val!r}.")


@rule("A-DsHeuristicsLDAPSecurity", CATEGORY, "Reconnaissance", "dSHeuristics weakens default LDAP security descriptor")
def r_dsh_ldap_security(ctx) -> Finding:
    val = _ds_heuristics(ctx)
    # index 27 (28th char) is LDAPAddAuthZVerifications: it must be "1".
    # Absent/short dSHeuristics also counts as not-set, i.e. a finding.
    bad = len(val) < 28 or _dsh_char(val, 27) != "1"
    status = Status.TRIGGERED if bad else Status.CLEAN
    return Finding("A-DsHeuristicsLDAPSecurity", CATEGORY, "Reconnaissance",
                    "dSHeuristics weakens default LDAP security descriptor", status, f"dSHeuristics={val!r}.")


def _pre2k_members(ctx):
    entries = ctx.search(f"CN=Builtin,{ctx.base_dn}", "(cn=Pre-Windows 2000 Compatible Access)", attributes=["member"])
    return get_attr_list(entries[0], "member") if entries else []


@rule("A-PreWin2000Anonymous", CATEGORY, "Reconnaissance", "Pre-Windows 2000 group includes Anonymous")
def r_pre2k_anonymous(ctx) -> Finding:
    members = _pre2k_members(ctx)
    # PingCastle treats Anonymous (S-1-5-7) OR Everyone (S-1-1-0) as this finding.
    hit = any(("s-1-5-7" in m.lower() or "s-1-1-0" in m.lower()
               or "anonymous" in m.lower() or "everyone" in m.lower()) for m in members)
    status = Status.TRIGGERED if hit else Status.CLEAN
    return Finding("A-PreWin2000Anonymous", CATEGORY, "Reconnaissance", "Pre-Windows 2000 group includes Anonymous",
                    status, "Anonymous Logon is a member." if hit else "Anonymous Logon is not a member.")


@rule("A-PreWin2000AuthenticatedUsers", CATEGORY, "Reconnaissance", "Pre-Windows 2000 group uses broad default membership")
def r_pre2k_auth_users(ctx) -> Finding:
    members = _pre2k_members(ctx)
    # Membership is stored as DNs; the well-known SIDs appear as CN=S-1-5-11 style
    # entries, so match on the SID rather than a display name.
    hit = any("s-1-5-11" in m.lower() or "authenticated users" in m.lower() for m in members)
    # Polarity: Authenticated Users being present IS the finding. This previously
    # reported the exact inverse -- clean when the group was misconfigured.
    status = Status.TRIGGERED if hit else Status.CLEAN
    return Finding("A-PreWin2000AuthenticatedUsers", CATEGORY, "Reconnaissance",
                    "Pre-Windows 2000 group contains Authenticated Users", status,
                    "Authenticated Users is a member of Pre-Windows 2000 Compatible Access, "
                    "granting broad read over the directory."
                    if hit else "Authenticated Users is not a member.",
                    [{"member": m} for m in members])


@rule("A-PreWin2000Other", CATEGORY, "Reconnaissance", "Pre-Windows 2000 group has unexpected members")
def r_pre2k_other(ctx) -> Finding:
    members = _pre2k_members(ctx)
    # PingCastle's test is structural: any member whose DN does NOT start "CN=S-"
    # is a real (non well-known-SID) principal that was explicitly added.
    unexpected = [m for m in members if not m.upper().startswith("CN=S-")]
    status = Status.TRIGGERED if unexpected else Status.CLEAN
    return Finding("A-PreWin2000Other", CATEGORY, "Reconnaissance", "Pre-Windows 2000 group has unexpected members",
                    status, f"{len(unexpected)} unexpected member(s).", [{"member": m} for m in unexpected])


@rule("A-RootDseAnonBinding", CATEGORY, "Reconnaissance", "Anonymous RootDSE bind allowed")
def r_rootdse_anon(ctx) -> Finding:
    from ldap3 import Server, Connection, ANONYMOUS
    try:
        anon_server = Server(ctx.server.host, port=ctx.server.port, get_info="NONE")
        anon_conn = Connection(anon_server, authentication=ANONYMOUS, auto_bind=True)
        anon_conn.search("", "(objectClass=*)", search_scope="BASE", attributes=["namingContexts"])
        got_data = bool(anon_conn.entries)
        anon_conn.unbind()
    except Exception:
        got_data = False
    status = Status.TRIGGERED if got_data else Status.CLEAN
    return Finding("A-RootDseAnonBinding", CATEGORY, "Reconnaissance", "Anonymous RootDSE bind allowed", status,
                    "Anonymous bind returned RootDSE data." if got_data else "Anonymous bind did not return data.")


@rule("A-NullSession", CATEGORY, "Reconnaissance", "DC permits anonymous (null session) SMB connections",
      requires=("ldap", "smb"))
def r_null_session(ctx) -> Finding:
    try:
        from impacket.smbconnection import SMBConnection
    except ImportError:
        return Finding("A-NullSession", CATEGORY, "Reconnaissance",
                        "DC permits anonymous (null session) SMB connections", Status.REQUIRES_SMB,
                        "impacket not installed.")
    hits = []
    for dc in ctx.dc_hostnames:
        try:
            smb = SMBConnection(dc, dc, timeout=5)
            smb.login("", "")  # null session
            shares = smb.listShares()
            smb.close()
            hits.append({"dc": dc, "shares_visible": len(shares)})
        except Exception:
            continue
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding("A-NullSession", CATEGORY, "Reconnaissance",
                    "DC permits anonymous (null session) SMB connections", status,
                    f"{len(hits)} DC(s) accepted a null SMB session.", hits)


@rule("A-DnsZoneTransfert", CATEGORY, "Reconnaissance", "DNS zone allows unrestricted zone transfer (AXFR)")
def r_dns_zone_transfer(ctx) -> Finding:
    import dns.zone
    import dns.query

    hits = []
    for dc in ctx.dc_hostnames or [ctx.domain]:
        try:
            z = dns.zone.from_xfr(dns.query.xfr(dc, ctx.domain, timeout=5))
            if z:
                hits.append({"dc": dc, "records": len(list(z.nodes))})
        except Exception:
            continue
    status = Status.TRIGGERED if hits else Status.CLEAN
    return Finding("A-DnsZoneTransfert", CATEGORY, "Reconnaissance",
                    "DNS zone allows unrestricted zone transfer (AXFR)", status,
                    f"{len(hits)} DC/DNS server(s) allowed an unauthenticated AXFR of {ctx.domain}.", hits)


@rule("A-AnonymousAuthorizedGPO", CATEGORY, "Reconnaissance", "A GPO grants a user right to Anonymous Logon",
      requires=("ldap", "smb"))
def r_anonymous_authorized_gpo(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    out = []
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        for right, value in tmpl.get("Privilege Rights", {}).items():
            if "s-1-5-7" in value.lower() or "anonymous logon" in value.lower():
                out.append({"gpo": g.display_name, "right": right, "value": value})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-AnonymousAuthorizedGPO", CATEGORY, "Reconnaissance",
                    "A GPO grants a user right to Anonymous Logon", status,
                    f"{len(out)} GPO right assignment(s) reference the ANONYMOUS LOGON SID (S-1-5-7).", out)


@rule("A-NoNetSessionHardening", CATEGORY, "Reconnaissance", "NetSessionEnum hardening (NetCease) not applied",
      requires=("ldap", "smb"))
def r_no_net_session_hardening(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    configured = False
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        for key, vname, _t, _d in entries:
            if "lanmanserver" in key.lower() and "srvsvcsessioninfo" in vname.lower():
                configured = True
    status = Status.CLEAN if configured else Status.TRIGGERED
    return Finding("A-NoNetSessionHardening", CATEGORY, "Reconnaissance",
                    "NetSessionEnum hardening (NetCease) not applied", status,
                    "At least one GPO sets a SrvsvcSessionInfo value under LanmanServer parameters "
                    "(presence-only check -- this confirms hardening was attempted, not that the security "
                    "descriptor content is actually restrictive)." if configured else
                    "No GPO sets SrvsvcSessionInfo; NetSessionEnum is likely unrestricted for any authenticated "
                    "user, letting them enumerate active sessions on DCs (useful for hunting logged-on admins).")

# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

@rule("A-AuditDC", CATEGORY, "Audit", "DC audit policy missing key event categories", requires=("ldap", "smb"))
def r_audit_dc(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    configured = False
    for g in gpos:
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if tmpl and tmpl.get("Event Audit"):
            configured = True
            break
    status = Status.CLEAN if configured else Status.TRIGGERED
    return Finding("A-AuditDC", CATEGORY, "Audit", "DC audit policy missing key event categories", status,
                    "At least one GPO configures the legacy Event Audit policy." if configured else
                    "No GPO configures audit policy via GptTmpl.inf (note: modern advanced audit policy via "
                    "audit.csv is not checked by this pass).")


@rule("A-AuditPowershell", CATEGORY, "Audit", "PowerShell script block logging not enabled", requires=("ldap", "smb"))
def r_audit_powershell(ctx) -> Finding:
    from .. import gpo as gpomod
    gpos = gpomod.list_gpos(ctx)
    enabled = False
    for g in gpos:
        entries = gpomod.fetch_registry_pol(ctx, g)
        val = gpomod.find_reg_value(entries, r"policies\microsoft\windows\powershell\scriptblocklogging",
                                     "EnableScriptBlockLogging")
        if val and str(val) == "1":
            enabled = True
    status = Status.CLEAN if enabled else Status.TRIGGERED
    return Finding("A-AuditPowershell", CATEGORY, "Audit", "PowerShell script block logging not enabled", status,
                    "Enabled in at least one GPO." if enabled else "Not enabled in any GPO.")


# ---------------------------------------------------------------------------
# Backup
# ---------------------------------------------------------------------------

@rule("A-NotEnoughDC", CATEGORY, "Backup", "Too few Domain Controllers for redundancy")
def r_not_enough_dc(ctx) -> Finding:
    count = len(ctx.dc_hostnames)
    status = Status.TRIGGERED if count < 2 else Status.CLEAN
    return Finding("A-NotEnoughDC", CATEGORY, "Backup", "Too few Domain Controllers for redundancy", status,
                    f"{count} Domain Controller(s) found (recommended: at least 2).")


not_implemented("A-BackupMetadata", CATEGORY, "Backup", "No recent AD backup detected",
                 "PingCastle detects this via replication metadata (DRS GetReplicationMetadata / dumpsterExpiry-"
                 "adjacent internals), which needs the DRSUAPI RPC interface, not plain LDAP. Deliberately left "
                 "out per the earlier scoping decision to avoid anything resembling the DCSync-adjacent RPC call.")

# ---------------------------------------------------------------------------
# Temporary Admins / Object Config
# ---------------------------------------------------------------------------

@rule("A-AdminSDHolder", CATEGORY, "TemporaryAdmins", "Non-standard trustees hold rights on AdminSDHolder")
def r_adminsdholder(ctx) -> Finding:
    dn = f"CN=AdminSDHolder,CN=System,{ctx.base_dn}"
    entries = ctx.search_with_sd(dn, "(objectClass=*)", attributes=["distinguishedName"], scope="BASE")
    out = []
    if entries:
        raw = ctx.get_raw_sd_bytes(entries[0])
        if raw:
            sd = parse_security_descriptor(raw)
            # Deny-aware, domain-aware, and covers WRITE_PROP/SELF_WRITE/
            # CONTROL_ACCESS edges the old 0xF0000000 mask missed entirely.
            out.extend(effective_dangerous_aces(sd, ctx.domain_sid))
            if sd.malformed_ace_count:
                out.append({"trustee_sid": "(unparseable)",
                            "detail": f"{sd.malformed_ace_count} ACE(s) on AdminSDHolder could not be parsed "
                                      "- review this object manually rather than treating it as clean"})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-AdminSDHolder", CATEGORY, "TemporaryAdmins",
                    "Non-standard trustees hold rights on AdminSDHolder", status,
                    f"{len(out)} non-standard trustee(s) hold broad/dangerous rights on AdminSDHolder.", out)


@rule("A-BadSuccessor", CATEGORY, "ObjectConfig", "OU delegation permits dMSA creation (BadSuccessor)")
def r_bad_successor(ctx) -> Finding:
    """BadSuccessor is not about dMSA objects existing -- it is about a
    non-privileged principal being able to CREATE or CONTROL a
    msDS-DelegatedManagedServiceAccount in an OU, which lets them designate it
    as the successor of a privileged account.

    Two preconditions gate exploitability (per SpecterOps' research and
    PingCastle's own rule): the domain must have a KDS root key, and there
    must be at least one Windows Server 2025 DC. Without both, the technique
    does not work, so we report NOT_APPLICABLE rather than a false alarm.
    """
    # Precondition 1: a KDS root key must exist (gMSA/dMSA infrastructure)
    kds_keys = ctx.search(f"CN=Master Root Keys,CN=Group Key Distribution Service,"
                           f"CN=Services,{ctx.config_nc}",
                           "(objectClass=msKds-ProvRootKey)", attributes=["cn"])
    if not kds_keys:
        return Finding("A-BadSuccessor", CATEGORY, "ObjectConfig",
                        "OU delegation permits dMSA creation (BadSuccessor)", Status.NOT_APPLICABLE,
                        "No KDS root key present, so dMSA objects cannot be created at all "
                        "and the BadSuccessor technique does not apply.")

    # Precondition 2: at least one Windows Server 2025 DC
    dcs = ctx.search(ctx.base_dn, "(&(objectCategory=computer)(primaryGroupID=516))",
                      attributes=["operatingSystem", "dNSHostName"])
    has_2025 = any("2025" in str(get_attr(d, "operatingSystem", "")) for d in dcs)
    if not has_2025:
        return Finding("A-BadSuccessor", CATEGORY, "ObjectConfig",
                        "OU delegation permits dMSA creation (BadSuccessor)", Status.NOT_APPLICABLE,
                        "No Windows Server 2025 Domain Controller found; dMSA succession is not "
                        "supported by older DCs, so the BadSuccessor technique does not apply here.")

    # Both preconditions met -- now look for OUs whose ACL lets a non-privileged
    # principal create or control child objects (dMSAs are created as children).
    out = []
    for e in ctx.search_with_sd(ctx.base_dn, "(objectClass=organizationalUnit)",
                                 attributes=["distinguishedName"]):
        raw = ctx.get_raw_sd_bytes(e)
        if not raw:
            continue
        sd = parse_security_descriptor(raw)
        for hit in effective_dangerous_aces(
                sd, ctx.domain_sid,
                mask=(ACCESS_MASK["CREATE_CHILD"] | ACCESS_MASK["GENERIC_ALL"]
                      | ACCESS_MASK["WRITE_DACL"] | ACCESS_MASK["WRITE_OWNER"]
                      | ACCESS_MASK["GENERIC_WRITE"])):
            out.append({"ou": str(get_attr(e, "distinguishedName", "")), **hit})

    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-BadSuccessor", CATEGORY, "ObjectConfig",
                    "OU delegation permits dMSA creation (BadSuccessor)", status,
                    f"KDS root key present and a Windows Server 2025 DC exists, so the technique is "
                    f"viable. {len(out)} OU delegation(s) grant a non-privileged principal create/control "
                    "rights that would permit creating a dMSA. Note: this flags create/control rights over "
                    "ALL child object types (the ACE is rarely scoped specifically to the dMSA class), so "
                    "confirm the delegation is genuinely unintended before reporting.", out[:200])
