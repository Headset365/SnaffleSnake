"""
Trusts rules (PingCastle category `T-*`, plus the one `S-Domain$$$` rule
PingCastle files under Trusts/SIDHistory).
"""
from __future__ import annotations

from ..models import rule, not_implemented, Finding, Status
from ..utils import filetime_to_datetime, days_since, get_attr, get_attr_list, bin_sid_to_str, sid_to_rid

CATEGORY = "Trusts"

TRUST_ATTR_NON_TRANSITIVE = 0x1
TRUST_ATTR_UPLEVEL_ONLY = 0x2
TRUST_ATTR_QUARANTINED_DOMAIN = 0x4
TRUST_ATTR_FOREST_TRANSITIVE = 0x8
TRUST_ATTR_WITHIN_FOREST = 0x20
TRUST_ATTR_USES_RC4_ENCRYPTION = 0x80


def _list_trusts(ctx):
    if "trusts" in ctx._cache:
        return ctx._cache["trusts"]
    entries = ctx.search(f"CN=System,{ctx.base_dn}", "(objectClass=trustedDomain)",
                          attributes=["trustPartner", "trustDirection", "trustType", "trustAttributes",
                                      "flatName", "whenChanged", "securityIdentifier",
                                      "msDS-SupportedEncryptionTypes"])
    out = []
    for e in entries:
        try:
            attrs = int(get_attr(e, "trustAttributes", 0) or 0)
        except (TypeError, ValueError):
            attrs = 0
        try:
            enc = int(get_attr(e, "msDS-SupportedEncryptionTypes", 0) or 0)
        except (TypeError, ValueError):
            enc = 0
        try:
            ttype = int(get_attr(e, "trustType", 0) or 0)
        except (TypeError, ValueError):
            ttype = 0
        try:
            tdir = int(get_attr(e, "trustDirection", 0) or 0)
        except (TypeError, ValueError):
            tdir = 0
        out.append({
            "enc_types": enc,
            "trust_type": ttype,
            "trust_dir": tdir,
            "partner": str(get_attr(e, "trustPartner", "")),
            "flat_name": str(get_attr(e, "flatName", "")),
            "direction": get_attr(e, "trustDirection"),
            "type": get_attr(e, "trustType"),
            "attributes": attrs,
            "when_changed": get_attr(e, "whenChanged"),
        })
    ctx._cache["trusts"] = out
    return out


@rule("T-AlgsAES", CATEGORY, "OldTrustProtocol", "Trust does not have AES enabled")
def r_trust_aes(ctx) -> Finding:
    """Upstream reads msDS-SupportedEncryptionTypes on the trustedDomain object
    and triggers when it is 0 ("Not Configured") or has neither AES bit
    (0x8 | 0x10). Outbound-only trusts (trustDirection == 2) are skipped.

    This previously tested a supposed RC4 bit (0x80) in `trustAttributes` --
    the wrong attribute entirely; that bit is not the encryption setting.
    """
    out = []
    for t in _list_trusts(ctx):
        if t["trust_dir"] == 2:      # outbound-only: not our side to fix
            continue
        if t["enc_types"] == 0:
            out.append({"partner": t["partner"], "state": "Not Configured"})
        elif not (t["enc_types"] & (ENCTYPE_AES128 | ENCTYPE_AES256)):
            out.append({"partner": t["partner"], "state": "AES not enabled",
                        "supportedEncryptionTypes": t["enc_types"]})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-AlgsAES", CATEGORY, "OldTrustProtocol", "Trust does not have AES enabled",
                    status, f"{len(out)} inbound/bidirectional trust(s) lack AES Kerberos support.", out)


@rule("T-Downlevel", CATEGORY, "OldTrustProtocol", "Downlevel (Windows NT) trust present")
def r_trust_downlevel(ctx) -> Finding:
    """Upstream tests `trustType == 1` (TRUST_TYPE_DOWNLEVEL, a Windows NT-era
    trust). This previously inspected an UPLEVEL_ONLY bit in `trustAttributes`,
    which is a different field and does not encode the trust type.
    """
    out = [{"partner": t["partner"], "trustType": t["trust_type"]}
           for t in _list_trusts(ctx) if t["trust_type"] == 1]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-Downlevel", CATEGORY, "OldTrustProtocol",
                    "Downlevel (Windows NT) trust present", status,
                    f"{len(out)} trust(s) are TRUST_TYPE_DOWNLEVEL (Windows NT), which cannot use "
                    "Kerberos and falls back to NTLM.", out)


@rule("T-SIDFiltering", CATEGORY, "SIDFiltering", "SID filtering disabled on an external trust")
def r_sid_filtering(ctx) -> Finding:
    trusts = _list_trusts(ctx)
    out = []
    for t in trusts:
        is_within_forest = bool(t["attributes"] & TRUST_ATTR_WITHIN_FOREST)
        is_forest_transitive = bool(t["attributes"] & TRUST_ATTR_FOREST_TRANSITIVE)
        if is_within_forest:
            continue  # SID filtering is not applicable to intra-forest trusts
        quarantined = bool(t["attributes"] & TRUST_ATTR_QUARANTINED_DOMAIN)
        if not quarantined:
            out.append(t)
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-SIDFiltering", CATEGORY, "SIDFiltering", "SID filtering disabled on an external trust",
                    status, f"{len(out)} external/forest trust(s) do not have SID filtering (quarantine) enabled.",
                    [{"partner": t["partner"]} for t in out])


@rule("T-Inactive", CATEGORY, "TrustInactive", "Trust appears inactive")
def r_trust_inactive(ctx) -> Finding:
    """Upstream: a trust is active if its trustedDomain object was modified
    within the last 40 days (the trust password rotates on that cadence).
    This previously used the interdomain trust ACCOUNT's lastLogonTimestamp
    with a 90-day window -- a different object and a different threshold.
    """
    out = []
    for t in _list_trusts(ctx):
        age = days_since(t.get("when_changed"))
        if age is None or age > 40:
            out.append({"partner": t["partner"], "days_since_change": age})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-Inactive", CATEGORY, "TrustInactive", "Trust appears inactive", status,
                    f"{len(out)} trust(s) have not been updated in over 40 days, indicating the "
                    "trust password is no longer rotating.", out)


@rule("T-AzureADSSO", CATEGORY, "TrustAzure", "Azure AD Seamless SSO computer account not rotated")
def r_azure_sso(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(sAMAccountName=AZUREADSSOACC$)", attributes=["pwdLastSet"])
    if not entries:
        return Finding("T-AzureADSSO", CATEGORY, "TrustAzure",
                        "Azure AD Seamless SSO computer account not rotated", Status.NOT_APPLICABLE,
                        "AZUREADSSOACC$ not found; Seamless SSO not in use.")
    d = days_since(filetime_to_datetime(get_attr(entries[0], "pwdLastSet")))
    # Upstream threshold is one YEAR (AddYears(1)), not 40 days.
    status = Status.TRIGGERED if d is not None and d >= 365 else Status.CLEAN
    return Finding("T-AzureADSSO", CATEGORY, "TrustAzure",
                    "Azure AD Seamless SSO computer account not rotated", status,
                    f"AZUREADSSOACC$ password age = {d} days (upstream flags at 1 year; Microsoft recommends "
                    f"rotating every 30 days; "
                    "compromise of this account's Kerberos key can forge Entra ID tokens).")


def _script_path_out_of_domain(ctx):
    entries = ctx.search(ctx.base_dn, "(scriptPath=*)", attributes=["sAMAccountName", "scriptPath"])
    out = []
    for e in entries:
        path = str(get_attr(e, "scriptPath", ""))
        if path.startswith("\\\\") and ctx.domain.lower() not in path.lower():
            out.append({"account": str(get_attr(e, "sAMAccountName", "")), "scriptPath": path})
    return out


@rule("T-ScriptOutOfDomain", CATEGORY, "TrustImpermeability",
      "Logon script hosted outside the domain", requires=("ldap", "smb"))
def r_script_out_of_domain(ctx) -> Finding:
    """Upstream inspects BOTH the per-user `scriptPath` logon scripts AND
    GPO-delivered logon scripts. Only the former was checked here, so a script
    pushed by GPO from a foreign UNC path was invisible.
    """
    out = _script_path_out_of_domain(ctx)   # per-user scriptPath

    # GPO logon scripts live in Scripts.ini under the GPO's User/Machine folder.
    from .. import gpo as gpomod
    import re as _re
    for g in gpomod.list_gpos(ctx):
        for scope in ("USER", "MACHINE"):
            raw = gpomod._smb_read(ctx, gpomod.gpo_relative_path(g, f"{scope}\\Scripts\\scripts.ini"))
            if not raw:
                continue
            text = raw.decode("utf-16-le", errors="ignore") or raw.decode("utf-8", errors="ignore")
            for m in _re.finditer(r"CmdLine\s*=\s*(.+)", text, _re.IGNORECASE):
                path = m.group(1).strip().strip('"')
                if path.startswith("\\\\") and ctx.domain.lower() not in path.lower():
                    out.append({"gpo": g.display_name, "scope": scope, "scriptPath": path})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-ScriptOutOfDomain", CATEGORY, "TrustImpermeability",
                    "Logon script hosted outside the domain", status,
                    f"{len(out)} logon script reference(s) point outside the local domain "
                    "(covers both per-user scriptPath and GPO-delivered scripts).", out)


not_implemented("T-FileDeployedOutOfDomain", CATEGORY, "TrustImpermeability",
                 "GPO-referenced file hosted outside the domain",
                 "Requires parsing every GPO's software-installation/file-deployment settings for UNC paths, "
                 "cross-referenced against the domain name; not yet implemented.", requires=("ldap", "smb"))
not_implemented("T-TGTDelegation", CATEGORY, "TrustImpermeability", "Trust allows TGT delegation",
                 "Controlled by a DC-side netdom/registry setting rather than an LDAP-visible trust attribute; "
                 "would need remote registry/WMI access to each DC. Not implemented to avoid guessing.")

# ---------------------------------------------------------------------------
# SID History
# ---------------------------------------------------------------------------

@rule("S-Domain$$$", CATEGORY, "SIDHistory", "ADMT SID-history auditing group present")
def r_domain_triple_dollar(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn, "(cn=*$$$)", attributes=["cn"])
    out = [{"group": str(get_attr(e, "cn", ""))} for e in entries]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("S-Domain$$$", CATEGORY, "SIDHistory", "ADMT SID-history auditing group present",
                    status, f"{len(out)} '$$$' migration-auditing group(s) found (leftover from an ADMT SID-history migration).", out)


def _sidhistory_scan(ctx):
    if "sidhistory_scan" in ctx._cache:
        return ctx._cache["sidhistory_scan"]
    entries = ctx.search(ctx.base_dn, "(sidHistory=*)", attributes=["sAMAccountName", "sidHistory"])
    trusted_partner_sids = set()
    for t in _list_trusts(ctx):
        pass  # trustedDomain doesn't reliably expose the partner's own domain SID in `securityIdentifier` on all AD versions
    out = []
    for e in entries:
        raw_values = e["sidHistory"].raw_values if "sidHistory" in e else []
        for raw in raw_values:
            sid = bin_sid_to_str(raw)
            out.append({"account": str(get_attr(e, "sAMAccountName", "")), "sid_history": sid})
    ctx._cache["sidhistory_scan"] = out
    return out


@rule("T-SIDHistoryDangerous", CATEGORY, "SIDHistory", "SIDHistory references a built-in privileged SID")
def r_sidhistory_dangerous(ctx) -> Finding:
    """Upstream's DangerousSID test is simply RID < 1000 -- i.e. ANY built-in or
    well-known principal, not just Domain/Enterprise Admins. This previously
    used a hand-picked list of five RIDs (512/519/518/544/500), missing every
    other built-in (Account Operators, Backup Operators, Server Operators,
    Print Operators, Cert Publishers, and so on).
    """
    scan = _sidhistory_scan(ctx)
    out = []
    for row in scan:
        rid = sid_to_rid(row["sid_history"])
        if rid is not None and rid < 1000:
            out.append({**row, "rid": rid})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-SIDHistoryDangerous", CATEGORY, "SIDHistory",
                    "SIDHistory references a built-in privileged SID", status,
                    f"{len(out)} sidHistory value(s) carry a RID below 1000, meaning they impersonate "
                    "a built-in principal from another domain.", out)


@rule("T-SIDHistorySameDomain", CATEGORY, "SIDHistory", "SIDHistory value belongs to this domain (anomalous)")
def r_sidhistory_same_domain(ctx) -> Finding:
    scan = _sidhistory_scan(ctx)
    out = [row for row in scan if row["sid_history"].rsplit("-", 1)[0] == ctx.domain_sid]
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-SIDHistorySameDomain", CATEGORY, "SIDHistory",
                    "SIDHistory value belongs to this domain (anomalous)", status,
                    f"{len(out)} sidHistory value(s) reference this domain's own SID (not a real migration artifact).", out)


@rule("T-SIDHistoryUnknownDomain", CATEGORY, "SIDHistory", "SIDHistory references an unresolvable domain")
def r_sidhistory_unknown_domain(ctx) -> Finding:
    scan = _sidhistory_scan(ctx)
    known_prefixes = {ctx.domain_sid} | {t["partner"] for t in _list_trusts(ctx)}
    out = []
    for row in scan:
        prefix = row["sid_history"].rsplit("-", 1)[0]
        if prefix != ctx.domain_sid:
            # We can't fully resolve trust partner SIDs from securityIdentifier reliably across all
            # AD versions in this pass, so this flags any history from a domain SID that isn't our own -
            # cross-reference the listed trusts manually to rule out expected migration sources.
            out.append(row)
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("T-SIDHistoryUnknownDomain", CATEGORY, "SIDHistory",
                    "SIDHistory references an unresolvable domain", status,
                    f"{len(out)} sidHistory value(s) reference a foreign domain SID - cross-check against "
                    f"known trusts ({[t['partner'] for t in _list_trusts(ctx)]}) to rule out legitimate migrations.",
                    out[:200])
