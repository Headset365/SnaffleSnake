"""
Anomalies / PassTheCredential and LocalGroupVulnerability subcategories.

`A-DC-Coerce` / `A-DC-Spooler` / `A-DC-WebClient` check for *exposure* of the
vulnerable service/interface (an RPC endpoint-mapper query or a port-reachability
check) -- the same thing a port scanner does. None of them issue the actual
coercion call (e.g. EfsRpcOpenFileRaw / RpcRemoteFindFirstPrinterChangeNotification);
that would cross from enumeration into an active technique and is deliberately
out of scope.
"""
from __future__ import annotations

from ..constants import UAC_ACCOUNTDISABLE, UAC_SMARTCARD_REQUIRED
from ..models import rule, not_implemented, Finding, Status
from ..utils import filetime_to_datetime, days_since, get_attr

CATEGORY = "Anomalies"

# ---------------------------------------------------------------------------
# LAPS coverage
# ---------------------------------------------------------------------------

def _laps_schema_present(ctx):
    if "laps_schema" in ctx._cache:
        return ctx._cache["laps_schema"]
    legacy = ctx.search(ctx.schema_nc, "(lDAPDisplayName=ms-Mcs-AdmPwd)", attributes=["lDAPDisplayName"])
    modern = ctx.search(ctx.schema_nc, "(lDAPDisplayName=msLAPS-Password)", attributes=["lDAPDisplayName"])
    result = {"legacy": bool(legacy), "modern": bool(modern)}
    ctx._cache["laps_schema"] = result
    return result


@rule("A-LAPS-Not-Installed", CATEGORY, "PassTheCredential", "LAPS not deployed in the domain")
def r_laps_not_installed(ctx) -> Finding:
    schema = _laps_schema_present(ctx)
    installed = schema["legacy"] or schema["modern"]
    status = Status.CLEAN if installed else Status.TRIGGERED
    return Finding("A-LAPS-Not-Installed", CATEGORY, "PassTheCredential", "LAPS not deployed in the domain",
                    status, f"Legacy LAPS schema present: {schema['legacy']}; Windows LAPS schema present: {schema['modern']}.")


@rule("A-LAPS-Joined-Computers", CATEGORY, "PassTheCredential", "Proportion of computers not covered by LAPS")
def r_laps_coverage(ctx) -> Finding:
    schema = _laps_schema_present(ctx)
    if not (schema["legacy"] or schema["modern"]):
        return Finding("A-LAPS-Joined-Computers", CATEGORY, "PassTheCredential",
                        "Proportion of computers not covered by LAPS", Status.NOT_APPLICABLE,
                        "LAPS is not deployed at all (see A-LAPS-Not-Installed).")
    total = ctx.search(ctx.base_dn, f"(&(objectCategory=computer)(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE})))",
                        attributes=["sAMAccountName"])
    # Read the expiration-time attribute rather than the password itself: it is
    # typically NOT ACL-restricted the way the password value is, so this stays
    # usable from an unprivileged account -- see the earlier conversation about
    # LAPS being the one genuinely ACL-protected value.
    covered_attr = "ms-Mcs-AdmPwdExpirationTime" if schema["legacy"] else "msLAPS-PasswordExpirationTime"
    covered = ctx.search(ctx.base_dn, f"(&(objectCategory=computer)({covered_attr}=*))", attributes=["sAMAccountName"])
    total_n, covered_n = len(total), len(covered)
    pct = (covered_n / total_n * 100) if total_n else 0
    status = Status.TRIGGERED if pct < 95 else Status.CLEAN
    return Finding("A-LAPS-Joined-Computers", CATEGORY, "PassTheCredential",
                    "Proportion of computers not covered by LAPS", status,
                    f"{covered_n}/{total_n} computers ({pct:.1f}%) have a LAPS expiration timestamp set.")


@rule("A-ProtectedUsers", CATEGORY, "PassTheCredential",
      "Schema too old to support the Protected Users group")
def r_protected_users_domainwide(ctx) -> Finding:
    """Upstream this is a SCHEMA VERSION test: `SchemaVersion < 69` means the
    forest schema predates Windows Server 2012 R2, so the Protected Users group
    does not exist and the mitigation is unavailable domain-wide.

    The previous implementation counted members of the Protected Users group --
    a different question entirely, and one already covered for privileged
    accounts by P-ProtectedUsers.
    """
    entries = ctx.search(ctx.schema_nc, "(objectClass=*)", scope="BASE",
                          attributes=["objectVersion"])
    version = get_attr(entries[0], "objectVersion") if entries else None
    try:
        version = int(version)
    except (TypeError, ValueError):
        return Finding("A-ProtectedUsers", CATEGORY, "PassTheCredential",
                        "Schema too old to support the Protected Users group", Status.ERROR,
                        "Could not read the schema objectVersion to establish support.")
    too_old = version < 69
    status = Status.TRIGGERED if too_old else Status.CLEAN
    return Finding("A-ProtectedUsers", CATEGORY, "PassTheCredential",
                    "Schema too old to support the Protected Users group", status,
                    f"Forest schema objectVersion = {version} "
                    f"({'below' if too_old else 'meets'} the 69 / Windows Server 2012 R2 baseline "
                    "required for the Protected Users group).")


@rule("A-SmartCardRequired", CATEGORY, "PassTheCredential",
      "Smart-card-required accounts whose password hash has not rotated")
def r_smartcard_required(ctx) -> Finding:
    """PingCastle does NOT flag smart-card usage itself (that is good practice).
    It flags ENABLED smart-card-required accounts whose underlying NT hash has
    not changed in 91+ days: when SMARTCARD_REQUIRED is set, AD generates a
    random password once and never rotates it, so a stale hash stays valid
    indefinitely for pass-the-hash.

    PingCastle reads the true hash-change time from replication metadata for
    unicodePwd. We approximate with pwdLastSet, which tracks the same event in
    the common case and needs only a normal LDAP read.
    """
    entries = ctx.search(
        ctx.base_dn,
        f"(&(objectCategory=person)(objectClass=user)"
        f"(!(userAccountControl:1.2.840.113556.1.4.803:={UAC_ACCOUNTDISABLE}))"
        f"(userAccountControl:1.2.840.113556.1.4.803:={UAC_SMARTCARD_REQUIRED}))",
        attributes=["sAMAccountName", "pwdLastSet"])
    total = len(entries)
    out = []
    for e in entries:
        d = days_since(filetime_to_datetime(get_attr(e, "pwdLastSet")))
        if d is None or d >= 91:
            out.append({"account": str(get_attr(e, "sAMAccountName", "")), "hash_age_days": d})
    if total == 0:
        return Finding("A-SmartCardRequired", CATEGORY, "PassTheCredential",
                        "Smart-card-required accounts whose password hash has not rotated",
                        Status.NOT_APPLICABLE,
                        "No enabled accounts have the smart-card-required flag set.")
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-SmartCardRequired", CATEGORY, "PassTheCredential",
                    "Smart-card-required accounts whose password hash has not rotated", status,
                    f"{len(out)} of {total} enabled smart-card-required account(s) have a password hash "
                    "older than 91 days (approximated via pwdLastSet). Rotate by toggling the "
                    "smart-card-required flag off and on.", out)


@rule("A-SmartCardPwdRotation", CATEGORY, "PassTheCredential", "Smart-card accounts' password rotation status")
def r_smartcard_pwd_rotation(ctx) -> Finding:
    entries = ctx.search(ctx.base_dn,
                          f"(&(objectCategory=person)(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:={UAC_SMARTCARD_REQUIRED}))",
                          attributes=["sAMAccountName", "pwdLastSet"])
    out = []
    for e in entries:
        d = days_since(filetime_to_datetime(get_attr(e, "pwdLastSet")))
        if d is not None and d >= 365:
            out.append({"account": str(get_attr(e, "sAMAccountName", "")), "password_age_days": d})
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-SmartCardPwdRotation", CATEGORY, "PassTheCredential",
                    "Smart-card accounts' password rotation status", status,
                    f"{len(out)} smart-card-required account(s) with password 1+ year old.", out)


def _rpc_endpoint_reachable(host, uuid_str, timeout=5):
    """Query the target's RPC endpoint mapper (port 135) for a given interface
    UUID. This mirrors what `rpcdump.py`/`Get-NetRPCInterface`-style tools do:
    it only asks 'is this interface registered', never calls a method on it."""
    try:
        from impacket.dcerpc.v5 import transport, epm
        strbinding = f"ncacn_ip_tcp:{host}[135]"
        rpctransport = transport.DCERPCTransportFactory(strbinding)
        rpctransport.set_connect_timeout(timeout)
        dce = rpctransport.get_dce_rpc()
        dce.connect()
        entries = epm.hept_lookup(host, inet_utils=True) if hasattr(epm, "hept_lookup") else []
        dce.disconnect()
        return any(uuid_str.lower() in str(e).lower() for e in entries)
    except Exception:
        return None  # inconclusive, not "clean"


@rule("A-DC-Spooler", CATEGORY, "PassTheCredential", "Print Spooler exposed on Domain Controllers",
      requires=("ldap", "smb"))
def r_dc_spooler(ctx) -> Finding:
    try:
        from impacket.dcerpc.v5 import transport
    except ImportError:
        return Finding("A-DC-Spooler", CATEGORY, "PassTheCredential", "Print Spooler exposed on Domain Controllers",
                        Status.REQUIRES_SMB, "impacket not installed.")
    out = []
    for dc in ctx.dc_hostnames:
        try:
            rpctransport = transport.DCERPCTransportFactory(f"ncacn_np:{dc}[\\pipe\\spoolss]")
            rpctransport.set_credentials(ctx.smb_username or "", ctx.smb_password or "", ctx.smb_domain or "")
            dce = rpctransport.get_dce_rpc()
            dce.connect()
            dce.disconnect()
            out.append({"dc": dc})
        except Exception:
            continue
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-DC-Spooler", CATEGORY, "PassTheCredential", "Print Spooler exposed on Domain Controllers",
                    status, f"{len(out)} DC(s) have the \\pipe\\spoolss named pipe reachable "
                    "(Print Spooler running -- PrinterBug/coercion surface). Connection only; no coercion call issued.", out)


@rule("A-DC-WebClient", CATEGORY, "PassTheCredential", "WebClient (WebDAV) service exposed on Domain Controllers",
      requires=("ldap", "smb"))
def r_dc_webclient(ctx) -> Finding:
    import socket as _socket
    out = []
    for dc in ctx.dc_hostnames:
        try:
            with _socket.create_connection((dc, 6001), timeout=3):
                out.append({"dc": dc, "port": 6001})
        except Exception:
            continue
    status = Status.TRIGGERED if out else Status.CLEAN
    return Finding("A-DC-WebClient", CATEGORY, "PassTheCredential",
                    "WebClient (WebDAV) service exposed on Domain Controllers", status,
                    f"{len(out)} DC(s) have the WebClient service port (6001) open "
                    "(HTTP-based coercion surface, e.g. as an alternative to SMB-based PetitPotam).", out)


@rule("A-DC-Coerce", CATEGORY, "PassTheCredential",
      "Outbound NTLM not restricted on Domain Controllers", requires=("ldap", "smb"))
def r_dc_coerce(ctx) -> Finding:
    """Upstream this is NOT an RPC probe -- it is a MITIGATION check. PingCastle
    looks for a GPO applying to the Domain Controllers OU (or the domain root)
    that sets `MSV1_0\\RestrictSendingNTLMTraffic` to 2 ("Deny all"). If that
    mitigation is present the rule is suppressed; otherwise the DCs are
    considered exposed to coercion-to-relay chains such as PetitPotam.

    The previous implementation performed an EFSRPC bind probe instead. That
    tests something real but different (is the interface reachable), and it is
    not what this rule ID means. The bind probe is retained below purely as
    supplementary evidence, and never changes the verdict.
    """
    from .. import gpo as gpomod
    mitigated_by = []
    for g in gpomod.list_gpos(ctx):
        tmpl = gpomod.fetch_gpttmpl(ctx, g)
        if not tmpl:
            continue
        for k, v in tmpl.get("Registry Values", {}).items():
            if k.lower().endswith("restrictsendingntlmtraffic"):
                try:
                    if int(str(v).split(",")[-1]) == 2:
                        mitigated_by.append({"gpo": g.display_name, "setting": "RestrictSendingNTLMTraffic=2"})
                except ValueError:
                    continue
    if mitigated_by:
        return Finding("A-DC-Coerce", CATEGORY, "PassTheCredential",
                        "Outbound NTLM not restricted on Domain Controllers", Status.CLEAN,
                        "A GPO sets RestrictSendingNTLMTraffic=2 (Deny all), which mitigates "
                        "coercion-to-NTLM-relay against the DCs.", mitigated_by)

    # Supplementary only: is the EFSRPC interface bindable? Bind-only, never a
    # method call, and does not alter the verdict above.
    reachable = []
    try:
        from impacket.dcerpc.v5 import transport
        from impacket.uuid import uuidtup_to_bin
        for dc in ctx.dc_hostnames:
            try:
                rt = transport.DCERPCTransportFactory(f"ncacn_np:{dc}[\\pipe\\lsarpc]")
                rt.set_credentials(ctx.smb_username or "", ctx.smb_password or "", ctx.smb_domain or "")
                dce = rt.get_dce_rpc()
                dce.connect()
                dce.bind(uuidtup_to_bin(("c681d488-d850-11d0-8c52-00c04fd90f7e", "1.0")))
                dce.disconnect()
                reachable.append({"dc": dc, "efsrpc_interface": "bindable"})
            except Exception:
                continue
    except ImportError:
        pass
    return Finding("A-DC-Coerce", CATEGORY, "PassTheCredential",
                    "Outbound NTLM not restricted on Domain Controllers", Status.TRIGGERED,
                    "No GPO restricts outbound NTLM on the Domain Controllers "
                    "(RestrictSendingNTLMTraffic=2 not found), so coercion-to-relay chains are "
                    f"not mitigated. Supplementary: {len(reachable)} DC(s) accepted an EFSRPC "
                    "interface bind (bind-only probe, no method invoked).", reachable)


not_implemented("A-DCRefuseComputerPwdChange", CATEGORY, "PassTheCredential", "DC configured to refuse machine pwd changes",
                 "Lives in DC-local registry (Netlogon parameters), needs remote registry/WMI access to each DC "
                 "which requires local admin rights on that host -- out of scope for a directory-read-only account.")
not_implemented("A-MembershipEveryone", CATEGORY, "LocalGroupVulnerability",
                 "Sensitive local group includes Everyone/broad principals",
                 "Requires SAMR queries against each individual host's local SAM database (not a domain-wide AD "
                 "object), needing either local admin or at minimum a SAMR-permitted read on every target -- a "
                 "materially different scope than the DC-focused checks above. Consider extending with impacket's "
                 "samr.hSamrEnumerateAliasesInDomain per host if you want this.")
