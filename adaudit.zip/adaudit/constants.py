"""
Constants used across rule implementations: userAccountControl bit flags,
msDS-SupportedEncryptionTypes bits, well-known RIDs, AD CS / extended-right
GUIDs, and obsolete-OS detection patterns.

All values are from public Microsoft documentation (MS-ADTS, MS-SAMR) and
well-known AD security research (adsecurity.org, MS-DTYP). Nothing here
executes any action; it is purely lookup data used to interpret LDAP
attribute values that were read with a normal authenticated bind.
"""

# ---------------------------------------------------------------------------
# userAccountControl bit flags (MS-SAMR 2.2.1.13)
# ---------------------------------------------------------------------------
UAC_SCRIPT = 0x0001
UAC_ACCOUNTDISABLE = 0x0002
UAC_HOMEDIR_REQUIRED = 0x0008
UAC_LOCKOUT = 0x0010
UAC_PASSWD_NOTREQD = 0x0020
UAC_PASSWD_CANT_CHANGE = 0x0040
UAC_ENCRYPTED_TEXT_PWD_ALLOWED = 0x0080
UAC_TEMP_DUPLICATE_ACCOUNT = 0x0100
UAC_NORMAL_ACCOUNT = 0x0200
UAC_INTERDOMAIN_TRUST_ACCOUNT = 0x0800
UAC_WORKSTATION_TRUST_ACCOUNT = 0x1000
UAC_SERVER_TRUST_ACCOUNT = 0x2000
UAC_DONT_EXPIRE_PASSWORD = 0x10000
UAC_MNS_LOGON_ACCOUNT = 0x20000
UAC_SMARTCARD_REQUIRED = 0x40000
UAC_TRUSTED_FOR_DELEGATION = 0x80000
UAC_NOT_DELEGATED = 0x100000
UAC_USE_DES_KEY_ONLY = 0x200000
UAC_DONT_REQUIRE_PREAUTH = 0x400000
UAC_PASSWORD_EXPIRED = 0x800000
UAC_TRUSTED_TO_AUTH_FOR_DELEGATION = 0x1000000
UAC_PARTIAL_SECRETS_ACCOUNT = 0x04000000

# ---------------------------------------------------------------------------
# msDS-SupportedEncryptionTypes bits (MS-ADTS / MS-KILE)
# ---------------------------------------------------------------------------
ENCTYPE_DES_CBC_CRC = 0x1
ENCTYPE_DES_CBC_MD5 = 0x2
ENCTYPE_RC4_HMAC = 0x4
ENCTYPE_AES128 = 0x8
ENCTYPE_AES256 = 0x10

# ---------------------------------------------------------------------------
# Well-known RIDs (last component of a domain SID) -> friendly name
# ---------------------------------------------------------------------------
WELL_KNOWN_RID = {
    500: "Administrator",
    502: "krbtgt",
    512: "Domain Admins",
    513: "Domain Users",
    514: "Domain Guests",
    515: "Domain Computers",
    516: "Domain Controllers",
    517: "Cert Publishers",
    518: "Schema Admins",
    519: "Enterprise Admins",
    520: "Group Policy Creator Owners",
    521: "Read-only Domain Controllers",
    522: "Cloneable Domain Controllers",
    553: "RAS and IAS Servers",
    571: "Allowed RODC Password Replication Group",
    572: "Denied RODC Password Replication Group",
}

DEFAULT_PRIMARY_GROUP_IDS = {513, 514, 515, 516, 521}

# Groups that are expected/normal to hold high privilege — used to filter
# ACL-based findings down to "unexpected" trustees only.
PRIVILEGED_RID_SUFFIXES = {512, 519, 500, 518, 516, 521, 544}  # +544=Administrators (BUILTIN)

# ---------------------------------------------------------------------------
# Extended-right GUIDs relevant to security findings (MS-ADTS 5.1.3.2)
# ---------------------------------------------------------------------------
EXTENDED_RIGHTS = {
    "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2": "DS-Replication-Get-Changes",
    "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2": "DS-Replication-Get-Changes-All",
    "89e95b76-444d-4c62-991a-0facbeda640c": "DS-Replication-Get-Changes-In-Filtered-Set",
    "00299570-246d-11d0-a768-00aa006e0529": "User-Force-Change-Password",
    "1131f6ac-9c07-11d1-f79f-00c04fc2dcd2": "DS-Replication-Synchronize",
    "45ec5156-db7e-47bb-b53f-dbeb2d03c40f": "Reanimate-Tombstone",
    "ccc2dc7d-a6ad-4a7a-8846-c04e3cc53501": "Unexpire-Password",
    "037088f8-0ae1-11d2-b422-00a0c968f939": "Self-Membership",
    "bf9679c0-0de6-11d0-a285-00aa003049e2": "Self-Membership",  # Member attribute self-write
}
DCSYNC_GUIDS = {
    "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2",
    "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2",
}

# ---------------------------------------------------------------------------
# Access mask bits relevant to ACL findings (MS-DTYP 2.4.3)
# ---------------------------------------------------------------------------
ACCESS_MASK = {
    "GENERIC_READ": 0x80000000,
    "GENERIC_WRITE": 0x40000000,
    "GENERIC_EXECUTE": 0x20000000,
    "GENERIC_ALL": 0x10000000,
    "WRITE_OWNER": 0x00080000,
    "WRITE_DACL": 0x00040000,
    "READ_CONTROL": 0x00020000,
    "DELETE": 0x00010000,
    "CONTROL_ACCESS": 0x00000100,   # used together with ObjectType GUID
    "WRITE_PROP": 0x00000020,
    "READ_PROP": 0x00000010,
    "SELF_WRITE": 0x00000008,
    "CREATE_CHILD": 0x00000001,
    "DELETE_CHILD": 0x00000002,
}
DANGEROUS_RIGHTS_MASK = (
    ACCESS_MASK["GENERIC_ALL"]
    | ACCESS_MASK["GENERIC_WRITE"]
    | ACCESS_MASK["WRITE_OWNER"]
    | ACCESS_MASK["WRITE_DACL"]
)

# Broader mask used for object/attribute-level checks. Adds the rights that
# carry real AD attack edges but are NOT covered by the generic-write bits
# above: WRITE_PROP (e.g. writing `member` -> add self to a privileged group,
# or writing msDS-KeyCredentialLink -> Shadow Credentials), SELF_WRITE (the
# self-membership edge), and CONTROL_ACCESS (extended rights such as
# ForceChangePassword and the DS-Replication-Get-Changes* pair used by DCSync).
# Rules that check "can this trustee meaningfully modify this object" should
# use this, not DANGEROUS_RIGHTS_MASK alone.
DANGEROUS_RIGHTS_MASK_EXTENDED = (
    DANGEROUS_RIGHTS_MASK
    | ACCESS_MASK["WRITE_PROP"]
    | ACCESS_MASK["SELF_WRITE"]
    | ACCESS_MASK["CONTROL_ACCESS"]
)

# Attribute GUIDs that make a WRITE_PROP ACE dangerous when scoped to them.
DANGEROUS_WRITE_PROP_GUIDS = {
    "bf9679c0-0de6-11d0-a285-00aa003049e2": "member (add-member edge)",
    "5b47d60f-6090-40b2-9f37-2a4de88f3063": "msDS-KeyCredentialLink (Shadow Credentials)",
    "3f78c3e5-f79a-46bd-a0b8-9d18116ddc79": "msDS-AllowedToActOnBehalfOfOtherIdentity (RBCD)",
    "f30e3bbe-9ff0-11d1-b603-0000f80367c1": "gPLink",
    "f30e3bbf-9ff0-11d1-b603-0000f80367c1": "gPOptions",
}

# ---------------------------------------------------------------------------
# Obsolete OS detection: substring -> (rule_id_workstation, rule_id_dc)
# Matched against the `operatingSystem` attribute (case-insensitive).
# ---------------------------------------------------------------------------
OBSOLETE_OS_PATTERNS = [
    ("windows nt", "S-OS-NT", None),
    ("windows 2000", "S-OS-2000", "S-DC-2000"),
    ("windows xp", "S-OS-XP", None),
    ("windows vista", "S-OS-Vista", None),
    ("server 2003", "S-OS-2003", "S-DC-2003"),
    ("server 2008 r2", "S-OS-2008", "S-DC-2008"),
    ("server 2008", "S-OS-2008", "S-DC-2008"),
    ("windows 7", "S-OS-Win7", None),
    ("windows 8", "S-OS-Win8", None),  # note: matches "8.1" too, handled in rule
    ("server 2012", "S-OS-2012", "S-DC-2012"),
    ("windows 10", "S-OS-W10", None),
    ("windows 11", "S-OS-W10", None),
]

# Functional level integer -> friendly name (msDS-Behavior-Version / domainFunctionality)
FUNCTIONAL_LEVELS = {
    0: "Windows 2000",
    1: "Windows Server 2003 (mixed)",
    2: "Windows Server 2003",
    3: "Windows Server 2008",
    4: "Windows Server 2008 R2",
    5: "Windows Server 2012",
    6: "Windows Server 2012 R2",
    7: "Windows Server 2016",
    8: "Windows Server 2019/2022 (2016+ w/ no new FL)",
}
RECOMMENDED_MIN_FUNCTIONAL_LEVEL = 7

# FILETIME epoch offset: 1601-01-01 to 1970-01-01, in 100ns units
FILETIME_EPOCH_DIFF = 116444736000000000
