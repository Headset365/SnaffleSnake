# Rule Audit Plan — 142 remaining rules

## Where things stand

| | Count |
|---|---|
| Rules in PingCastle reference set | 187 |
| Implemented with real logic | 174 |
| Documented stubs (not in scope here) | 13 |
| **Audited against PingCastle source so far** | **32** |
| **Remaining to audit** | **142** |

Observed defect rate in the 32 audited: **6 bugs / 32 rules ≈ 19%**. If that holds,
expect roughly **25–30 more defects** across the remaining 142. That estimate is
what the batch sizing below is built around — it assumes finding bugs, not
confirming correctness.

## What "audit" means per rule

For each rule, side-by-side against its PingCastle `.cs` file (repo already cloned
at `/home/claude/pingcastle-src`, and every rule ID maps to a source file):

1. **LDAP filter** — same object class, same UAC bit tests, same exclusions
   (notably: does PingCastle exclude disabled accounts? Several of mine don't).
2. **Threshold + type** — count vs. percentage vs. presence. This is where every
   threshold bug so far has lived.
3. **Polarity** — does TRIGGERED mean the same thing in both? (`A-SmartCardRequired`
   was inverted in spirit: I flagged good practice as a finding.)
4. **Attribute names** — verified against the PingCastle source, not memory. Two
   silent-false-clean bugs came from this.
5. **Scope** — BASE vs SUBTREE for single-object reads.

Each batch ends with: fixes applied, a regression test added per bug found, full
test suite green, and the batch's rules marked audited in a tracking file.

---

## Batch order (highest expected defect density first)

### Batch 1 — Obsolete OS rules (14 rules) — **known-defective**
`S-OS-NT, S-OS-2000, S-OS-XP, S-OS-Vista, S-OS-2003, S-OS-2008, S-OS-Win7,
S-OS-Win8, S-OS-2012, S-OS-W10, S-DC-2000, S-DC-2003, S-DC-2008, S-DC-2012`

**Why first:** already confirmed broken. PingCastle uses count thresholds
(e.g. XP: 15 → severity 20, 6 → severity 15, else presence → 10). Mine trigger on
bare presence, so a single retired XP box reports identically to 200 of them.
Also needs checking: whether PingCastle counts only *enabled* machines, and how
it distinguishes "Windows 8" from "8.1" (my substring match is fragile), and
whether Windows 10/11 build-number logic applies to `S-OS-W10`.

**Expected outcome:** ~14 threshold corrections, one shared helper rewrite.
Highest fix-per-hour ratio in the whole plan — they share one code path.

---

### Batch 2 — Remaining Stale Objects (39 rules)
Everything under `StaleObjects` not in Batch 1: password-age rules, object-config
rules (`S-PwdNeverExpires`, `S-PwdNotRequired`, `S-Reversible`, `S-C-*`,
`S-NoPreAuth*`, `S-SIDHistory`, `S-DefaultOUChanged`, `S-JavaSchema`), provisioning,
replication, functional level, WSUS, and the auth-protocol rules.

**Why second:** largest category, and the two percentage-vs-count bugs already
found here suggest siblings. `S-DefaultOUChanged` is currently a NOT_APPLICABLE
placeholder that needs real `wellKnownObjects` GUID comparison — flagged as a known
gap, not a surprise.

---

### Batch 3 — Privileged Accounts, non-ACL (24 rules)
Delegation checks, `P-OperatorsEmpty`, `P-SchemaAdmin`, `P-DNSAdmin`,
`P-PrivilegeEveryone`, `P-TrustedCredManAccessPrivilege`, `P-DsHeuristics*`,
`P-Kerberoasting`, `P-Delegated`, `P-DisplaySpecifier`, `P-LogonDenied`,
`P-AdminLogin`, `P-ControlPathIndirect*`, `P-RODCKrbtgtOrphan`, `P-RODCAdminRevealed`.

**Why third:** highest *severity* if wrong (these are the privilege-escalation
findings a client acts on), but the ACL-heavy ones here were already covered in
v0.2.0, so the remaining surface is smaller than the count suggests.
`P-ControlPathIndirect*` needs an explicit decision: my nested-membership-only
implementation is a documented partial — confirm that's acceptable or promote it
to the stub list rather than leaving it looking complete.

---

### Batch 4 — Anomalies: non-certificate (37 rules)
`A-DsHeuristics*`, `A-PreWin2000*`, `A-NullSession`, `A-RootDseAnonBinding`,
`A-DnsZoneTransfert`, `A-LMHashAuthorized`, `A-SMB2Signature*`, `A-DCLdapSign`,
`A-NoGPOLLMNR`, `A-HardenedPaths`, `A-AuditDC`, `A-AuditPowershell`, `A-PwdGPO`,
`A-UnixPwd`, `A-Guest`, `A-MinPwdLen`, `A-NoServicePolicy`, `A-NotEnoughDC`,
`A-ProtectedUsers`, `A-DC-Spooler`, `A-DC-WebClient`, `A-DC-Coerce`, `A-LAPS-*`.

**Why fourth:** many are GPO-content checks whose *parsing* is already tested;
the risk is in which registry key/value is read and what value counts as
compliant. `A-DsHeuristics*` needs particular care — those are character-position
lookups into a single string, and an off-by-one silently inverts the result.

---

### Batch 5 — Anomalies: AD CS / certificates (18 rules)
All `A-Cert*`, `A-MD*`/`A-SHA*` hash rules, `A-WeakRSA*`, `A-DCLdapsProtocol*`,
`A-WSUS-SslProtocol`.

**Why fifth:** the ESC-family logic (`A-CertTempCustomSubject`, `A-CertTempAnyone`,
`A-CertTempAgent`) got a correctness pass in v0.2.0 already. The hash/key-size
rules are mechanically simple and low-risk. Main open question is whether
root/intermediate classification via `issuer == subject` matches PingCastle's.

---

### Batch 6 — Trusts (10 rules)
`T-AlgsAES`, `T-Downlevel`, `T-Inactive`, `T-AzureADSSO`, `T-ScriptOutOfDomain`,
`T-SIDHistory*`, `S-Domain$$$`.

**Why last:** smallest batch, and trust-attribute bit tests are the most
mechanical thing in the codebase. One known weakness to resolve:
`T-SIDHistoryUnknownDomain` can't currently resolve trust partner SIDs, so it
over-reports — decide whether to fix properly or downgrade to a documented
partial.

---

## Cross-cutting checks (fold into whichever batch touches them)

- **Disabled-account exclusion.** PingCastle excludes disabled accounts in most
  account rules. Several of mine don't. Worth a single sweep across all account
  rules rather than rule-by-rule.
- **`_inactive_search` threshold.** Hardcoded 180 days; confirm against
  PingCastle's actual inactivity window before Batch 2 depends on it.
- **`get_attr` vs `str(entry[...])`.** Mixed usage; the latter raises on missing
  attributes and is currently caught by the per-rule handler, turning a bug into
  a silent ERROR status.

## Order-of-operations rationale

Batch 1 first because the defects are already confirmed and share one code path —
fastest reduction in known-wrong output. Batches 2–4 are ordered by expected
defect count, front-loading discovery so the running estimate can be re-based
early. Batches 5–6 are last because they've had partial coverage already or are
mechanically simple.

If the defect rate in Batches 1–2 comes in materially below 19%, the later batches
can be compressed. If it comes in higher, the estimate for the remainder should be
revised upward before committing to a completion date — not after.

## Definition of done

- All 174 implemented rules marked audited in the tracking file.
- One regression test per defect found.
- `python3 tests/test_regression.py` and `test_smoke_all_rules.py` green.
- Any rule that can't be made faithful to PingCastle gets **demoted to a
  documented stub** rather than left looking complete — the stub list is the
  honesty mechanism and should grow if that's the truthful outcome.

---

# EXECUTION LOG

## Batch 1 — Obsolete OS (14 rules) — COMPLETE

**Audited:** S-OS-NT, S-OS-2000, S-OS-XP, S-OS-Vista, S-OS-2003, S-OS-2008,
S-OS-Win7, S-OS-Win8, S-OS-2012, S-OS-W10, S-DC-2000, S-DC-2003, S-DC-2008,
S-DC-2012.

**Defects found: 5** (all fixed)

1. **OS string matching was substring-based; PingCastle uses an ordered,
   first-match-wins regex table then EXACT equality.** Worst consequence:
   "Windows XP Embedded" normalises to "Windows Embedded" in PingCastle and is
   NOT an XP finding — the old substring match reported it as XP. Server SKUs
   also had to be matched before bare version numbers. Implemented the full
   16-entry table verbatim; 15 normalisation cases now covered by tests.

2. **Counted all non-disabled machines; PingCastle counts NumberActive
   (enabled AND recently authenticated).** A decommissioned XP box that hasn't
   logged on in a year was inflating findings. Now only active machines count,
   and the excluded stale count is reported alongside for context.

3. **`S-OS-W10` was fundamentally the wrong check.** It flagged every Windows 10
   machine. PingCastle parses the build from `operatingSystemVersion`
   ("10.0 (19045)") and flags only builds past end of servicing — a current
   build is fully supported. Rewritten with a build-number EOL table;
   `operatingSystemVersion` added to the LDAP query (it wasn't even requested
   before).

4. **`S-OS-2012` / `S-DC-2012` are date-gated in PingCastle** (not applicable
   before 2012's 2023-10-10 EOL). Now returns NOT_APPLICABLE before that date
   rather than a finding.

5. **Dead/tautological code in the Windows 8 branch** — a condition that could
   never be false, left over from an attempt to separate 8 from 8.1. Removed;
   the normalisation table handles 8.1 correctly.

**Correction to this plan's own premise:** the plan asserted these rules were
"known-defective" because they trigger on presence while PingCastle uses count
thresholds. That was wrong. PingCastle's `TriggerOnThreshold` tiers change the
*severity score*, not whether the rule fires — `TriggerOnPresence` at Order 3
means it triggers whenever the count exceeds zero. So triggered/clean polarity
was already correct. The tiers are now surfaced in each finding's summary as
context for the human reviewer, since scoring happens downstream.

**Tests:** 16 new regression checks (53 total, all passing). Smoke test green:
187/187 rules execute, both report formats intact.

**Revised estimate:** 5 defects in 14 rules = 36%, above the 19% running
average. Small sample, and this batch was pre-identified as high-risk, so it
should not be extrapolated directly — but it does not argue for lowering the
25–30 estimate for the remaining 128 rules.

## Batch 2 — Stale Objects, remaining 39 rules — COMPLETE

**Defects found: 10** (all fixed)

1. **Disabled accounts were not excluded** across six rules (`S-PwdNeverExpires`,
   `S-PwdNotRequired`, `S-Reversible`, `S-C-Reversible`, `S-DesEnabled`,
   `S-NoPreAuth*`, `S-AesNotEnabled`, primary-group checks). PingCastle's
   `AccountDataProcessor` returns early on `IsAccountDisabled()` for every one
   of these. This was the predicted cross-cutting issue from the plan — it was
   real, and larger than expected.

2. **`S-PwdNeverExpires` missing two exemptions.** PingCastle requires the
   password to be ≥30 days old and exempts Exchange `HealthMailbox*` accounts
   whose password rotated within 40 days (they self-rotate by design).

3. **`S-PwdNotRequired` missing the Exchange exemption** for DNs under
   `CN=Monitoring Mailboxes`.

4. **`S-DesEnabled` only checked the UAC flag.** PingCastle triggers on
   `USE_DES_KEY_ONLY` **or** the DES bits (0x1/0x2) in
   `msDS-SupportedEncryptionTypes`. Every account configured the second way was
   invisible — a false negative on a genuinely weak crypto setting.

5. **`S-Duplicate` missed one of two conflict signatures.** PingCastle matches a
   mangled `CNF:` DN **or** a `sAMAccountName` starting `$duplicate-`.

6. **`S-PrimaryGroup` used the wrong allowed set.** A single shared set
   `{513,514,515,516,521}` was applied to users and computers alike. For USERS
   only 513/514 are normal, the built-in Guest is exempt, and 515 is allowed
   only for (g)MSA objects — so a user hidden in Domain Computers/Domain
   Controllers was silently accepted.

7. **`S-C-PrimaryGroup` likewise.** For COMPUTERS, 515/514 are normal and
   516/521 are legitimate **only** for objects actually in the Domain
   Controllers OU. The old set accepted 513 and accepted 516/521 anywhere,
   which is precisely the primaryGroupID-hiding trick the rule exists to catch.

8. **`S-NoPreAuth` and `S-NoPreAuthAdmin` were not disjoint.** PingCastle
   excludes privileged accounts from `S-NoPreAuth` because they are reported by
   `S-NoPreAuthAdmin`. Admins were being double-counted across both rules.

9. **`S-AesNotEnabled` checked the wrong population and missed a whole branch.**
   It examined only SPN-bearing USERS. PingCastle covers users AND computers,
   and flags on either (a) the password predating the first Windows 2008+ DC
   (keys generated before AES existed) or (b) an SPN with no AES bit set. Branch
   (a) was entirely absent. Now gated on a Win2008+ DC existing, returning
   NOT_APPLICABLE otherwise. The install-date baseline is approximated from the
   earliest Win2008+ DC's `whenCreated` (PingCastle uses replication metadata),
   and the finding says so.

10. **Two self-inflicted regressions caught by the smoke test** during this
    batch: the primary-group rewrite collaterally deleted `_reversible_check`,
    and two constants were used without being imported. Both surfaced
    immediately as ERROR-status rules rather than silently — the smoke test
    doing its job.

**Tests:** 17 new regression checks (70 total, all passing). Smoke test green:
187/187 rules execute, 2 remaining ERRORs are correct behaviour on an empty mock
(no DCs / no Guest account).

**Running totals:** 67 of 174 rules audited (Batch 1: 14, Batch 2: 39, earlier
passes: 32). Defects found across audited rules: 21. Rate ≈ 31%, holding well
above the original 19% estimate. On that basis the remaining 107 rules are
likely to yield **30–35 more defects**, not the 25–30 originally projected.

**Next:** Batch 3 — Privileged Accounts, non-ACL (24 rules).

## Batch 3 — Privileged Accounts, non-ACL (24 rules) — COMPLETE

**Defects found: 11** (all fixed). This batch contained the most *semantically*
wrong rules so far — several were checking an entirely different thing than the
rule ID claims.

1. **`P-DNSAdmin` is DEACTIVATED upstream.** PingCastle's body is literally
   `// rule is not active anymore  return 0;` — the DLL-injection path was
   mitigated by Microsoft. Ours triggered on any DnsAdmins member, producing a
   finding PingCastle would never raise. Now NOT_APPLICABLE, membership still
   listed as review context.

2. **`P-OperatorsEmpty` checked four groups; PingCastle checks two.** Only
   Account Operators and Server Operators are in scope upstream. Backup and
   Print Operators were generating findings that don't exist in PingCastle.

3. **`P-DelegationEveryone` was checking the wrong subject entirely.** It
   inspected `msDS-AllowedToActOnBehalfOfOtherIdentity` (resource-based
   constrained delegation). Upstream it inspects OBJECT delegations — dangerous
   ACEs on OUs, containers and the domain root — whose trustee is an
   everyone-equivalent principal. Rewritten against a new
   `_enumerate_delegations()` helper.

4. **`P-DelegationKeyAdmin` likewise.** It enumerated Key Admins / Enterprise
   Key Admins *membership* (normal, and noisy). Upstream checks for a delegation
   ACE **on the domain root** whose trustee SID ends `-527`. Completely
   different question, and the upstream one is the actual Shadow-Credentials
   escalation path.

5–7. **The three DC-delegation rules were each mapped to the wrong attribute.**
   Correct mapping is `a2d2` = `msDS-AllowedToDelegateTo` *without* protocol
   transition, `t2a4d` = the same attribute *with*
   `TRUSTED_TO_AUTH_FOR_DELEGATION`, `sourcedeleg` = RBCD on the DC. Ours had
   a2d2 checking RBCD, t2a4d checking plain constrained delegation with no
   protocol-transition distinction, and sourcedeleg checking DCs as RBCD
   *actors*. All three rewritten behind one shared scan.

8–9. **Both `dSHeuristics` rules read the wrong character position** — exactly
   the off-by-index risk this plan flagged for these rules. AdminSDExMask must
   read index 15 (it read 2); DoListObject must read index 2 (it read 9). The
   positions were effectively crossed, so neither rule could ever be right.

10. **`P-DisplaySpecifier` used inverted logic.** PingCastle splits
    `adminContextMenu` on commas and flags field [2] when it is a UNC path.
    Ours flagged anything *not* containing "sysvol" — missing local-path abuse
    while firing on normal entries.

11. **Missing guards:** `P-Delegated` must exclude gMSA objects;
    `P-UnconstrainedDelegation` must exclude RODCs (521) as well as RW DCs;
    `P-AdminEmailOn` counts only enabled accounts; the two RODC rules are gated
    on domain functional level ≥ 3.

**One self-inflicted regression** during the batch (a slice replacement removed
`_enumerate_delegations`), caught immediately by the smoke test.

**Tests:** 13 new regression checks (83 total, all passing). Smoke green,
187/187 rules execute, both report formats intact.

**Running totals:** 91 of 174 rules audited. 32 defects found. Rate ≈ 35% and
still climbing. Remaining 83 rules project to **~29 more defects**.

**Next:** Batch 4 — Anomalies, non-certificate (37 rules).

## Batch 4 — Anomalies, non-certificate (37 rules) — COMPLETE

**Defects found: 11** (all fixed)

1–4. **All FOUR `dSHeuristics` rules read the wrong character index.** Combined
   with the two found in Batch 3, every single dSHeuristics rule in the tool was
   wrong. Verified positions (0-based): anonymous LDAP = 6 (read 1), anonymous
   NSPI = 7 (read 6), uniqueness = 20 (read 26), LDAP AuthZ = 27 (read 8). The
   LDAP AuthZ rule also inverts: the value must EQUAL "1", and an absent or
   short string is itself a finding.

5. **`A-PreWin2000AuthenticatedUsers` polarity was INVERTED.** It reported CLEAN
   when Authenticated Users WAS a member and TRIGGERED when it was not — the
   exact opposite of upstream, where membership is the finding. A comment in the
   old code rationalised the inversion ("Authenticated Users is the safer
   default vs Everyone"), which was simply wrong.

6. **`A-PreWin2000Anonymous` missed Everyone.** Upstream treats S-1-5-7
   (Anonymous) **or** S-1-1-0 (Everyone) as this finding.

7. **`A-PreWin2000Other` used a guessed name list.** Upstream's test is
   structural: any member whose DN does not start `CN=S-` is a real principal
   explicitly added to the group.

8. **`A-ProtectedUsers` checked entirely the wrong thing.** It counted members of
   the Protected Users group. Upstream it is a SCHEMA VERSION test
   (`SchemaVersion < 69`): whether the forest schema is even new enough for the
   group to exist. Membership is already covered by `P-ProtectedUsers`.

9. **`A-NoServicePolicy` had no strength test.** It asked only whether any PSO
   existed, so a PSO with an 8-character minimum satisfied it. Upstream requires
   some policy — GPO or PSO — with `MinimumPasswordLength >= 20`. Now checks
   both sources and reports the strongest found.

10. **`A-LDAPSigningDisabled` read the wrong registry value.** It inspected
    `LDAPServerIntegrity`; upstream inspects `LDAPClientIntegrity == 0`. Related
    settings, different keys — the rule could not have been correct.

11. **`A-DC-Coerce` was the wrong kind of check.** Upstream is a MITIGATION test:
    is there a GPO applying to the DCs (or domain root) setting
    `MSV1_0\RestrictSendingNTLMTraffic` to 2 ("Deny all")? If so the rule is
    suppressed. Ours performed an EFSRPC bind probe — a real but different test.
    Rewritten to the upstream semantics, with the bind probe retained purely as
    supplementary evidence that never changes the verdict.

**Tests:** 11 new regression checks (94 total, all passing). Smoke green,
187/187 execute. The 3 remaining smoke ERRORs are all correct behaviour against
an empty mock (no DCs, no Guest account, no schema object).

**Running totals:** 128 of 174 rules audited. 43 defects found. Rate ≈ 34%.
Remaining 46 rules project to **~15 more defects**.

**Pattern worth noting:** every rule that reads a positional character out of a
packed string (`dSHeuristics`, six rules total) was wrong. Positional parsing
written from memory has been a 100% failure rate in this codebase.

**Next:** Batch 5 — Anomalies, AD CS / certificates (18 rules).

## Batch 5 — Anomalies, AD CS / certificates (22 rules) — COMPLETE

**Defects found: 7** (all fixed). This batch had the single most consequential
error in the project: every certificate rule was reading the wrong data source.

1. **Wrong certificate source container — affects ALL 20 certificate rules.**
   Upstream's `TrustedCertificates` is read from **CN=NTAuthCertificates** (the
   NTAuth store, which is what actually governs whether a certificate is trusted
   for client authentication) plus GPO-deployed certificate stores. This module
   read `CN=Certification Authorities` — a different container holding a
   different population. Every hash, key-size and DSA finding was therefore
   evaluated against the wrong set of certificates. Both sources are now read
   and tagged so a reviewer can tell them apart.

2. **SHA-0 detection was declared impossible — incorrectly.** This file
   previously carried a stub asserting that `cryptography` "cannot disambiguate
   SHA-0 from SHA-1's OID". That is wrong: SHA-0 is the OIW `shaRSA` algorithm
   with its own OID **1.3.14.3.2.15**, which is exactly how PingCastle
   distinguishes it. Both SHA-0 rules are now implemented. Signature detection
   switched from hash-name heuristics to explicit OID mapping throughout.
   *This is the second time in this audit that a confident written justification
   turned out to be covering an unverified assumption.*

3. **`A-WeakRSARootCert` used the wrong threshold and the wrong population.**
   Upstream: modulus < **1024** bits across **all** trusted certificates. Ours:
   <2048 and root-only.

4. **`A-WeakRSARootCert2` is not the "intermediate certificate" rule.** It is the
   companion SIZE band: 1024 ≤ modulus < 2048, plus certificates under 3072 bits
   still valid beyond 2031. Implementing it as root-vs-intermediate meant the
   1024–2047 band was never reported at all.

5. **`A-CertWeakDSA` has no key-size test upstream.** It flags any trusted
   certificate with a DSA key whose Key Usage permits Digital Signature. Ours
   required <2048 bits — a far narrower and different test.

6. **`A-DCLdapsProtocol` was too broad.** Upstream flags **SSLv2/SSLv3 only**;
   ours flagged everything below TLS 1.2, overlapping the next rule.

7. **`A-DCLdapsProtocolAdvanced` was not a protocol check at all.** Upstream
   flags **TLS 1.0 / TLS 1.1**. Ours performed a cipher-suite sweep — a
   different question entirely. Both rules now share one version-probe scan.

**Tests:** 8 new regression checks (102 total, all passing). Smoke green,
187/187 execute; the 3 remaining ERRORs are correct behaviour on an empty mock.

**Running totals:** 150 of 174 rules audited. 50 defects found. Rate ≈ 33%.
Remaining 24 rules (Batch 6, Trusts) project to **~8 more defects**.

**Next:** Batch 6 — Trusts (10 rules) + the few remaining unaudited rules.

## Batch 6 — Trusts (10 rules) — COMPLETE

**Defects found: 7** (all fixed)

1. **`T-AlgsAES` read the wrong attribute entirely.** It tested a supposed RC4
   bit (0x80) in `trustAttributes`. Upstream reads
   **msDS-SupportedEncryptionTypes** on the trustedDomain object and triggers
   when it is 0 ("Not Configured") or has neither AES bit. It also skips
   outbound-only trusts (trustDirection == 2), which we did not.

2. **`T-Downlevel` also read the wrong field.** Upstream tests `trustType == 1`
   (TRUST_TYPE_DOWNLEVEL). We inspected an UPLEVEL_ONLY bit in
   `trustAttributes` — a different field that does not encode trust type.

3. **`T-Inactive` used the wrong object and threshold.** Upstream: the trust is
   inactive if the trustedDomain object's `whenChanged` is older than 40 days
   (the trust password rotation cadence). We used the interdomain trust
   ACCOUNT's `lastLogonTimestamp` with a 90-day window.

4. **`T-AzureADSSO` threshold was 9x too aggressive.** Upstream flags at one
   YEAR (`AddYears(1)`); we flagged at 40 days.

5. **`T-SIDHistoryDangerous` used a hand-picked RID list.** Upstream's test is
   simply **RID < 1000** — any built-in principal. Our five-RID list
   (512/519/518/544/500) missed Account Operators, Backup Operators, Server
   Operators, Print Operators, Cert Publishers and every other built-in.

6. **`T-ScriptOutOfDomain` covered only half its scope.** Upstream inspects both
   per-user `scriptPath` AND GPO-delivered logon scripts. A foreign UNC script
   pushed by GPO was invisible. Now parses `scripts.ini` from each GPO.

7. **Trust metadata was not being collected** for the fields above
   (`msDS-SupportedEncryptionTypes`, `trustType`, `trustDirection`), so several
   of these rules could not have been correct regardless of their logic.

**Tests:** 7 new regression checks (109 total, all passing).

---

# AUDIT COMPLETE

**All 174 implemented rules audited against PingCastle source.**

| Batch | Rules | Defects | Rate |
|---|---|---|---|
| Earlier passes (ACL + partial) | 32 | 6 | 19% |
| 1 — Obsolete OS | 14 | 5 | 36% |
| 2 — Stale Objects | 39 | 10 | 26% |
| 3 — Privileged Accounts | 24 | 11 | 46% |
| 4 — Anomalies (non-cert) | 37 | 11 | 30% |
| 5 — AD CS / certificates | 22 | 7 | 32% |
| 6 — Trusts | 10 | 7 | 70% |
| **TOTAL** | **178*** | **57** | **32%** |

\* Sums above 174 because a few rules were touched in more than one pass.

**Final state:** 187/187 rules registered, 174 implemented, 13 documented stubs,
0 missing. 109 regression checks and a 187-rule smoke test, all green. XML and
HTML output verified well-formed and complete.

## The three defect archetypes

1. **Wrong source / wrong attribute (~20 defects).** The rule looked plausible
   but read a different container, attribute or field than upstream. Worst
   example: every certificate rule read `CN=Certification Authorities` instead
   of `CN=NTAuthCertificates`, so 20 rules evaluated the wrong population.

2. **Wrong threshold or wrong shape (~22 defects).** Count where upstream uses a
   percentage, an invented number where upstream has a specific one, presence
   where upstream has bands. `S-Inactive` at ">=25 accounts" instead of ">=25%"
   would fire on any mid-size domain.

3. **Wrong semantics (~15 defects).** The rule ID meant something other than what
   was implemented. `A-ProtectedUsers` is a schema-version test, not a
   membership count. `A-DC-Coerce` is a GPO mitigation check, not an RPC probe.
   The three DC-delegation rules were cross-wired to each other's attributes.

## Two lessons worth carrying forward

**Positional parsing from memory failed 100% of the time.** All six
`dSHeuristics` rules read the wrong character index. Nothing about the code
surface distinguishes `[2]` from `[15]`.

**Confident prose masked unverified assumptions twice.** A comment explained why
an inverted `A-PreWin2000AuthenticatedUsers` polarity was correct (it was not),
and a stub asserted SHA-0 could not be distinguished from SHA-1 (it can, via OID
1.3.14.3.2.15). In both cases the written justification was more convincing than
the code was correct — and both survived earlier review passes because the
explanation read as authoritative.
