# SnaffleSnake

*Snaffler + Python = SnaffleSnake.*

A Python/Linux port of [Snaffler](https://github.com/SnaffCon/Snaffler)'s core
workflow: authenticated SMB share/file enumeration with a rules-based
sensitive-file triage classifier (Black/Red/Yellow/Green severity), producing
output compatible with existing Snaffler ingestors (SnafflerParser, Efflanrs,
snaffler-ng's importers, etc).

**For authorized penetration testing and red team engagements only.** You
must already have valid credentials (password, NTLM hash, or a Kerberos
ticket) for the target environment — SnaffleSnake does not exploit anything or
grant access; it enumerates files the authenticated account can already read.

## Install

**Recommended: [pipx](https://pipx.pypa.io/)** — installs SnaffleSnake into
its own isolated virtualenv and puts the `snafflesnake` command on your
`$PATH`, callable from anywhere, without touching system Python packages.

```bash
git clone <this-repo> snafflesnake && cd snafflesnake
pipx install .
```

Don't have pipx yet? On Kali/Debian: `sudo apt install pipx`. Otherwise:
`python3 -m pip install --user pipx && pipx ensurepath` (then open a new
shell).

**Alternative: plain venv**

```bash
git clone <this-repo> snafflesnake && cd snafflesnake
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

With the venv activated, `snafflesnake` is on `$PATH` for that shell; run
`source venv/bin/activate` again in any new terminal you want to use it in.

## Updating

**pipx install:** `git pull` alone does *not* update the installed command —
pipx built a real, standalone copy into its own venv, so you need to
rebuild it after pulling:

```bash
cd snafflesnake && git pull
pipx install --force .
```

`pipx upgrade snafflesnake` also works and can be run from any directory
(pipx remembers the original clone path) — but its "already at latest
version" message is only comparing the version number in `setup.py`
(which this project doesn't bump on every commit), not actual file
content, so don't be alarmed by that wording: it rebuilds from your
current source either way. `--force .` is the more foolproof of the two,
especially if you've ever moved the cloned folder.

**venv install:** if you installed with `pip install -e .` (editable
mode), `git pull` is enough on its own — the venv points straight at your
source tree, so code changes take effect immediately. You only need to
re-run `pip install -r requirements.txt` if a pulled change adds a new
dependency.

## Quick start

```bash
# Password auth against a single host
snafflesnake -u jdoe -p 'P@ssw0rd!' -d CORP 10.10.10.5

# Pass-the-hash against multiple hosts from a file
snafflesnake -u jdoe -H :31d6cfe0d16ae931b73c59d7e0c089c0 -d CORP --targets-file hosts.txt

# Kerberos, using a ticket already in $KRB5CCNAME
export KRB5CCNAME=/tmp/jdoe.ccache
snafflesnake -u jdoe -k --use-ccache -d corp.local --dc-ip 10.10.10.1 10.10.10.5

# Through a pivot (SOCKS proxy via proxychains) -- lower thread count, it's slow
proxychains snafflesnake -u jdoe -p 'P@ssw0rd!' -d CORP 10.10.10.5 --threads 3

# Write Snaffler-compatible TSV for SnafflerParser / other ingestors
snafflesnake -u jdoe -p 'P@ssw0rd!' -d CORP -y -o loot.tsv --targets-file hosts.txt

# NDJSON output
snafflesnake -u jdoe -p 'P@ssw0rd!' -d CORP -t json -o loot.json --targets-file hosts.txt

# No target list -- discover hosts from the domain via LDAP instead
snafflesnake -u jdoe -p 'P@ssw0rd!' -d corp.local --dc-ip 10.10.10.1 --discover
```

Run `snafflesnake --help` for the full flag reference.

## Host discovery (`--discover`)

Opt-in only -- the default is still "you give it a target list." If you'd
rather not build one by hand, `--discover` binds to the domain over LDAP and
enumerates computer objects to scan instead, the same idea as Snaffler's own
behavior when no explicit targets are given.

```bash
snafflesnake -u jdoe -p 'P@ssw0rd!' -d corp.local --dc-ip 10.10.10.1 --discover
```

- **Explicit targets always win.** If you pass positional hosts or
  `--targets-file` *and* `--discover`, the explicit list is used and
  discovery is skipped (with a note printed so it's not a silent
  surprise) -- same precedence Snaffler uses.
- **Stale computers are filtered out** by default: anything that hasn't
  logged into the domain in 120 days is skipped (`--stale-days 0` disables
  this; any other number changes the window).
- **Exclude specific hosts** from a discovered list with
  `--discover-exclude-file hosts-to-skip.txt` (one hostname per line) --
  useful for known-fragile boxes you want left alone.
- **Custom LDAP filter:** `--ldap-filter` overrides the default
  `(objectClass=computer)`, e.g. to target a specific OU or naming pattern.
- **Auth support is narrower than SMB auth:** discovery works with
  `-p`/`--password` (NTLM bind) or Kerberos (`--use-ccache`, needs the
  optional `gssapi` package: `pip install gssapi`, which needs
  `libkrb5-dev` on the system). It does **not** work with `-H`/NTLM-hash
  auth -- LDAP's NTLM bind needs a real password client-side to compute
  the response, there's no pass-the-hash path for it. If you only have a
  hash, use explicit targets instead.

## Cutting false positives

Snaffler's ruleset has a deliberate noise tier: **green**. Rules like
`KeepNameContainsGreen` match any filename containing `passw`/`secret`, and
`RelayNetConfigByName` matches `router`/`switch`/`cisco`/`firewall`
anywhere in a name — so "Password Policy 2024.docx", "Secret Santa
List.xlsx" and "Company Switchover Plan.docx" all match. That's upstream
behavior, faithfully ported, not a bug in the regexes.

The fix is a severity floor (Snaffler calls it InterestLevel):

```bash
snafflesnake -u jdoe -p 'pw' -d CORP --min-triage yellow --targets-file hosts.txt
```

Measured against a sample of benign business filenames vs. real loot:

| Floor | Benign files reported | Real loot kept |
|-------|----------------------|----------------|
| `green` (default) | 3 / 9 | all |
| `yellow` | **0 / 9** | all |

`--min-triage yellow` is the single highest-value knob for noise. Red and
black floors go further if you only want high-confidence hits. The filter
is applied at one chokepoint, so suppressed findings are excluded from the
console, the output file, *and* the HTML report counts.

## Scan performance

Two things dominate scan time, and neither is regex speed (classification
benchmarks at ~15,000 files/sec — it is not the bottleneck):

1. **Bytes pulled over SMB.** SnaffleSnake skips downloading known binary
   containers (`.docx`, `.xlsx`, `.pdf`, `.zip`, `.exe`, media, …) for
   content scanning, since the text heuristic would discard them anyway.
   Previously a 40MB `.docx` matching a name rule was transferred in full
   and then thrown away. Name/extension matches are still reported.
2. **How many files get opened at all.** Content scanning is driven by
   relay rules, exactly like Snaffler. `--grep-all` additionally scans
   every file with a known text extension — that's a SnaffleSnake superset,
   and it's **off by default** because it costs a download per file and
   widens the false-positive surface. Turn it on deliberately, not
   habitually.

**Parallelism is per-directory.** `--threads` controls how many
*directories* are being listed concurrently, across all hosts and shares.
Listing a directory pushes each subdirectory back onto a shared work
queue, so a single large fileserver saturates the whole pool — earlier
versions parallelized per-host, which meant one host got one thread no
matter what you set. Measured on a single host with 31 directories:

| `--threads` | wall time | speedup |
|---|---|---|
| 1 | 0.99s | 1.0x |
| 4 | 0.36s | 2.8x |
| 16 | 0.18s | 5.5x |

Each worker keeps its own SMBConnection per host and reuses it (impacket's
SMBConnection is not thread-safe, so connections are never shared).

Under proxychains, keep `--threads` low (2–4); SOCKS pivots serialize
badly and more threads usually makes it slower, not faster.

## Certificate inspection (x509)

Rules with the `CheckForKeys` action don't just report that a `.pfx`/`.p12`
exists — SnaffleSnake parses it and says *why* it matters:

- **`HasPrivateKey`** vs **`PublicCertOnly`** — a public cert is noise; a
  private key is loot. Public-only certs are downgraded to yellow so they
  don't sit alongside real keys.
- **`NoPasswordRequired`** / **`PasswordCracked:<pw>`** — encrypted
  keystores are tried against Snaffler's list of well-known tutorial
  passwords, plus the filename stem (people name the file after its
  password more often than you'd hope).
- **`HasPassword`** — parsed as a real keystore but not opened. A file we
  simply failed to understand returns nothing at all rather than falsely
  claiming it's password-protected.
- **`IsCACert`**, **`Expired`**, subject, issuer, SAN and EKU detail.

## Domain user rules (`--domain-users`)

Pulls interesting-looking accounts from AD — service/admin/vault accounts
(`svc`, `sql`, `adm`, `cyberark`, `thycotic`, …) and anything trusted for
delegation — and injects them as content-match patterns, so a config file
mentioning `svc_sqlbackup` gets flagged.

```bash
snafflesnake -u jdoe -p 'pw' -d corp.local --dc-ip 10.0.0.1 --domain-users --targets-file hosts.txt
```

Account names are matched delimited by whitespace/quotes rather than as
bare substrings, and names shorter than `--domain-user-min-len` (default 6)
are skipped — a 3-character account name would match half the estate.

> Upstream note: Snaffler's default target for these patterns is a rule
> named `KeepConfigRegexRed`, which doesn't exist in its own shipped
> ruleset (it lives only in a scratch `unsorted.txt`), and the failure is
> swallowed by a `try/catch` — so upstream's `-u` attaches to nothing by
> default. SnaffleSnake targets rules that actually exist.

## Resuming an interrupted scan

Big estates get interrupted — dropped pivots, Ctrl-C, closed laptops.
Record progress with `--state-file`, then resume with `--resume`:

```bash
# First run -- records completed shares as it goes
snafflesnake -u jdoe -p 'pw' -d CORP --targets-file hosts.txt \
    --state-file scan.state -o loot.txt

# ...interrupted. Pick up where it left off:
snafflesnake -u jdoe -p 'pw' -d CORP --targets-file hosts.txt \
    --state-file scan.state --resume -o loot.txt
```

- Checkpoints are per **(host, share)**, written append-only and flushed as
  each share completes, so a hard kill can't corrupt the ledger.
- A share interrupted mid-walk is deliberately *not* marked complete, so it
  gets rewalked — meaning a resumed run may re-report findings from the one
  share that was in flight. Completed shares are never rescanned.
- The state file tracks **progress, not results**. Findings aren't replayed
  on resume; append to the same output file to build the full picture.
- `--resume` without `--state-file` is rejected rather than silently
  ignored.

## Output formats

| Format  | Flag              | Notes                                                          |
|---------|-------------------|-----------------------------------------------------------------|
| plain   | `-t plain` (default) | Human-readable, one line per finding.                        |
| tsv     | `-y` / `-t tsv`   | Tab-separated (configurable via `--separator`); 14 columns by default, `--tsv-legacy` for 13. Intended for SnafflerParser and similar tools. |
| json    | `-t json`         | NDJSON — one JSON object per line, not a single array.         |

Findings are always written with `[File]`/`[Share]` task types, a
Black/Red/Yellow/Green severity, the matched rule name, permissions (always
`R` in v1 — see Known Limitations), size, timestamps, the full UNC path, and
a match keyword/content snippet.

## HTML report

`--html report.html` writes a single self-contained HTML file alongside
whatever plain/tsv/json output you've also asked for — nothing else to
serve, no network calls, no external JS/CSS. Open it in any browser to:

- filter by severity, task type, host, or rule, and free-text search
  across UNC path, rule name, and content snippet;
- see the matched keyword highlighted inline in each content snippet;
- see any recovered secret (e.g. a decrypted GPP password) called out in
  its own box with the associated account name, so you don't have to
  read every content snippet by eye to find the interesting ones.

## GPP cpassword decryption

Group Policy Preferences let admins push local-account, scheduled-task, and
mapped-drive credentials via XML files in SYSVOL (`Groups.xml`,
`Services.xml`, `ScheduledTasks.xml`, `DataSources.xml`, `Drives.xml`,
`Printers.xml`). The password sits in a `cpassword` attribute, AES-256-CBC
encrypted with a static key Microsoft published in the MS-GPPREF spec
(§2.2.1.1.4) — the same key used by NetExec, Metasploit's `smb_enum_gpp`,
and `gpp-decrypt`. MS14-025 stopped *new* GPP passwords from being created,
but old XML files routinely linger in SYSVOL for years.

SnaffleSnake scans every GPP preference filename it finds (`snafflesnake/gpp.py` +
the bundled `snafflesnake_extra.yaml` rules) and, if a non-empty `cpassword`
turns up, decrypts it automatically and reports it as a
`GppDecryptedPassword` finding (Black) with the recovered plaintext and
associated account name inline — no manual copy/decrypt step. This is
SnaffleSnake-specific; upstream Snaffler surfaces the raw encrypted file but
doesn't decrypt it.

## Rules

SnaffleSnake ships with **Snaffler's full default ruleset** (88 classifiers)
ported verbatim from `SnaffCon/Snaffler`'s `DefaultRules/*.toml` into the
YAML schema below, regenerated by `tools/convert_snaffler_rules.py`, plus
2 SnaffleSnake-specific rules for GPP detection (`snafflesnake/rules/snafflesnake_extra.yaml`,
loaded by default alongside the ported set). Matching semantics match
Snaffler exactly: every wordlist entry is a case-insensitive regex, anchored
by type (`exact`→`^p$`, `startswith`→`^p`, `endswith`→`p$`,
`contains`/`regex`→unanchored). Share-name and file-path rules match against
the full UNC (`\\host\share\...`), and `.bak` files are matched on their inner
extension, both as in Snaffler.

## Writing your own rules

Pass one or more YAML files with `--rules path/to/rules.yaml` (repeatable;
later files override earlier ones by rule `name`). Use `--no-default-rules`
to replace the built-in set entirely.

```yaml
rules:
  - name: MyCustomRule
    enum_scope: file            # share | directory | file | contents | postmatch
    match_location: file_name   # share_name | file_path | file_name
                                 # | file_extension | file_content | file_length
    wordlist_type: contains     # exact | contains | startswith | endswith | regex
    wordlist: ['backup_db']     # regex fragments (case-insensitive)
    triage: red                 # green | yellow | red | black
    match_action: snaffle       # snaffle | discard | relay | check_for_keys
                                 # | send_to_next_scope | check_contents
    relay_targets: []           # for relay rules: names of rules to bounce to
    match_length: 150           # contents rules only: context chars around a hit
    description: 'Optional'
```

**Content scanning** is driven by `relay` rules exactly like Snaffler: a file
whose extension matches a `Relay*ByExtension` rule is downloaded and grepped
with that rule's `relay_targets` (the contents-scope rules). Files over
`--max-file-size` (default 10M) are reported by name/extension only.

## Known limitations (v1)

- **Permissions field is always `R`.** Detecting write access reliably means
  probing with a real write (noisy) or parsing ACLs — out of scope for v1.
  `RW` detection is a stretch goal.
- **No archive descent** (`EnterArchive`) — unimplemented upstream too.
- **`--discover` doesn't support NTLM-hash auth** — see the Host discovery
  section above; use explicit targets if you only have a hash.
- **In-memory, size-capped content scanning** — very large files are reported
  by name only.

## Legal

Only run this against systems and environments you are authorized to test.
Misuse of this tool against systems without authorization is illegal.
