"""Tests for snafflesnake.cli -- argument parsing and the explicit-targets
vs --discover precedence rule (explicit targets always win, matching
Snaffler's own behavior).
"""
from __future__ import annotations

import pytest

from snafflesnake.cli import _build_config, build_arg_parser


def _parse(*argv):
    return build_arg_parser().parse_args(list(argv))


class TestTargetPrecedence:
    def test_explicit_targets_only(self):
        args = _parse("-u", "jdoe", "-p", "pw", "host1", "host2")
        cfg = _build_config(args)
        assert cfg.hosts == ["host1", "host2"]
        assert cfg.discover is False

    def test_discover_only_no_explicit_targets(self):
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1", "--discover")
        cfg = _build_config(args)
        assert cfg.hosts == []
        assert cfg.discover is True

    def test_explicit_targets_override_discover_flag(self, capsys):
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1",
                       "--discover", "host1")
        cfg = _build_config(args)
        assert cfg.hosts == ["host1"]
        assert cfg.discover is False  # explicit target wins, discovery not scheduled
        assert "ignoring --discover" in capsys.readouterr().err

    def test_no_targets_no_discover_raises(self):
        args = _parse("-u", "jdoe", "-p", "pw")
        with pytest.raises(SystemExit, match="no targets specified"):
            _build_config(args)


class TestDiscoverValidation:
    def test_discover_without_dc_ip_raises(self):
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--discover")
        with pytest.raises(SystemExit, match="--dc-ip"):
            _build_config(args)

    def test_discover_with_hash_only_raises(self):
        args = _parse("-u", "jdoe", "-H", "aad3b435b51404eeaad3b435b51404ee",
                       "-d", "corp.local", "--dc-ip", "10.0.0.1", "--discover")
        with pytest.raises(SystemExit, match="hash-only"):
            _build_config(args)

    def test_discover_with_kerberos_is_allowed(self):
        args = _parse("-u", "jdoe", "-k", "--use-ccache",
                       "-d", "corp.local", "--dc-ip", "10.0.0.1", "--discover")
        cfg = _build_config(args)
        assert cfg.discover is True

    def test_discover_defaults(self):
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1", "--discover")
        cfg = _build_config(args)
        assert cfg.ldap_filter == "(objectClass=computer)"
        assert cfg.stale_days == 120
        assert cfg.ldaps is False
        assert cfg.ldap_port is None

    def test_discover_exclude_file(self, tmp_path):
        exfile = tmp_path / "exclude.txt"
        exfile.write_text("oldbox.corp.local\nlegacyserver.corp.local\n")
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1",
                       "--discover", "--discover-exclude-file", str(exfile))
        cfg = _build_config(args)
        assert cfg.discover_exclude == {"oldbox.corp.local", "legacyserver.corp.local"}

    def test_discover_exclude_file_missing_raises(self):
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1",
                       "--discover", "--discover-exclude-file", "/no/such/file.txt")
        with pytest.raises(SystemExit, match="discover-exclude-file"):
            _build_config(args)

    def test_ldaps_sets_flag(self):
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1",
                       "--discover", "--ldaps")
        cfg = _build_config(args)
        assert cfg.ldaps is True

    def test_custom_ldap_filter_and_stale_days(self):
        args = _parse("-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1",
                       "--discover", "--ldap-filter", "(name=WKSTN*)", "--stale-days", "30")
        cfg = _build_config(args)
        assert cfg.ldap_filter == "(name=WKSTN*)"
        assert cfg.stale_days == 30


class TestMainDiscoveryWiring:
    """End-to-end check that main() actually calls discovery and threads
    the resulting host list through to the scheduler -- not just that
    _build_config sets the right flags.
    """

    def test_discovered_hosts_reach_scheduler(self, monkeypatch):
        import snafflesnake.cli as cli_mod

        captured = {}

        def fake_discover_hosts(cfg):
            return ["disc1.corp.local", "disc2.corp.local"]

        def fake_scheduler_run(cfg, engine, sink):
            captured["hosts"] = list(cfg.hosts)

        monkeypatch.setattr("snafflesnake.discovery.discover_hosts", fake_discover_hosts)
        monkeypatch.setattr(cli_mod, "scheduler_run", fake_scheduler_run)

        rc = cli_mod.main([
            "-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1", "--discover",
        ])

        assert rc == 0
        assert captured["hosts"] == ["disc1.corp.local", "disc2.corp.local"]

    def test_discovery_failure_exits_cleanly(self, monkeypatch, capsys):
        import snafflesnake.cli as cli_mod
        from snafflesnake.discovery import DiscoveryError

        def fake_discover_hosts(cfg):
            raise DiscoveryError("LDAP bind to 10.0.0.1:389 failed: simulated")

        monkeypatch.setattr("snafflesnake.discovery.discover_hosts", fake_discover_hosts)

        rc = cli_mod.main([
            "-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1", "--discover",
        ])

        assert rc == 1
        assert "discovery failed" in capsys.readouterr().err

    def test_empty_discovery_result_exits_cleanly(self, monkeypatch, capsys):
        import snafflesnake.cli as cli_mod

        monkeypatch.setattr("snafflesnake.discovery.discover_hosts", lambda cfg: [])

        rc = cli_mod.main([
            "-u", "jdoe", "-p", "pw", "-d", "corp.local", "--dc-ip", "10.0.0.1", "--discover",
        ])

        assert rc == 1
        assert "no hosts to scan" in capsys.readouterr().err
