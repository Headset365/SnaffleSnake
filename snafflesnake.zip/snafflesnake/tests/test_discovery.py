"""Tests for snafflesnake.discovery (LDAP-based host discovery)."""
from __future__ import annotations

import datetime as dt
from unittest.mock import patch

import ldap3
import pytest

from snafflesnake import discovery
from snafflesnake.config import Config
from snafflesnake.discovery import DiscoveryError, _base_dn, _filetime_to_datetime, _first, discover_hosts

# A FILETIME value that's ~recent (well within any reasonable staleness window).
_RECENT_TICKS = str(
    int(((dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=5)) - discovery._FILETIME_EPOCH).total_seconds() * 10_000_000)
)
# A FILETIME value from several years ago -- always stale.
_OLD_TICKS = "130000000000000000"  # ~2013


def _cfg(**overrides) -> Config:
    base = dict(
        hosts=[], username="jdoe", password="hunter2", domain="corp.local",
        dc_ip="10.10.10.1", discover=True,
    )
    base.update(overrides)
    return Config(**base)


_REAL_CONNECTION = ldap3.Connection  # captured before any patching happens


def _mock_connection_factory(entries):
    """Return a function that builds a real ldap3.Connection forced onto
    MOCK_SYNC, pre-seeded with `entries` (list of (dn, attrs) tuples), so
    snafflesnake.discovery's real code path can be exercised end-to-end
    without touching the network.
    """
    def factory(*args, **kwargs):
        kwargs.pop("client_strategy", None)
        conn = _REAL_CONNECTION(*args, client_strategy=ldap3.MOCK_SYNC, **kwargs)
        for dn, attrs in entries:
            conn.strategy.add_entry(dn, attrs)
        return conn
    return factory


class TestFiletimeConversion:
    def test_recent_ticks_convert(self):
        result = _filetime_to_datetime(_RECENT_TICKS)
        assert result is not None
        assert (dt.datetime.now(dt.timezone.utc) - result).days < 10

    def test_zero_is_none(self):
        assert _filetime_to_datetime("0") is None
        assert _filetime_to_datetime(0) is None

    def test_negative_is_none(self):
        assert _filetime_to_datetime("-5") is None

    def test_non_numeric_is_none(self):
        assert _filetime_to_datetime("not-a-number") is None
        assert _filetime_to_datetime(None) is None

    def test_absurd_overflow_is_none(self):
        assert _filetime_to_datetime("9" * 30) is None


class TestFirst:
    def test_returns_first_value(self):
        assert _first({"name": ["WKSTN01"]}, "name") == "WKSTN01"

    def test_empty_list_is_none(self):
        assert _first({"name": []}, "name") is None

    def test_missing_key_is_none(self):
        assert _first({}, "name") is None


class TestBaseDn:
    def test_simple_domain(self):
        assert _base_dn("corp.local") == "DC=corp,DC=local"

    def test_single_label_domain(self):
        assert _base_dn("corp") == "DC=corp"

    def test_empty_domain_raises(self):
        with pytest.raises(DiscoveryError):
            _base_dn("")

    def test_dot_domain_raises(self):
        with pytest.raises(DiscoveryError):
            _base_dn(".")


class TestConnectValidation:
    """These fail before any network call, so no mocking needed."""

    def test_missing_dc_ip_raises(self):
        cfg = _cfg(dc_ip=None)
        with pytest.raises(DiscoveryError, match="--dc-ip"):
            discovery._connect(cfg)

    def test_hash_only_raises(self):
        cfg = _cfg(password=None, nthash="aad3b435b51404eeaad3b435b51404ee", kerberos=False)
        with pytest.raises(DiscoveryError, match="hash-only"):
            discovery._connect(cfg)


class TestDiscoverHostsHappyPath:
    def test_dedup_fallback_and_staleness(self):
        entries = [
            ("CN=WKSTN01,CN=Computers,DC=corp,DC=local", {
                "objectClass": ["computer"], "dNSHostName": "wkstn01.corp.local",
                "name": "WKSTN01", "lastLogonTimestamp": _RECENT_TICKS,
            }),
            ("CN=NODNS,CN=Computers,DC=corp,DC=local", {
                # no dNSHostName -> falls back to name + domain
                "objectClass": ["computer"], "name": "NODNS", "lastLogonTimestamp": _RECENT_TICKS,
            }),
            ("CN=STALEBOX,CN=Computers,DC=corp,DC=local", {
                # old lastLogonTimestamp -> excluded by the staleness filter
                "objectClass": ["computer"], "dNSHostName": "stalebox.corp.local",
                "name": "STALEBOX", "lastLogonTimestamp": _OLD_TICKS,
            }),
            ("CN=EXCLUDED,CN=Computers,DC=corp,DC=local", {
                "objectClass": ["computer"], "dNSHostName": "excluded.corp.local",
                "name": "EXCLUDED", "lastLogonTimestamp": _RECENT_TICKS,
            }),
        ]
        cfg = _cfg(discover_exclude={"excluded.corp.local"})
        with patch("snafflesnake.discovery.ldap3.Connection", _mock_connection_factory(entries)):
            hosts = discover_hosts(cfg)

        assert hosts == ["nodns.corp.local", "wkstn01.corp.local"]

    def test_stale_days_zero_disables_filter(self):
        entries = [
            ("CN=STALEBOX,CN=Computers,DC=corp,DC=local", {
                "objectClass": ["computer"], "dNSHostName": "stalebox.corp.local",
                "name": "STALEBOX", "lastLogonTimestamp": _OLD_TICKS,
            }),
        ]
        cfg = _cfg(stale_days=0)
        with patch("snafflesnake.discovery.ldap3.Connection", _mock_connection_factory(entries)):
            hosts = discover_hosts(cfg)
        assert hosts == ["stalebox.corp.local"]

    def test_missing_lastlogon_excluded_when_staleness_enabled(self):
        entries = [
            ("CN=NOSTAMP,CN=Computers,DC=corp,DC=local", {
                "objectClass": ["computer"], "dNSHostName": "nostamp.corp.local", "name": "NOSTAMP",
                # no lastLogonTimestamp at all
            }),
        ]
        cfg = _cfg(stale_days=120)
        with patch("snafflesnake.discovery.ldap3.Connection", _mock_connection_factory(entries)):
            hosts = discover_hosts(cfg)
        assert hosts == []

    def test_no_matching_computers_returns_empty_list(self):
        cfg = _cfg()
        with patch("snafflesnake.discovery.ldap3.Connection", _mock_connection_factory([])):
            assert discover_hosts(cfg) == []


class TestKerberosDiscovery:
    def test_missing_gssapi_raises_clear_error(self):
        cfg = _cfg(password=None, kerberos=True)
        with patch.dict("sys.modules", {"gssapi": None}):
            with pytest.raises(DiscoveryError, match="gssapi"):
                discovery._connect(cfg)
