"""Tests for resume state (snafflesnake.state) and the noise/perf controls."""
from __future__ import annotations

from snafflesnake.config import Config
from snafflesnake.models import Finding, Triage
from snafflesnake.output import OutputSink
from snafflesnake.state import ScanState


class TestScanState:
    def test_marks_and_reports_done(self, tmp_path):
        p = tmp_path / "scan.state"
        st = ScanState(str(p))
        assert st.is_done("srv01", "data") is False
        st.mark_done("srv01", "data")
        assert st.is_done("srv01", "data") is True
        st.close()

    def test_persists_across_instances(self, tmp_path):
        p = tmp_path / "scan.state"
        st = ScanState(str(p))
        st.mark_done("srv01", "data")
        st.mark_done("srv02", "share2")
        st.close()

        st2 = ScanState(str(p), resume=True)
        assert st2.is_done("srv01", "data")
        assert st2.is_done("srv02", "share2")
        assert st2.completed_count() == 2
        st2.close()

    def test_without_resume_ignores_existing_records(self, tmp_path):
        p = tmp_path / "scan.state"
        st = ScanState(str(p))
        st.mark_done("srv01", "data")
        st.close()

        # resume=False: previous progress is not honored (fresh scan)
        st2 = ScanState(str(p), resume=False)
        assert st2.is_done("srv01", "data") is False
        st2.close()

    def test_case_insensitive(self, tmp_path):
        st = ScanState(str(tmp_path / "s.state"))
        st.mark_done("SRV01", "DATA")
        assert st.is_done("srv01", "data")
        st.close()

    def test_duplicate_marks_written_once(self, tmp_path):
        p = tmp_path / "s.state"
        st = ScanState(str(p))
        st.mark_done("srv01", "data")
        st.mark_done("srv01", "data")
        st.close()
        assert len([ln for ln in p.read_text().splitlines() if ln.strip()]) == 1

    def test_torn_final_line_is_tolerated(self, tmp_path):
        """A hard kill can leave a half-written line; every complete record
        before it must still be recovered."""
        p = tmp_path / "s.state"
        p.write_text('{"host": "srv01", "share": "data"}\n{"host": "srv02", "sha')
        st = ScanState(str(p), resume=True)
        assert st.is_done("srv01", "data")
        assert st.completed_count() == 1
        st.close()

    def test_missing_file_with_resume_is_not_an_error(self, tmp_path):
        st = ScanState(str(tmp_path / "nope.state"), resume=True)
        assert st.completed_count() == 0
        st.close()

    def test_append_does_not_clobber_previous_run(self, tmp_path):
        p = tmp_path / "s.state"
        ScanState(str(p)).mark_done("srv01", "data")
        st2 = ScanState(str(p), resume=True)
        st2.mark_done("srv02", "other")
        st2.close()
        st3 = ScanState(str(p), resume=True)
        assert st3.completed_count() == 2
        st3.close()


def _finding(triage: Triage) -> Finding:
    return Finding(triage=triage, rule_name="R", task_type="File", host="h",
                   share="s", unc="\\\\h\\s\\f", keyword="k")


class TestMinTriageFilter:
    def _sink(self, tmp_path, floor: int):
        cfg = Config(hosts=["h"], username="u", password="p", min_triage=floor,
                     out_file=str(tmp_path / "out.txt"), to_console=False)
        return cfg, OutputSink(cfg)

    def test_green_floor_reports_everything(self, tmp_path):
        cfg, sink = self._sink(tmp_path, 1)
        for t in (Triage.GREEN, Triage.YELLOW, Triage.RED, Triage.BLACK):
            sink.write(_finding(t))
        sink.flush()
        assert len((tmp_path / "out.txt").read_text().splitlines()) == 4

    def test_yellow_floor_suppresses_green(self, tmp_path):
        cfg, sink = self._sink(tmp_path, 2)
        for t in (Triage.GREEN, Triage.YELLOW, Triage.RED, Triage.BLACK):
            sink.write(_finding(t))
        sink.flush()
        assert len((tmp_path / "out.txt").read_text().splitlines()) == 3

    def test_black_floor_keeps_only_black(self, tmp_path):
        cfg, sink = self._sink(tmp_path, 4)
        for t in (Triage.GREEN, Triage.YELLOW, Triage.RED, Triage.BLACK):
            sink.write(_finding(t))
        sink.flush()
        assert len((tmp_path / "out.txt").read_text().splitlines()) == 1

    def test_suppressed_findings_excluded_from_html_report(self, tmp_path):
        cfg = Config(hosts=["h"], username="u", password="p", min_triage=3,
                     html_file=str(tmp_path / "r.html"), to_console=False)
        sink = OutputSink(cfg)
        sink.write(_finding(Triage.GREEN))
        sink.write(_finding(Triage.BLACK))
        sink.flush()
        html = (tmp_path / "r.html").read_text()
        assert "Black: 1" in html
        assert "Green: 0" in html


class TestResumeThroughScheduler:
    """Exercises the real parallel scheduler: completed shares must be
    skipped on a resumed run, and interrupted ones must not be."""

    def _conn(self):
        from unittest.mock import MagicMock

        class F:
            def __init__(s, n, d=False, sz=0):
                s._n, s._d, s._sz = n, d, sz
            def get_longname(s): return s._n
            def is_directory(s): return 1 if s._d else 0
            def get_filesize(s): return s._sz
            def get_mtime_epoch(s): return 1700000000.0
            def get_ctime_epoch(s): return 1699000000.0

        c = MagicMock()
        c.listShares.return_value = [
            {"shi1_netname": b"data\x00", "shi1_type": 0},
            {"shi1_netname": b"apps\x00", "shi1_type": 0},
        ]
        c.listPath.side_effect = lambda sh, pat: [F(".", True), F("..", True), F("id_rsa", sz=1679)]
        c.getFile.side_effect = lambda sh, p, cb: cb(b"key")
        return c

    def _run(self, tmp_path, resume: bool, out_name: str):
        from unittest.mock import patch

        from snafflesnake import scheduler
        from snafflesnake.output import OutputSink
        from snafflesnake.rules.engine import RuleEngine

        cfg = Config(hosts=["srv01"], username="u", password="p", threads=4,
                     state_file=str(tmp_path / "scan.state"), resume=resume,
                     out_file=str(tmp_path / out_name), to_console=False)
        sink = OutputSink(cfg)
        with patch.object(scheduler.auth, "connect", return_value=self._conn()):
            scheduler.run(cfg, RuleEngine(use_default_rules=True), sink)
        return (tmp_path / out_name).read_text()

    def test_second_run_skips_completed_shares(self, tmp_path):
        first = self._run(tmp_path, resume=False, out_name="a.txt")
        assert "id_rsa" in first, "first run should find files"

        second = self._run(tmp_path, resume=True, out_name="b.txt")
        assert "id_rsa" not in second, "completed shares must not be rewalked"

    def test_state_records_all_shares(self, tmp_path):
        self._run(tmp_path, resume=False, out_name="a.txt")
        st = ScanState(str(tmp_path / "scan.state"), resume=True)
        assert st.is_done("srv01", "data")
        assert st.is_done("srv01", "apps")
        st.close()
