"""Tests for the HTML report generator (snafflesnake.report)."""
from __future__ import annotations

from snafflesnake.models import Finding, Triage
from snafflesnake.report import build_html, write_html_report


def _findings():
    return [
        Finding(triage=Triage.BLACK, rule_name="KeepSSHKeysByFileName", task_type="File",
                host="dc01", share="data", unc="\\\\dc01\\data\\home\\id_rsa",
                size_human="1.6kB", modified="2023-11-14 22:13:20Z", keyword="id_rsa"),
        Finding(triage=Triage.BLACK, rule_name="GppDecryptedPassword", task_type="File",
                host="dc01", share="SYSVOL", unc="\\\\dc01\\SYSVOL\\Groups.xml",
                keyword="cpassword", content="account='Administrator' password='Local*P4ssword!'",
                decrypted="Local*P4ssword!", account="Administrator"),
        Finding(triage=Triage.YELLOW, rule_name="KeepSCCMShares", task_type="Share",
                host="srv02", share="SCCMContentLib$", unc="\\\\srv02\\SCCMContentLib$"),
    ]


class TestBuildHtml:
    def test_contains_findings(self):
        h = build_html(_findings())
        assert "id_rsa" in h
        assert "GppDecryptedPassword" in h
        assert "SCCMContentLib$" in h

    def test_decrypted_secret_shown(self):
        h = build_html(_findings())
        assert "Local*P4ssword!" in h
        assert "Administrator" in h

    def test_keyword_highlighted(self):
        h = build_html(_findings())
        # the id_rsa keyword should be wrapped in a <mark> within its content
        # (content is empty here, so check the mark helper via a content row)
        f = Finding(triage=Triage.RED, rule_name="R", content="secret=hunter2 here", keyword="hunter2")
        h2 = build_html([f])
        assert "<mark>hunter2</mark>" in h2

    def test_severity_counts_present(self):
        h = build_html(_findings())
        assert "Black: 2" in h
        assert "Yellow: 1" in h

    def test_self_contained_no_external_refs(self):
        h = build_html(_findings())
        assert "http://" not in h and "https://" not in h
        assert "<script" in h  # interactivity is inline

    def test_html_escaping(self):
        f = Finding(triage=Triage.RED, rule_name="X", content="<script>alert(1)</script>", keyword="")
        h = build_html([f])
        assert "<script>alert(1)</script>" not in h
        assert "&lt;script&gt;" in h

    def test_write_to_file(self, tmp_path):
        out = tmp_path / "report.html"
        write_html_report(str(out), _findings(), {"generated": "now", "targets": "dc01"})
        text = out.read_text()
        assert text.startswith("<!DOCTYPE html>")
        assert "Local*P4ssword!" in text
