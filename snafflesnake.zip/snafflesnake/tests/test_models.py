import pytest

from snafflesnake.models import (
    EnumScope,
    Finding,
    MatchAction,
    MatchLocation,
    Rule,
    Target,
    Triage,
    WordListType,
)


class TestTriage:
    def test_ordering(self):
        assert Triage.BLACK > Triage.RED > Triage.YELLOW > Triage.GREEN

    def test_from_str(self):
        assert Triage.from_str("red") == Triage.RED
        assert Triage.from_str("BLACK") == Triage.BLACK
        assert Triage.from_str(" Yellow ") == Triage.YELLOW

    def test_str_representation(self):
        assert str(Triage.RED) == "Red"
        assert str(Triage.BLACK) == "Black"


class TestEnumParsing:
    def test_enum_scope_from_str(self):
        assert EnumScope.from_str("file") == EnumScope.FILE
        assert EnumScope.from_str("CONTENTS") == EnumScope.CONTENTS

    def test_match_location_from_str(self):
        assert MatchLocation.from_str("file_extension") == MatchLocation.FILE_EXTENSION

    def test_wordlist_type_from_str(self):
        assert WordListType.from_str("regex") == WordListType.REGEX

    def test_match_action_from_str(self):
        assert MatchAction.from_str("discard") == MatchAction.DISCARD

    def test_invalid_scope_raises(self):
        with pytest.raises(ValueError):
            EnumScope.from_str("not_a_scope")


class TestRule:
    def test_from_dict_roundtrip(self):
        d = {
            "name": "TestRule",
            "enum_scope": "file",
            "match_location": "file_extension",
            "wordlist_type": "exact",
            "wordlist": [".pem", ".key"],
            "triage": "red",
            "match_action": "snaffle",
        }
        rule = Rule.from_dict(d)
        assert rule.name == "TestRule"
        assert rule.enum_scope == EnumScope.FILE
        assert rule.match_location == MatchLocation.FILE_EXTENSION
        assert rule.wordlist_type == WordListType.EXACT
        assert rule.wordlist == [".pem", ".key"]
        assert rule.triage == Triage.RED
        assert rule.match_action == MatchAction.SNAFFLE

    def test_defaults(self):
        d = {
            "name": "MinimalRule",
            "enum_scope": "share",
            "match_location": "share_name",
            "wordlist_type": "exact",
            "wordlist": ["IPC$"],
            "triage": "green",
        }
        rule = Rule.from_dict(d)
        assert rule.match_action == MatchAction.SNAFFLE
        assert rule.match_length == 200
        assert rule.description == ""

    def test_missing_required_field_raises(self):
        with pytest.raises(KeyError):
            Rule.from_dict({"name": "Broken"})


class TestTarget:
    def test_unc_full(self):
        t = Target(host="host01", share="share", path="dir\\file.txt")
        assert t.unc == "\\\\host01\\share\\dir\\file.txt"

    def test_unc_share_only(self):
        t = Target(host="host01", share="share")
        assert t.unc == "\\\\host01\\share"


class TestFinding:
    def test_defaults(self):
        f = Finding(triage=Triage.RED, rule_name="TestRule")
        assert f.task_type == "File"
        assert f.permissions == "R"
        assert f.content == ""
        assert f.size == 0
