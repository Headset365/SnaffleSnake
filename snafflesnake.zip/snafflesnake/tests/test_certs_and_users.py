"""Tests for x509 certificate inspection and domain-user dynamic rules."""
from __future__ import annotations

import datetime as dt

import pytest

from snafflesnake.certs import inspect_cert
from snafflesnake.rules.engine import RuleEngine

cryptography = pytest.importorskip("cryptography")

from cryptography import x509  # noqa: E402
from cryptography.hazmat.primitives import hashes, serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric import rsa  # noqa: E402
from cryptography.hazmat.primitives.serialization import BestAvailableEncryption, pkcs12  # noqa: E402
from cryptography.x509.oid import NameOID  # noqa: E402


def _make_cert(ca: bool = False, days_valid: int = 365):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "ca.corp.local" if ca else "web01.corp.local")])
    now = dt.datetime.now(dt.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(name).issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(days=1))
        .not_valid_after(now + dt.timedelta(days=days_valid))
        .add_extension(x509.BasicConstraints(ca=ca, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )
    return key, cert


@pytest.fixture(scope="module")
def kc():
    return _make_cert()


class TestInspectCert:
    def test_pfx_without_password(self, kc):
        key, cert = kc
        data = pkcs12.serialize_key_and_certificates(b"t", key, cert, None, serialization.NoEncryption())
        r = inspect_cert(data, "web01.pfx", ".pfx")
        assert "HasPrivateKey" in r
        assert "NoPasswordRequired" in r
        assert any(x.startswith("Subject:") for x in r)

    def test_pfx_with_weak_password_is_cracked(self, kc):
        key, cert = kc
        data = pkcs12.serialize_key_and_certificates(
            b"t", key, cert, None, BestAvailableEncryption(b"changeit"))
        r = inspect_cert(data, "web01.pfx", ".pfx")
        assert "HasPrivateKey" in r
        assert "PasswordCracked:changeit" in r

    def test_pfx_with_strong_password_reports_haspassword(self, kc):
        key, cert = kc
        data = pkcs12.serialize_key_and_certificates(
            b"t", key, cert, None, BestAvailableEncryption(b"Zx9!q7Lm2#Vt"))
        r = inspect_cert(data, "web01.pfx", ".pfx")
        assert r == ["HasPassword", "LookNearbyForTxtFiles"]

    def test_filename_stem_is_tried_as_password(self, kc):
        key, cert = kc
        data = pkcs12.serialize_key_and_certificates(
            b"t", key, cert, None, BestAvailableEncryption(b"corpwildcard"))
        r = inspect_cert(data, "corpwildcard.pfx", ".pfx")
        assert "HasPrivateKey" in r
        assert "PasswordCracked:corpwildcard" in r

    def test_public_cert_only_is_flagged_as_such(self, kc):
        _, cert = kc
        r = inspect_cert(cert.public_bytes(serialization.Encoding.PEM), "web01.crt", ".crt")
        assert "PublicCertOnly" in r
        assert "HasPrivateKey" not in r

    def test_bare_private_key(self, kc):
        key, _ = kc
        pem = key.private_bytes(serialization.Encoding.PEM,
                                serialization.PrivateFormat.PKCS8,
                                serialization.NoEncryption())
        r = inspect_cert(pem, "web01.key", ".key")
        assert "HasPrivateKey" in r

    def test_ca_cert_is_flagged(self):
        key, cert = _make_cert(ca=True)
        data = pkcs12.serialize_key_and_certificates(b"ca", key, cert, None, serialization.NoEncryption())
        r = inspect_cert(data, "ca.pfx", ".pfx")
        assert "IsCACert" in r
        assert "HasPrivateKey" in r

    def test_expired_cert_flagged(self):
        key, cert = _make_cert(days_valid=-1) if False else (None, None)
        # build an already-expired cert explicitly
        k = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        n = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "old.corp.local")])
        past = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=10)
        c = (x509.CertificateBuilder().subject_name(n).issuer_name(n)
             .public_key(k.public_key()).serial_number(x509.random_serial_number())
             .not_valid_before(past - dt.timedelta(days=1)).not_valid_after(past)
             .sign(k, hashes.SHA256()))
        data = pkcs12.serialize_key_and_certificates(b"o", k, c, None, serialization.NoEncryption())
        assert "Expired" in inspect_cert(data, "old.pfx", ".pfx")

    @pytest.mark.parametrize("junk", [b"not a cert at all", b"", b"Hello readme " * 40])
    def test_junk_returns_nothing_not_a_false_haspassword(self, junk):
        """Claiming HasPassword for a file we simply failed to parse would
        be a confident lie."""
        assert inspect_cert(junk, "x.pfx", ".pfx") == []


class TestDomainUserRules:
    def _engine(self):
        return RuleEngine(use_default_rules=True)

    def test_patterns_added_to_named_rule(self):
        e = self._engine()
        before = len(e.get_rule("KeepPassOrKeyInCode").compiled)
        n = e.add_domain_user_patterns(["svc_sqlbackup", "adm_jdoe"], ["KeepPassOrKeyInCode"])
        assert n == 2
        assert len(e.get_rule("KeepPassOrKeyInCode").compiled) == before + 2

    def test_short_names_skipped(self):
        e = self._engine()
        n = e.add_domain_user_patterns(["bob", "svc_sqlbackup"], ["KeepPassOrKeyInCode"], min_len=6)
        assert n == 1, "short account names would match half the estate"

    def test_matches_delimited_occurrences_only(self):
        e = self._engine()
        e.add_domain_user_patterns(["svc_sql"], ["KeepPassOrKeyInCode"], min_len=4)
        pats = e.get_rule("KeepPassOrKeyInCode").compiled

        def hit(t):
            return any(p.search(t) for p in pats)

        assert hit('user="svc_sql"')
        assert hit("runas svc_sql now")
        assert not hit("unrelated content with no accounts")

    def test_unknown_rule_name_is_skipped_not_fatal(self):
        e = self._engine()
        assert e.add_domain_user_patterns(["svc_sqlbackup"], ["NoSuchRule"]) == 0

    def test_regex_metacharacters_in_names_are_escaped(self):
        e = self._engine()
        # AD names can contain $ (computer accounts) and . -- these must be
        # literal, not regex syntax.
        n = e.add_domain_user_patterns(["svc.backup$"], ["KeepPassOrKeyInCode"], min_len=4)
        assert n == 1
        pats = e.get_rule("KeepPassOrKeyInCode").compiled
        assert any(p.search('user="svc.backup$"') for p in pats)
        assert not any(p.search('user="svcXbackupY"') for p in pats)
