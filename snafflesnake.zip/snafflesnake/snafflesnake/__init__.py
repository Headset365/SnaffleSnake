"""snafflesnake -- authenticated SMB share/file enumeration with a rules-based
sensitive-file triage classifier. A Python/Linux port of Snaffler's core
workflow, for authorized penetration testing and red team engagements.
"""
__version__ = "0.1.0"
