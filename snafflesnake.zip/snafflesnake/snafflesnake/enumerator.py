"""
snafflesnake.enumerator
~~~~~~~~~~~~~~~~~~
Share discovery and recursive directory/file walking over a single,
already-authenticated SMBConnection (owned by the calling thread).

File classification mirrors Snaffler: a file is checked against every
file-scope rule. Discard rules prune it; reporting rules (Snaffle /
CheckForKeys / SendToNextScope) emit a Finding (subject to PostMatch
discard filters); Relay rules bounce to named target rules, which drive
content scanning (contents-scope targets) or extra metadata matches
(file-scope targets).
"""
from __future__ import annotations

import logging
from collections.abc import Iterator

from impacket.smbconnection import SessionError

from snafflesnake.config import Config
from snafflesnake.content import scan_file
from snafflesnake.models import EnumScope, Finding, MatchAction, Target, Triage
from snafflesnake.rules.engine import RuleEngine
from snafflesnake.utils import human_size, now_snaffler_time, split_extension, to_snaffler_time, to_unc

log = logging.getLogger("snafflesnake.enumerator")

_STYPE_DISKTREE_MASK = 0x0F  # low nibble of shi1_type; 0 == disk share

_REPORTING_ACTIONS = {
    MatchAction.SNAFFLE,
    MatchAction.CHECK_FOR_KEYS,
    MatchAction.SEND_TO_NEXT_SCOPE,
    MatchAction.CHECK_CONTENTS,
}


class Enumerator:
    def __init__(self, conn, engine: RuleEngine, cfg: Config, host: str):
        self.conn = conn
        self.engine = engine
        self.cfg = cfg
        self.host = host
        self.walkable_shares: list[str] = []

    # -- shares -----------------------------------------------------------

    def list_shares(self) -> list[Finding]:
        results: list[Finding] = []
        self.walkable_shares = []
        try:
            raw_shares = self.conn.listShares()
        except SessionError as e:
            log.warning("failed to list shares on %s: %s", self.host, e)
            return results

        for s in raw_shares:
            name = s["shi1_netname"][:-1]
            if isinstance(name, bytes):
                name = name.decode(errors="replace")
            stype = s["shi1_type"]

            if (stype & _STYPE_DISKTREE_MASK) != 0:
                continue
            if self.cfg.shares_include and name not in self.cfg.shares_include:
                continue
            if name in self.cfg.shares_exclude:
                continue

            target = Target(host=self.host, share=name, is_dir=True)
            match = self.engine.classify(target, EnumScope.SHARE)

            triage, rule_name, keyword = Triage.GREEN, "", ""
            if match is not None:
                rule, keyword = match
                triage, rule_name = rule.triage, rule.name
                if rule.match_action == MatchAction.DISCARD:
                    continue  # e.g. IPC$/print$ -- not reported, not walked

            try:
                self.conn.listPath(name, "*")
            except SessionError:
                if self.cfg.verbose:
                    log.info("share not readable, skipping: \\\\%s\\%s", self.host, name)
                continue

            results.append(
                Finding(
                    triage=triage,
                    rule_name=rule_name,
                    task_type="Share",
                    host=self.host,
                    share=name,
                    unc=to_unc(self.host, name, None),
                    keyword=keyword,
                    log_time=now_snaffler_time(),
                )
            )

            # Snaffler reports C$/ADMIN$ (KeepDollarShares) but does NOT
            # scan inside them; honor that unless --include-admin.
            if _is_admin_share(name) and not self.cfg.include_admin:
                continue
            self.walkable_shares.append(name)
        return results

    # -- directory / file walk ---------------------------------------------

    def walk_share(self, share: str) -> Iterator[Finding]:
        visited: set[str] = set()
        yield from self._walk_dir(share, "", depth=0, visited=visited)

    def scan_dir(self, share: str, rel_path: str, depth: int) -> tuple[list[Finding], list[str]]:
        """List ONE directory: classify its files and return
        (findings, subdirectory_rel_paths) without recursing.

        This is what lets the scheduler treat each directory as an
        independent unit of work and hand it to any thread, instead of a
        single thread owning an entire recursive share walk. walk_share()
        is kept for single-threaded use and tests.
        """
        findings: list[Finding] = []
        subdirs: list[str] = []

        if depth > self.cfg.max_depth:
            return findings, subdirs

        smb_pattern = ((rel_path + "/*") if rel_path else "*").replace("\\", "/")
        try:
            entries = self.conn.listPath(share, smb_pattern)
        except SessionError as e:
            if self.cfg.verbose:
                log.info("access denied listing \\\\%s\\%s\\%s: %s", self.host, share, rel_path, e)
            return findings, subdirs

        for entry in entries:
            fname = entry.get_longname()
            if fname in (".", ".."):
                continue

            full_rel = f"{rel_path}\\{fname}" if rel_path else fname

            if entry.is_directory() != 0:
                dir_target = Target(host=self.host, share=share, path=full_rel, name=fname, is_dir=True)
                match = self.engine.classify(dir_target, EnumScope.DIRECTORY)
                if match is not None and match[0].match_action == MatchAction.DISCARD:
                    continue
                subdirs.append(full_rel)
                continue

            findings.extend(self._classify_file(share, full_rel, fname, entry))

        return findings, subdirs

    def _walk_dir(self, share: str, rel_path: str, depth: int, visited: set[str]) -> Iterator[Finding]:
        if depth > self.cfg.max_depth:
            return

        smb_pattern = ((rel_path + "/*") if rel_path else "*").replace("\\", "/")
        try:
            entries = self.conn.listPath(share, smb_pattern)
        except SessionError as e:
            if self.cfg.verbose:
                log.info("access denied listing \\\\%s\\%s\\%s: %s", self.host, share, rel_path, e)
            return

        for entry in entries:
            fname = entry.get_longname()
            if fname in (".", ".."):
                continue

            full_rel = f"{rel_path}\\{fname}" if rel_path else fname
            is_dir = entry.is_directory() != 0

            if is_dir:
                dir_target = Target(host=self.host, share=share, path=full_rel, name=fname, is_dir=True)
                match = self.engine.classify(dir_target, EnumScope.DIRECTORY)
                if match is not None and match[0].match_action == MatchAction.DISCARD:
                    continue
                key = f"{share}\\{full_rel}".lower()
                if key in visited:
                    continue
                visited.add(key)
                yield from self._walk_dir(share, full_rel, depth + 1, visited)
                continue

            yield from self._classify_file(share, full_rel, fname, entry)

    def _classify_file(self, share: str, full_rel: str, fname: str, entry) -> Iterator[Finding]:
        try:
            size = entry.get_filesize()
            mtime = entry.get_mtime_epoch()
            ctime = entry.get_ctime_epoch()
        except Exception:
            size, mtime, ctime = 0, None, None

        ext = split_extension(fname)
        target = Target(
            host=self.host, share=share, path=full_rel, name=fname,
            extension=ext, size=size, is_dir=False, mtime=mtime, ctime=ctime,
        )

        matches = self.engine.all_matches(target, EnumScope.FILE)
        if not matches:
            return

        # A discard match prunes the file entirely.
        if any(rule.match_action == MatchAction.DISCARD for rule, _ in matches):
            return

        # PostMatch discard filters (false-positive suppression).
        if self.engine.postmatch_discard(target):
            return

        relay_content_rules: set[str] = set()
        grep_all_contents = False

        for rule, keyword in matches:
            if rule.match_action in _REPORTING_ACTIONS:
                finding = self._file_finding(target, rule, keyword)
                if rule.match_action == MatchAction.CHECK_FOR_KEYS:
                    # Snaffler's "special x509 dance": actually parse the
                    # cert so we can say whether there's a usable private
                    # key, whether it's password-protected (and if a
                    # well-known password opens it), and whether it's a CA
                    # cert. A public-only cert is noise; a CA key is not.
                    reasons = self._x509_reasons(share, full_rel, fname, target)
                    if reasons:
                        finding.content = ", ".join(reasons)
                        if "HasPrivateKey" not in reasons:
                            # No usable key -- downgrade so it doesn't sit
                            # at the top of the report alongside real keys.
                            finding.triage = min(finding.triage, Triage.YELLOW)
                yield finding
                if rule.match_action == MatchAction.CHECK_CONTENTS:
                    grep_all_contents = True
            elif rule.match_action == MatchAction.RELAY:
                for tname in rule.relay_targets:
                    tr = self.engine.get_rule(tname)
                    if tr is None:
                        continue
                    if tr.enum_scope == EnumScope.CONTENTS:
                        relay_content_rules.add(tname)
                    elif tr.enum_scope == EnumScope.FILE:
                        matched, k = self.engine.match_rule(tr, target)
                        if matched and tr.match_action in _REPORTING_ACTIONS:
                            yield self._file_finding(target, tr, k)

        # Content scanning: driven by relay targets (Snaffler-faithful), or
        # all-contents when a check_contents rule fired, or -- only when the
        # operator opts in with --grep-all -- the grepable-extension fallback.
        wants_scan = bool(relay_content_rules) or grep_all_contents or (
            self.cfg.grep_all and ext in self.cfg.grepable_exts
        )
        if not wants_scan or size > self.cfg.max_file_size:
            return

        # Skip the transfer entirely for binary containers: the text
        # heuristic would discard the bytes anyway, so downloading a 40MB
        # .docx just to throw it away is pure wasted bandwidth. The
        # name/extension match above was already reported.
        if ext in self.cfg.binary_exts:
            return

        names = None if grep_all_contents else (sorted(relay_content_rules) or None)
        try:
            for f in scan_file(self.conn, share, full_rel, size, target, self.engine, self.cfg, rule_names=names):
                yield f
        except SessionError as e:
            if self.cfg.verbose:
                log.info("could not read \\\\%s\\%s\\%s: %s", self.host, share, full_rel, e)

    def _x509_reasons(self, share: str, full_rel: str, fname: str, target: Target) -> list[str]:
        """Download and inspect a cert/keystore. Certs are small, so the
        transfer is cheap; anything implausibly large is skipped rather
        than pulled."""
        if (target.size or 0) > self.cfg.max_cert_size:
            return []
        import io

        from snafflesnake.certs import inspect_cert

        try:
            buf = io.BytesIO()
            self.conn.getFile(share, full_rel.replace("\\", "/"), buf.write)
            return inspect_cert(
                buf.getvalue(), filename=fname, extension=target.extension or "",
                passwords=self.cfg.cert_passwords or None,
            )
        except SessionError as e:
            if self.cfg.verbose:
                log.info("could not read cert \\\\%s\\%s\\%s: %s", self.host, share, full_rel, e)
            return []
        except Exception as e:  # noqa: BLE001 -- a malformed cert must not kill the walk
            log.debug("x509 inspection failed for %s: %s", full_rel, e)
            return []

    def _file_finding(self, target: Target, rule, keyword: str) -> Finding:
        return Finding(
            triage=rule.triage,
            rule_name=rule.name,
            task_type="File",
            host=target.host,
            share=target.share or "",
            full_path=target.path or "",
            unc=target.unc,
            extension=target.extension or "",
            size=target.size or 0,
            size_human=human_size(target.size or 0),
            modified=to_snaffler_time(target.mtime),
            created=to_snaffler_time(target.ctime),
            permissions="R",
            keyword=keyword,
            content="",
            log_time=now_snaffler_time(),
        )


def _is_admin_share(name: str) -> bool:
    """C$, D$, ..., ADMIN$ style administrative shares."""
    upper = name.upper()
    if upper == "ADMIN$":
        return True
    return len(name) == 2 and name[1] == "$" and name[0].isalpha()
