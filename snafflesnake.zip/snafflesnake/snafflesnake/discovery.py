"""
snafflesnake.discovery
~~~~~~~~~~~~~~~~~~~~~~
Optional LDAP-based host discovery: pull the domain's computer objects so
you don't have to hand-build a target list, mirroring Snaffler's behavior
when no explicit targets are given. Off by default -- see Config.discover
/ the CLI's --discover flag. Explicit targets (positional hosts or
--targets-file) always take precedence over discovery, same as Snaffler.

Auth support:
  - password (-p): NTLM bind (DOMAIN\\username + password). Works against
    any AD DC, no extra dependencies.
  - Kerberos (--use-ccache): SASL GSSAPI bind using the ticket already in
    $KRB5CCNAME, via the optional `gssapi` package. Not installed by
    default -- it needs system Kerberos dev headers (libkrb5-dev). Install
    it yourself (`pip install gssapi`) if you want this path.
  - NTLM hash only (-H, no plaintext password): NOT supported for
    discovery. ldap3's NTLM bind needs the actual password client-side to
    compute the NTLM response -- there's no pass-the-hash path for LDAP
    bind here. Use --discover with -p or Kerberos, or fall back to
    explicit targets / --targets-file.
"""
from __future__ import annotations

import datetime as dt

import ldap3
from ldap3.core.exceptions import LDAPException

from snafflesnake.config import Config

# Windows FILETIME epoch: 1601-01-01, ticks are 100ns intervals since then.
_FILETIME_EPOCH = dt.datetime(1601, 1, 1, tzinfo=dt.timezone.utc)

DEFAULT_LDAP_FILTER = "(objectClass=computer)"


class DiscoveryError(Exception):
    """Raised for any discovery failure -- bad config, bind failure, or
    search failure. cli.py catches this and exits cleanly.
    """


def _filetime_to_datetime(value) -> dt.datetime | None:
    """Convert a Windows FILETIME string/int to an aware UTC datetime.
    Returns None for missing/zero/unparseable values (0 conventionally
    means "never logged on").
    """
    try:
        ticks = int(value)
    except (TypeError, ValueError):
        return None
    if ticks <= 0:
        return None
    try:
        return _FILETIME_EPOCH + dt.timedelta(microseconds=ticks / 10)
    except (OverflowError, OSError):
        return None


def _first(attrs: dict, key: str) -> str | None:
    """ldap3 always returns attribute values as a list (possibly empty),
    regardless of whether the attribute is single- or multi-valued.
    """
    values = attrs.get(key)
    if not values:
        return None
    return values[0] or None


def _base_dn(domain: str) -> str:
    parts = [p for p in domain.split(".") if p and p != "."]
    if not parts:
        raise DiscoveryError(
            "--discover needs a fully-qualified domain (-d/--domain, e.g. corp.local) "
            "to build the LDAP search base"
        )
    return ",".join(f"DC={p}" for p in parts)


def _connect(cfg: Config) -> ldap3.Connection:
    if not cfg.dc_ip:
        raise DiscoveryError("--discover requires --dc-ip (the LDAP server/domain controller to query)")

    port = cfg.ldap_port or (636 if cfg.ldaps else 389)
    server = ldap3.Server(cfg.dc_ip, port=port, use_ssl=cfg.ldaps, get_info=ldap3.NONE)

    if cfg.kerberos:
        try:
            import gssapi  # noqa: F401
        except ImportError as e:
            raise DiscoveryError(
                "Kerberos-based LDAP discovery needs the optional 'gssapi' package "
                "(pip install gssapi -- needs libkrb5-dev on the system). Install it, "
                "or use --discover with -p/--password auth instead."
            ) from e
        conn = ldap3.Connection(server, authentication=ldap3.SASL, sasl_mechanism=ldap3.GSSAPI)
    elif cfg.password is not None:
        user = f"{cfg.domain}\\{cfg.username}" if cfg.domain and cfg.domain != "." else cfg.username
        conn = ldap3.Connection(server, user=user, password=cfg.password, authentication=ldap3.NTLM)
    else:
        raise DiscoveryError(
            "--discover isn't supported with hash-only authentication: ldap3's NTLM bind "
            "needs the plaintext password client-side to compute the response, not a stored "
            "hash. Use --discover with -p/--password or Kerberos, or supply explicit targets "
            "(positional hosts / --targets-file) instead."
        )

    try:
        bound = conn.bind()
    except LDAPException as e:
        raise DiscoveryError(f"LDAP connection to {cfg.dc_ip}:{port} failed: {e}") from e
    if not bound:
        raise DiscoveryError(f"LDAP bind to {cfg.dc_ip}:{port} failed: {conn.result}")

    return conn


def discover_hosts(cfg: Config) -> list[str]:
    """Query the domain for computer objects and return a deduplicated,
    sorted list of hostnames to scan.

    Applies (in order): the LDAP filter (cfg.ldap_filter), the staleness
    filter (cfg.stale_days via lastLogonTimestamp -- 0 disables it), and
    the exclusion list (cfg.discover_exclude).
    """
    conn = _connect(cfg)
    base_dn = _base_dn(cfg.domain)
    cutoff = (
        dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=cfg.stale_days)
        if cfg.stale_days > 0
        else None
    )
    exclude_lower = {h.lower() for h in cfg.discover_exclude}

    hosts: set[str] = set()
    try:
        entries = conn.extend.standard.paged_search(
            search_base=base_dn,
            search_filter=cfg.ldap_filter,
            attributes=["dNSHostName", "name", "lastLogonTimestamp"],
            paged_size=500,
            generator=True,
        )
        for entry in entries:
            attrs = entry.get("attributes")
            if not attrs:
                continue  # e.g. a searchResRef referral, not a real entry

            if cutoff is not None:
                last_seen = _filetime_to_datetime(_first(attrs, "lastLogonTimestamp"))
                if last_seen is None or last_seen < cutoff:
                    continue

            hostname = _first(attrs, "dNSHostName")
            if not hostname:
                name = _first(attrs, "name")
                if not name:
                    continue
                hostname = f"{name}.{cfg.domain}" if cfg.domain and cfg.domain != "." else name
            hostname = hostname.lower()

            if hostname in exclude_lower:
                continue
            hosts.add(hostname)
    except LDAPException as e:
        raise DiscoveryError(f"LDAP search failed: {e}") from e
    finally:
        conn.unbind()

    return sorted(hosts)


# --- domain user rules (Snaffler's -u/--domainusers) ---------------------

# Account-name fragments that mark a user as interesting. Ported verbatim
# from Snaffler's DomainUserMatchStrings.
DEFAULT_USER_MATCH_STRINGS = [
    "sql", "svc", "service", "backup", "ccm", "scom", "opsmgr", "adm",
    "adcs", "MSOL", "adsync", "thycotic", "secretserver", "cyberark",
    "configmgr",
]

# userAccountControl bits Snaffler treats as automatically interesting.
_UAC_TRUSTED_FOR_DELEGATION = 0x80000
_UAC_TRUSTED_TO_AUTH_FOR_DELEGATION = 0x1000000


def discover_domain_users(cfg: Config) -> list[str]:
    """Return 'interesting' domain account names for dynamic rule building.

    A user is kept if it is trusted for delegation (either flavour), or its
    sAMAccountName contains one of the match strings -- service accounts,
    admin accounts, and password-vault accounts being the ones whose
    appearance in a config file actually means something.
    """
    conn = _connect(cfg)
    base_dn = _base_dn(cfg.domain)
    match_strings = [s.lower() for s in (cfg.user_match_strings or DEFAULT_USER_MATCH_STRINGS)]

    users: set[str] = set()
    try:
        entries = conn.extend.standard.paged_search(
            search_base=base_dn,
            search_filter="(&(objectClass=user)(objectCategory=person))",
            attributes=["sAMAccountName", "userAccountControl"],
            paged_size=500,
            generator=True,
        )
        for entry in entries:
            attrs = entry.get("attributes")
            if not attrs:
                continue
            name = _first(attrs, "sAMAccountName")
            if not name:
                continue

            keep = False
            try:
                uac = int(_first(attrs, "userAccountControl") or 0)
            except (TypeError, ValueError):
                uac = 0
            if uac & (_UAC_TRUSTED_FOR_DELEGATION | _UAC_TRUSTED_TO_AUTH_FOR_DELEGATION):
                keep = True
            if not keep:
                lowered = name.lower()
                keep = any(s in lowered for s in match_strings)

            if keep:
                users.add(name)
    except LDAPException as e:
        raise DiscoveryError(f"LDAP user search failed: {e}") from e
    finally:
        conn.unbind()

    return sorted(users)
