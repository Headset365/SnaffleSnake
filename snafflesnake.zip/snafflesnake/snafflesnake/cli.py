"""
snafflesnake.cli
~~~~~~~~~~~
argparse surface and orchestration entry point. This is the ONLY place
that constructs a Config -- every other module receives it read-only.
"""
from __future__ import annotations

import argparse
import logging
import sys

from snafflesnake.config import Config
from snafflesnake.output import OutputSink
from snafflesnake.rules.engine import RuleEngine, RuleLoadError
from snafflesnake.scheduler import run as scheduler_run
from snafflesnake.utils import parse_hash, parse_size


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="snafflesnake",
        description="A Python/Linux Snaffler port: authenticated SMB share/file enumeration "
        "with a rules-based sensitive-file triage classifier. For authorized "
        "penetration testing and red team engagements only.",
    )

    p.add_argument("targets", nargs="*", help="Hosts/IPs to enumerate (in addition to --targets-file)")
    p.add_argument("--targets-file", help="Path to a file of hosts, one per line")

    auth_group = p.add_argument_group("Authentication")
    auth_group.add_argument("-u", "--username", required=True, help="Username")
    auth_group.add_argument("-p", "--password", help="Password")
    auth_group.add_argument("-H", "--hash", help="NTLM hash: LMHASH:NTHASH, :NTHASH, or bare NTHASH")
    auth_group.add_argument("-d", "--domain", default="", help="Domain (or '.' for local accounts)")
    auth_group.add_argument("-k", "--kerberos", action="store_true", help="Use Kerberos authentication")
    auth_group.add_argument("--use-ccache", action="store_true", help="Use ticket from $KRB5CCNAME (implies -k)")
    auth_group.add_argument("--dc-ip", help="Domain controller IP (for Kerberos)")

    disc_group = p.add_argument_group(
        "Discovery (opt-in; explicit targets/--targets-file always take precedence)"
    )
    disc_group.add_argument("--discover", action="store_true",
                             help="No explicit targets given? Discover hosts via LDAP against "
                             "the domain instead of requiring a list (needs --dc-ip)")
    disc_group.add_argument("--ldap-filter", default="(objectClass=computer)",
                             help="LDAP filter for discovery (default: (objectClass=computer))")
    disc_group.add_argument("--stale-days", type=int, default=120,
                             help="Skip discovered computers not seen in this many days "
                             "(default: 120; 0 disables the staleness filter)")
    disc_group.add_argument("--discover-exclude-file",
                             help="Path to a file of hostnames to exclude from discovery, one per line")
    disc_group.add_argument("--ldaps", action="store_true", help="Use LDAPS (port 636) for discovery")
    disc_group.add_argument("--ldap-port", type=int, help="Override the LDAP port (default: 389, or 636 with --ldaps)")
    disc_group.add_argument("--domain-users", action="store_true",
                             help="Pull interesting-looking accounts (service/admin/vault accounts, "
                             "and anything trusted for delegation) from AD and match files/content "
                             "referencing them (needs --dc-ip; Snaffler's -u)")
    disc_group.add_argument("--domain-user-min-len", type=int, default=6,
                             help="Ignore discovered account names shorter than this when building "
                             "rules (default: 6; short names match everything)")

    enum_group = p.add_argument_group("Enumeration")
    enum_group.add_argument("--threads", type=int, default=10, help="Max concurrent host connections (default: 10; "
                             "use 2-4 under proxychains)")
    enum_group.add_argument("--max-depth", type=int, default=30, help="Max directory recursion depth (default: 30)")
    enum_group.add_argument("--max-file-size", default="10M",
                             help="Max file size to content-scan, e.g. 10M, 500K (default: 10M)")
    enum_group.add_argument("--port", type=int, default=445, help="SMB port (default: 445)")
    enum_group.add_argument("--timeout", type=int, default=15, help="Per-operation SMB timeout in seconds (default: 15)")
    enum_group.add_argument("--include-admin", action="store_true",
                             help="Include ADMIN$/C$-style administrative shares")
    enum_group.add_argument("--shares", help="Comma-separated list of share names to restrict to")
    enum_group.add_argument("--exclude-shares", help="Comma-separated list of share names to exclude")

    rules_group = p.add_argument_group("Rules")
    rules_group.add_argument("--rules", action="append", default=[],
                              help="Path to a YAML rules file (repeatable; merged, later overrides earlier by name)")
    rules_group.add_argument("--no-default-rules", action="store_true", help="Don't load the built-in default rules")
    rules_group.add_argument("--min-triage", choices=["green", "yellow", "red", "black"], default="green",
                              help="Only report findings at or above this severity (default: green = "
                              "report everything). Green is the noisy tier -- try 'yellow' to cut "
                              "most false positives")
    rules_group.add_argument("--grep-all", action="store_true",
                              help="Also content-scan every file with a known text extension, even if "
                              "no rule pointed at it (slower, noisier; off by default)")

    resume_group = p.add_argument_group("Resume")
    resume_group.add_argument("--state-file", metavar="FILE",
                               help="Record completed host/share units to FILE so an interrupted scan "
                               "can be resumed")
    resume_group.add_argument("--resume", action="store_true",
                               help="Skip host/share units already recorded in --state-file")

    out_group = p.add_argument_group("Output (mirrors Snaffler's switches)")
    out_group.add_argument("-o", "--outfile", help="Write results to this file")
    out_group.add_argument("-s", "--stdout", dest="to_console", action="store_true", default=True,
                            help="Also stream results to console (default: on)")
    out_group.add_argument("--no-stdout", dest="to_console", action="store_false", help="Suppress console output")
    out_group.add_argument("-t", "--type", dest="out_format", choices=["plain", "tsv", "json"], default="plain",
                            help="Output format (default: plain)")
    out_group.add_argument("-y", "--tsv", action="store_true", help="Alias for --type tsv")
    out_group.add_argument("--separator", type=int, default=9, help="TSV field separator byte value (default: 9 = TAB)")
    out_group.add_argument("--tsv-legacy", action="store_true", help="Emit 13-column TSV instead of 14-column")
    out_group.add_argument("--html", dest="html_file", metavar="FILE",
                           help="Write a self-contained, filterable HTML report to FILE")
    out_group.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")
    out_group.add_argument("--no-color", action="store_true", help="Disable colored console output")

    return p


def _resolve_targets(args: argparse.Namespace) -> list[str]:
    targets = list(args.targets)
    if args.targets_file:
        try:
            with open(args.targets_file, "r", encoding="utf-8") as fh:
                targets.extend(line.strip() for line in fh if line.strip())
        except OSError as e:
            raise SystemExit(f"snafflesnake: could not read --targets-file: {e}")
    # de-duplicate while preserving order
    seen: set[str] = set()
    ordered = []
    for t in targets:
        if t not in seen:
            seen.add(t)
            ordered.append(t)
    return ordered


def _build_config(args: argparse.Namespace) -> Config:
    hosts = _resolve_targets(args)

    if hosts and args.discover:
        print(
            "snafflesnake: explicit targets given, ignoring --discover "
            "(explicit targets always take precedence)",
            file=sys.stderr,
        )
    elif not hosts and not args.discover:
        raise SystemExit(
            "snafflesnake: no targets specified (positional hosts, --targets-file, "
            "or --discover required)"
        )

    auth_modes_set = sum([bool(args.kerberos or args.use_ccache), bool(args.hash), bool(args.password)])
    if auth_modes_set == 0:
        raise SystemExit("snafflesnake: one of --password, --hash, or --kerberos/--use-ccache is required")
    if auth_modes_set > 1:
        raise SystemExit("snafflesnake: specify exactly one of --password, --hash, or --kerberos/--use-ccache")

    will_discover = not hosts and args.discover
    if will_discover:
        if not args.dc_ip:
            raise SystemExit("snafflesnake: --discover requires --dc-ip")
        if args.hash and not args.password:
            raise SystemExit(
                "snafflesnake: --discover isn't supported with hash-only authentication "
                "(LDAP bind needs a plaintext password or Kerberos, not a stored hash); "
                "use -p/--password or Kerberos with --discover, or supply explicit targets"
            )

    discover_exclude: set[str] = set()
    if args.discover_exclude_file:
        try:
            with open(args.discover_exclude_file, "r", encoding="utf-8") as fh:
                discover_exclude = {line.strip() for line in fh if line.strip()}
        except OSError as e:
            raise SystemExit(f"snafflesnake: could not read --discover-exclude-file: {e}")

    lmhash, nthash = "", ""
    if args.hash:
        try:
            lmhash, nthash = parse_hash(args.hash)
        except ValueError as e:
            raise SystemExit(f"snafflesnake: {e}")

    try:
        max_file_size = parse_size(args.max_file_size)
    except ValueError as e:
        raise SystemExit(f"snafflesnake: {e}")

    if args.domain_users:
        if not args.dc_ip:
            raise SystemExit("snafflesnake: --domain-users requires --dc-ip")
        if args.hash and not args.password:
            raise SystemExit(
                "snafflesnake: --domain-users isn't supported with hash-only authentication "
                "(LDAP bind needs a plaintext password or Kerberos)"
            )

    if args.resume and not args.state_file:
        raise SystemExit("snafflesnake: --resume requires --state-file (the ledger to resume from)")

    triage_floor = {"green": 1, "yellow": 2, "red": 3, "black": 4}[args.min_triage]

    out_format = "tsv" if args.tsv else args.out_format

    shares_include = [s.strip() for s in args.shares.split(",")] if args.shares else []
    shares_exclude = [s.strip() for s in args.exclude_shares.split(",")] if args.exclude_shares else []

    cfg = Config(
        hosts=hosts,
        username=args.username,
        password=args.password,
        lmhash=lmhash,
        nthash=nthash,
        domain=args.domain,
        kerberos=bool(args.kerberos or args.use_ccache),
        use_ccache=args.use_ccache,
        dc_ip=args.dc_ip,
        discover=will_discover,
        ldap_filter=args.ldap_filter,
        stale_days=args.stale_days,
        discover_exclude=discover_exclude,
        ldaps=args.ldaps,
        ldap_port=args.ldap_port,
        domain_users=args.domain_users,
        domain_user_min_len=args.domain_user_min_len,
        port=args.port,
        timeout=args.timeout,
        threads=args.threads,
        max_depth=args.max_depth,
        max_file_size=max_file_size,
        include_admin=args.include_admin,
        shares_include=shares_include,
        shares_exclude=shares_exclude,
        rule_paths=args.rules,
        use_default_rules=not args.no_default_rules,
        min_triage=triage_floor,
        grep_all=args.grep_all,
        state_file=args.state_file,
        resume=args.resume,
        out_format=out_format,
        out_file=args.outfile,
        html_file=args.html_file,
        to_console=args.to_console,
        tsv_separator=args.separator,
        tsv_legacy=args.tsv_legacy,
        color=not args.no_color,
        verbose=args.verbose,
    )

    return cfg


def main(argv: list[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    cfg = _build_config(args)

    logging.basicConfig(
        level=logging.DEBUG if cfg.verbose else logging.WARNING,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    if cfg.discover:
        from snafflesnake.discovery import DiscoveryError, discover_hosts

        print(f"snafflesnake: discovering hosts via LDAP against {cfg.dc_ip} ...", file=sys.stderr)
        try:
            cfg.hosts = discover_hosts(cfg)
        except DiscoveryError as e:
            print(f"snafflesnake: discovery failed: {e}", file=sys.stderr)
            return 1
        if not cfg.hosts:
            print("snafflesnake: discovery found no hosts to scan (check --ldap-filter/--stale-days)",
                  file=sys.stderr)
            return 1
        print(f"snafflesnake: discovered {len(cfg.hosts)} host(s)", file=sys.stderr)

    try:
        engine = RuleEngine(rule_paths=cfg.rule_paths, use_default_rules=cfg.use_default_rules)
    except RuleLoadError as e:
        print(f"snafflesnake: {e}", file=sys.stderr)
        return 1

    # Note: --include-admin is honored in the enumerator (it walks C$/ADMIN$
    # shares that are otherwise reported-but-not-walked). No rule needs to be
    # dropped, since Snaffler's default rules report dollar shares rather than
    # discarding them.

    if cfg.domain_users:
        from snafflesnake.discovery import DiscoveryError, discover_domain_users

        print("snafflesnake: pulling interesting domain accounts via LDAP ...", file=sys.stderr)
        try:
            users = discover_domain_users(cfg)
        except DiscoveryError as e:
            print(f"snafflesnake: domain-user discovery failed: {e}", file=sys.stderr)
            return 1
        added = engine.add_domain_user_patterns(
            users, cfg.domain_user_rules, min_len=cfg.domain_user_min_len
        )
        print(
            f"snafflesnake: {len(users)} interesting account(s) found, "
            f"{added} pattern(s) added to content rules",
            file=sys.stderr,
        )

    sink = OutputSink(cfg)

    try:
        scheduler_run(cfg, engine, sink)
    except KeyboardInterrupt:
        print("\nsnafflesnake: interrupted", file=sys.stderr)
        return 130

    return 0


if __name__ == "__main__":
    sys.exit(main())
