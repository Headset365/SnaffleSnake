"""
snafflesnake.rules.engine
~~~~~~~~~~~~~~~~~~~~
Loads YAML rule files and classifies Targets / file contents against them,
replicating Snaffler's matching semantics exactly.

Snaffler parity notes (verified against SnaffCore source):
  - EVERY wordlist entry is compiled to a regex, anchored by wordlist
    type: exact -> ^p$, startswith -> ^p, endswith -> p$, contains -> p,
    regex -> p. All matched case-insensitively (re.IGNORECASE). This is
    why ported wordlists contain regex fragments like '\\.ppk'.
  - Relay rules bounce to named relay_targets: contents-scope targets
    grep the file bytes, file-scope targets re-match on metadata.
  - PostMatch rules are discard-only filters applied after a Snaffle
    match to suppress known false positives.
  - Extension matching special-cases '.bak': a file like 'thing.kdbx.bak'
    is matched as if it were 'thing.kdbx'.
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml

from snafflesnake.models import (
    EnumScope,
    Finding,
    MatchAction,
    MatchLocation,
    Rule,
    Target,
    Triage,
    WordListType,
)
from snafflesnake.utils import extract_context, size_expr_match

# Actions that mean "report this file" (as opposed to discard / relay).
_REPORTING_ACTIONS = {
    MatchAction.SNAFFLE,
    MatchAction.CHECK_FOR_KEYS,
    MatchAction.SEND_TO_NEXT_SCOPE,
    MatchAction.CHECK_CONTENTS,
}


class RuleLoadError(Exception):
    pass


def _anchor(pattern: str, wl_type: WordListType) -> str:
    """Apply Snaffler's per-type anchoring to a wordlist entry."""
    if wl_type == WordListType.EXACT:
        return "^" + pattern + "$"
    if wl_type == WordListType.STARTSWITH:
        return "^" + pattern
    if wl_type == WordListType.ENDSWITH:
        return pattern + "$"
    # CONTAINS and REGEX: use as-is (unanchored search).
    return pattern


class RuleEngine:
    def __init__(self, rule_paths: list[str] | None = None, use_default_rules: bool = True):
        self._rules: list[Rule] = []
        self._by_scope: dict[EnumScope, list[Rule]] = {s: [] for s in EnumScope}
        self._by_name: dict[str, Rule] = {}

        paths: list[str] = []
        if use_default_rules:
            rules_dir = Path(__file__).parent
            paths.append(str(rules_dir / "default_rules.yaml"))
            extra = rules_dir / "snafflesnake_extra.yaml"
            if extra.is_file():
                paths.append(str(extra))
        if rule_paths:
            paths.extend(rule_paths)

        if not paths:
            raise RuleLoadError("no rule files specified and default rules disabled")

        self._load(paths)

    # -- loading ------------------------------------------------------

    def _load(self, paths: list[str]) -> None:
        loaded_by_name: dict[str, Rule] = {}

        for p in paths:
            path = Path(p)
            if not path.is_file():
                raise RuleLoadError(f"rule file not found: {p}")
            try:
                with path.open("r", encoding="utf-8") as fh:
                    doc = yaml.safe_load(fh) or {}
            except yaml.YAMLError as e:
                raise RuleLoadError(f"invalid YAML in {p}: {e}") from e

            raw_rules = doc.get("rules", [])
            if not isinstance(raw_rules, list):
                raise RuleLoadError(f"'rules' must be a list in {p}")

            for raw in raw_rules:
                try:
                    rule = Rule.from_dict(raw)
                except (KeyError, ValueError) as e:
                    raise RuleLoadError(f"invalid rule in {p}: {raw!r} ({e})") from e

                try:
                    rule.compiled = [
                        re.compile(_anchor(pat, rule.wordlist_type), re.IGNORECASE)
                        for pat in rule.wordlist
                    ]
                except re.error as e:
                    raise RuleLoadError(f"invalid regex in rule {rule.name!r}: {e}") from e

                loaded_by_name[rule.name] = rule  # later files override by name

        self._rules = list(loaded_by_name.values())
        self._by_name = {r.name: r for r in self._rules}
        self._by_scope = {s: [] for s in EnumScope}
        for rule in self._rules:
            self._by_scope[rule.enum_scope].append(rule)

    # -- queries --------------------------------------------------------

    def rules_for(self, scope: EnumScope) -> list[Rule]:
        return self._by_scope.get(scope, [])

    def get_rule(self, name: str) -> Rule | None:
        return self._by_name.get(name)

    def drop_rule(self, name: str) -> bool:
        if name not in self._by_name:
            return False
        del self._by_name[name]
        self._rules = [r for r in self._rules if r.name != name]
        for scope in self._by_scope:
            self._by_scope[scope] = [r for r in self._by_scope[scope] if r.name != name]
        return True

    # -- matching helpers -------------------------------------------------

    @staticmethod
    def _location_value(target: Target, location: MatchLocation) -> str | None:
        # Snaffler matches ShareName and FilePath rules against the full
        # UNC path (\\host\share\dir\file), which is why the ported
        # wordlists carry leading backslashes (e.g. '\\ipc\$', '\\winsxs').
        if location == MatchLocation.SHARE_NAME:
            return target.unc
        if location == MatchLocation.FILE_PATH:
            return target.unc
        if location == MatchLocation.FILE_NAME:
            return target.name
        if location == MatchLocation.FILE_EXTENSION:
            return _effective_extension(target)
        return None

    def _rule_matches_target(self, rule: Rule, target: Target) -> tuple[bool, str]:
        if rule.match_location == MatchLocation.FILE_LENGTH:
            if target.size is None:
                return False, ""
            # snafflesnake extension: if the wordlist holds comparison
            # expressions ('>10000000'), use them. Otherwise fall back to
            # Snaffler's exact-equality-to-match_length behavior.
            if rule.wordlist:
                for expr in rule.wordlist:
                    try:
                        if size_expr_match(target.size, expr):
                            return True, expr
                    except ValueError:
                        continue
                return False, ""
            if target.size == rule.match_length:
                return True, str(rule.match_length)
            return False, ""

        if rule.match_location == MatchLocation.FILE_MD5:
            return False, ""

        value = self._location_value(target, rule.match_location)
        if value is None:
            return False, ""

        for pattern in rule.compiled:
            if pattern.search(value):
                return True, pattern.pattern
        return False, ""

    def classify(self, target: Target, scope: EnumScope):
        """Return (rule, matched_pattern) of highest triage, with DISCARD
        winning at share/dir scope, or None if nothing matched.
        """
        best: tuple[Rule, str] | None = None
        discard_hit: tuple[Rule, str] | None = None

        for rule in self.rules_for(scope):
            matched, keyword = self._rule_matches_target(rule, target)
            if not matched:
                continue
            if rule.match_action == MatchAction.DISCARD:
                discard_hit = (rule, keyword)
                continue
            if best is None or rule.triage > best[0].triage:
                best = (rule, keyword)

        if discard_hit is not None:
            return discard_hit
        return best

    def match_rule(self, rule: Rule, target: Target) -> tuple[bool, str]:
        """Public single-rule match (used for relay target dispatch)."""
        return self._rule_matches_target(rule, target)

    def all_matches(self, target: Target, scope: EnumScope) -> list[tuple[Rule, str]]:
        """Return ALL matching rules for a scope (not just the best). A
        file legitimately matches both a Keep rule and a Relay rule -- the
        latter drives content scanning -- so the caller needs every match.
        """
        out: list[tuple[Rule, str]] = []
        for rule in self.rules_for(scope):
            matched, keyword = self._rule_matches_target(rule, target)
            if matched:
                out.append((rule, keyword))
        return out

    def postmatch_discard(self, target: Target) -> bool:
        for rule in self.rules_for(EnumScope.POSTMATCH):
            if rule.match_action != MatchAction.DISCARD:
                continue
            matched, _ = self._rule_matches_target(rule, target)
            if matched:
                return True
        return False

    # -- content scanning -------------------------------------------------

    def scan_content(self, data: bytes, target: Target, rule_names: list[str] | None = None) -> list[Finding]:
        findings: list[Finding] = []
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
                try:
                    text = data.decode("utf-16")
                except UnicodeDecodeError:
                    return findings
            else:
                try:
                    text = data.decode("latin-1")
                except UnicodeDecodeError:
                    return findings

        if rule_names is not None:
            rules = [
                self._by_name[n]
                for n in rule_names
                if n in self._by_name and self._by_name[n].enum_scope == EnumScope.CONTENTS
            ]
        else:
            rules = self.rules_for(EnumScope.CONTENTS)

        for rule in rules:
            if rule.match_location != MatchLocation.FILE_CONTENT:
                continue
            for pattern in rule.compiled:
                for m in pattern.finditer(text):
                    context = extract_context(text, m.start(), m.end(), rule.match_length or 200)
                    findings.append(self._make_content_finding(rule, target, m.group(0), context))
        return findings

    @staticmethod
    def _make_content_finding(rule: Rule, target: Target, keyword: str, context: str) -> Finding:
        return Finding(
            triage=rule.triage,
            rule_name=rule.name,
            task_type="File",
            host=target.host,
            share=target.share or "",
            full_path=target.path or "",
            unc=target.unc,
            extension=target.extension or "",
            size=target.size or 0,
            keyword=keyword,
            content=context,
        )


def _effective_extension(target: Target) -> str | None:
    """Snaffler '.bak' special-casing: 'thing.kdbx.bak' matches as '.kdbx'."""
    ext = target.extension
    if ext != ".bak" or not target.name:
        return ext
    stripped = target.name[: -len(".bak")]
    dot = stripped.rfind(".")
    inner = stripped[dot:].lower() if dot > 0 else ""
    return inner or ext
