"""
snafflesnake.scheduler
~~~~~~~~~~~~~~~~~
Runs enumeration across multiple hosts concurrently. Each worker thread
opens and owns its own SMBConnection -- impacket's SMBConnection is NOT
thread-safe, so connections are never shared across threads.

Findings flow through a single queue.Queue drained by one writer thread,
so console/file output is never interleaved or corrupted.
"""
from __future__ import annotations

import logging
import queue
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from snafflesnake import auth
from snafflesnake.config import Config
from snafflesnake.enumerator import Enumerator
from snafflesnake.models import Finding
from snafflesnake.output import OutputSink
from snafflesnake.rules.engine import RuleEngine

log = logging.getLogger("snafflesnake.scheduler")

# Sentinel used to tell the writer thread there's no more work coming.
_SENTINEL = object()


def run(cfg: Config, engine: RuleEngine, sink: OutputSink) -> None:
    """Entry point called by cli.py. Blocks until all hosts have been
    enumerated (or the user interrupts with Ctrl-C), writing findings to
    `sink` as they arrive.
    """
    finding_queue: "queue.Queue" = queue.Queue()
    stop_event = threading.Event()

    writer = threading.Thread(
        target=_writer_loop, args=(finding_queue, sink), name="snafflesnake-writer", daemon=True
    )
    writer.start()

    try:
        with ThreadPoolExecutor(max_workers=max(1, cfg.threads)) as pool:
            futures = {
                pool.submit(_process_host, host, cfg, engine, finding_queue, stop_event): host
                for host in cfg.hosts
            }
            for fut in as_completed(futures):
                host = futures[fut]
                try:
                    fut.result()
                except Exception as e:  # noqa: BLE001 -- one bad host must not kill the run
                    log.warning("host %s failed: %s", host, e)
    except KeyboardInterrupt:
        log.warning("interrupted -- stopping new work, draining in-flight findings...")
        stop_event.set()
    finally:
        finding_queue.put(_SENTINEL)
        writer.join(timeout=10)
        sink.flush()


def _process_host(host: str, cfg: Config, engine: RuleEngine, out_q: "queue.Queue", stop_event: threading.Event) -> None:
    if stop_event.is_set():
        return

    try:
        conn = auth.connect(host, cfg)
    except auth.AuthError as e:
        log.warning(str(e))
        return

    try:
        enumerator = Enumerator(conn, engine, cfg, host)

        share_findings = enumerator.list_shares()
        for f in share_findings:
            out_q.put(f)

        for share_name in enumerator.walkable_shares:
            if stop_event.is_set():
                return
            try:
                for finding in enumerator.walk_share(share_name):
                    if stop_event.is_set():
                        return
                    out_q.put(finding)
            except Exception as e:  # noqa: BLE001
                log.warning("error walking share \\\\%s\\%s: %s", host, share_name, e)
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _writer_loop(in_q: "queue.Queue", sink: OutputSink) -> None:
    while True:
        item = in_q.get()
        if item is _SENTINEL:
            break
        finding: Finding = item
        try:
            sink.write(finding)
        except Exception:  # noqa: BLE001 -- a bad finding must never kill the writer
            log.exception("failed to write finding")
