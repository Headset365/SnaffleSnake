"""
snafflesnake.scheduler
~~~~~~~~~~~~~~~~~~~~~~
Parallel enumeration.

Work is dispatched at DIRECTORY granularity, not host granularity. A pool
of workers pulls units off a shared queue; listing a directory emits its
file findings and pushes each subdirectory back onto the queue as a new
unit. That means a single huge fileserver parallelizes across all threads,
which the old per-host model could not do (one host == one thread, no
matter what --threads said).

Each worker owns its own SMBConnection per host and reuses it -- impacket's
SMBConnection is NOT thread-safe, so connections are never shared between
threads, but reconnecting per directory would be far more expensive than
the walk itself.

Findings flow through a single queue.Queue drained by one writer thread, so
console/file output is never interleaved or corrupted.
"""
from __future__ import annotations

import logging
import queue
import threading

from snafflesnake import auth
from snafflesnake.config import Config
from snafflesnake.enumerator import Enumerator
from snafflesnake.models import Finding
from snafflesnake.output import OutputSink
from snafflesnake.rules.engine import RuleEngine
from snafflesnake.state import ScanState

log = logging.getLogger("snafflesnake.scheduler")

_SENTINEL = object()


class _WorkQueue:
    """Queue plus an outstanding-task counter.

    Workers can push new work while draining, so "queue is empty" does NOT
    mean "we're finished" -- a worker may be mid-directory and about to
    push ten more. Completion is when outstanding hits zero.
    """

    def __init__(self) -> None:
        self._q: "queue.Queue" = queue.Queue()
        self._outstanding = 0
        self._lock = threading.Lock()
        self.finished = threading.Event()

    def put(self, task) -> None:
        with self._lock:
            self._outstanding += 1
        self._q.put(task)

    def get(self, timeout: float = 0.05):
        return self._q.get(timeout=timeout)

    def done(self) -> None:
        with self._lock:
            self._outstanding -= 1
            if self._outstanding <= 0:
                self.finished.set()


class _ShareTracker:
    """Counts outstanding directory units per (host, share) so a share can
    be checkpointed for --resume only once every one of its directories is
    finished -- which, walking in parallel, is not simply "the last one".
    """

    def __init__(self, state: ScanState | None):
        self._state = state
        self._pending: dict[tuple[str, str], int] = {}
        self._failed: set[tuple[str, str]] = set()
        self._lock = threading.Lock()

    def add(self, host: str, share: str, n: int = 1) -> None:
        if self._state is None:
            return
        with self._lock:
            self._pending[(host, share)] = self._pending.get((host, share), 0) + n

    def fail(self, host: str, share: str) -> None:
        """Mark a share as errored so it is never checkpointed complete."""
        if self._state is None:
            return
        with self._lock:
            self._failed.add((host, share))

    def complete(self, host: str, share: str) -> None:
        if self._state is None:
            return
        with self._lock:
            key = (host, share)
            self._pending[key] = self._pending.get(key, 0) - 1
            if self._pending[key] > 0:
                return
            del self._pending[key]
            if key in self._failed:
                return
        self._state.mark_done(host, share)


class _ConnCache:
    """Per-thread SMBConnection cache, keyed by host."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._local = threading.local()

    def get(self, host: str):
        conns = getattr(self._local, "conns", None)
        if conns is None:
            conns = self._local.conns = {}
        if host in conns:
            return conns[host]
        conn = auth.connect(host, self.cfg)  # may raise auth.AuthError
        conns[host] = conn
        return conn

    def close_all(self) -> None:
        for conn in getattr(self._local, "conns", {}).values():
            try:
                conn.close()
            except Exception:  # noqa: BLE001
                pass
        self._local.conns = {}


def run(cfg: Config, engine: RuleEngine, sink: OutputSink) -> None:
    finding_queue: "queue.Queue" = queue.Queue()
    stop_event = threading.Event()

    state = None
    if cfg.state_file:
        state = ScanState(cfg.state_file, resume=cfg.resume)
        if cfg.resume and state.completed_count():
            log.warning("resuming: skipping %d already-completed share(s)", state.completed_count())

    tracker = _ShareTracker(state)
    work = _WorkQueue()
    conns = _ConnCache(cfg)

    writer = threading.Thread(
        target=_writer_loop, args=(finding_queue, sink), name="snafflesnake-writer", daemon=True
    )
    writer.start()

    for host in cfg.hosts:
        work.put(("host", host, None, None, 0))

    n_workers = max(1, cfg.threads)
    workers = [
        threading.Thread(
            target=_worker_loop,
            args=(work, cfg, engine, finding_queue, stop_event, state, tracker, conns),
            name=f"snafflesnake-worker-{i}",
            daemon=True,
        )
        for i in range(n_workers)
    ]
    for w in workers:
        w.start()

    try:
        # Wait on the completion event rather than join()ing workers, so
        # Ctrl-C is delivered promptly instead of being swallowed by a
        # blocking join.
        while not work.finished.wait(timeout=0.05):
            if not any(w.is_alive() for w in workers):
                break
    except KeyboardInterrupt:
        log.warning("interrupted -- stopping new work, draining in-flight findings...")
        stop_event.set()
    finally:
        stop_event.set()
        for w in workers:
            w.join(timeout=5)
        finding_queue.put(_SENTINEL)
        writer.join(timeout=10)
        # sink.flush() writes the HTML report, so it must run on the
        # interrupt path too -- a partial scan should still produce one.
        sink.flush()
        if state is not None:
            state.close()


def _worker_loop(work, cfg, engine, out_q, stop_event, state, tracker, conns) -> None:
    try:
        while not stop_event.is_set() and not work.finished.is_set():
            try:
                task = work.get(timeout=0.05)
            except queue.Empty:
                continue
            try:
                _handle(task, work, cfg, engine, out_q, stop_event, state, tracker, conns)
            except Exception as e:  # noqa: BLE001 -- one bad unit must not kill the worker
                log.warning("work unit %r failed: %s", task[:3], e)
            finally:
                work.done()
    finally:
        conns.close_all()


def _handle(task, work, cfg, engine, out_q, stop_event, state, tracker, conns) -> None:
    kind, host, share, rel_path, depth = task
    if stop_event.is_set():
        return

    try:
        conn = conns.get(host)
    except auth.AuthError as e:
        log.warning(str(e))
        return

    enumerator = Enumerator(conn, engine, cfg, host)

    if kind == "host":
        for f in enumerator.list_shares():
            out_q.put(f)
        for share_name in enumerator.walkable_shares:
            if state is not None and state.is_done(host, share_name):
                log.debug("resume: skipping completed share \\\\%s\\%s", host, share_name)
                continue
            tracker.add(host, share_name)
            work.put(("dir", host, share_name, "", 0))
        return

    # kind == "dir"
    try:
        findings, subdirs = enumerator.scan_dir(share, rel_path, depth)
    except Exception:
        tracker.fail(host, share)
        raise
    finally:
        pass

    for f in findings:
        if stop_event.is_set():
            break
        out_q.put(f)

    if not stop_event.is_set() and depth < cfg.max_depth:
        for sub in subdirs:
            tracker.add(host, share)
            work.put(("dir", host, share, sub, depth + 1))

    if stop_event.is_set():
        # Interrupted: never checkpoint this share as complete.
        tracker.fail(host, share)
    tracker.complete(host, share)


def _writer_loop(in_q: "queue.Queue", sink: OutputSink) -> None:
    while True:
        item = in_q.get()
        if item is _SENTINEL:
            break
        finding: Finding = item
        try:
            sink.write(finding)
        except Exception:  # noqa: BLE001
            log.exception("failed to write finding")
