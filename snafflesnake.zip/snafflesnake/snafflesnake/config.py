"""
snafflesnake.config
~~~~~~~~~~~~~~
The single Config object threaded through the whole application. cli.py is
the only place that constructs one; every other module receives it read-only.
"""
from __future__ import annotations

from dataclasses import dataclass, field

DEFAULT_GREPABLE_EXTS = {
    ".txt", ".config", ".cnf", ".conf", ".ini", ".yml", ".yaml", ".xml",
    ".json", ".env", ".ps1", ".bat", ".cmd", ".vbs", ".sh", ".sql", ".php",
    ".asp", ".aspx", ".jsp", ".properties", ".pem", ".key",
}


# Compressed/binary container formats. Content-scanning these is pointless
# (the bytes fail the text heuristic anyway) but currently costs a full file
# transfer first, so we skip the download entirely.
DEFAULT_BINARY_EXTS = {
    ".docx", ".xlsx", ".pptx", ".docm", ".xlsm", ".pptm", ".doc", ".xls", ".ppt",
    ".pdf", ".zip", ".7z", ".rar", ".gz", ".bz2", ".xz", ".tar", ".cab", ".msi",
    ".exe", ".dll", ".sys", ".pyd", ".so", ".dylib", ".class", ".jar",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".tif", ".tiff", ".webp",
    ".mp3", ".mp4", ".avi", ".mov", ".wmv", ".wav", ".iso", ".vhd", ".vhdx",
    ".pst", ".ost", ".edb", ".mdf", ".ldf", ".bin", ".dat", ".pyc",
}


@dataclass
class Config:
    # --- targets ---
    hosts: list[str] = field(default_factory=list)

    # --- auth (exactly one of password / nthash / kerberos should be set) ---
    username: str = ""
    password: str | None = None
    lmhash: str = ""
    nthash: str = ""
    domain: str = ""
    kerberos: bool = False
    use_ccache: bool = False
    dc_ip: str | None = None

    # --- LDAP host discovery (opt-in; explicit hosts always take precedence) ---
    discover: bool = False
    ldap_filter: str = "(objectClass=computer)"
    stale_days: int = 120  # skip computers not seen in this many days; 0 disables
    discover_exclude: set[str] = field(default_factory=set)
    ldaps: bool = False
    ldap_port: int | None = None  # None -> 636 if ldaps else 389

    # --- SMB connection ---
    port: int = 445
    timeout: int = 15

    # --- enumeration ---
    threads: int = 10
    max_depth: int = 30
    max_file_size: int = 10_000_000
    include_admin: bool = False
    shares_include: list[str] = field(default_factory=list)
    shares_exclude: list[str] = field(default_factory=list)
    grepable_exts: set[str] = field(default_factory=lambda: set(DEFAULT_GREPABLE_EXTS))
    # Extensions never worth downloading for a CONTENT scan: they're
    # compressed/binary containers, so the NUL-byte heuristic would throw the
    # bytes away after paying full transfer cost. Skipping them pre-download
    # is a pure win -- a name/extension match is still reported either way.
    binary_exts: set[str] = field(default_factory=lambda: set(DEFAULT_BINARY_EXTS))

    # --- rules ---
    rule_paths: list[str] = field(default_factory=list)
    use_default_rules: bool = True

    # --- noise control ---
    # Minimum severity to report (mirrors Snaffler's InterestLevel). Green is
    # the noise tier: rules like KeepNameContainsGreen match any filename
    # containing 'passw'/'secret', which hits benign docs constantly.
    min_triage: int = 1  # 1=green (report everything), 2=yellow, 3=red, 4=black

    # Content-scan every file whose extension is in grepable_exts, even when
    # no relay rule pointed at it. This is a SnaffleSnake superset of
    # Snaffler's behavior -- off by default because it costs a download per
    # matching file and widens the false-positive surface.
    grep_all: bool = False

    # --- domain user rules (-u equivalent) ---
    domain_users: bool = False
    user_match_strings: list[str] = field(default_factory=list)  # empty -> built-in list
    domain_user_min_len: int = 6
    # Snaffler's default target is 'KeepConfigRegexRed', which does NOT exist
    # in its own shipped ruleset (it lives only in a scratch unsorted.txt), so
    # upstream's -u silently attaches to nothing. We target real rules instead.
    domain_user_rules: list[str] = field(
        default_factory=lambda: ["KeepPassOrKeyInCode", "KeepConfigRegexRed"]
    )

    # --- x509 (CheckForKeys rules) ---
    max_cert_size: int = 5_000_000  # certs are small; don't pull huge files
    cert_passwords: list[str] = field(default_factory=list)  # empty -> built-in list

    # --- resume ---
    state_file: str | None = None
    resume: bool = False

    # --- output ---
    out_format: str = "plain"  # "plain" | "tsv" | "json"
    out_file: str | None = None
    html_file: str | None = None  # write a self-contained HTML report here
    to_console: bool = True
    tsv_separator: int = 9  # TAB
    tsv_legacy: bool = False
    color: bool = True
    verbose: bool = False
