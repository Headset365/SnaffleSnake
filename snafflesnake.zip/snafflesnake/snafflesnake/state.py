"""
snafflesnake.state
~~~~~~~~~~~~~~~~~~
Resume support. Long scans of big estates get interrupted -- a dropped
pivot, a Ctrl-C, a laptop lid. This records which (host, share) units have
been fully walked so a re-run with --resume can skip them instead of
starting from zero.

Format is append-only NDJSON, one record per completed unit, flushed as
each unit finishes. Append-only matters: a partially-written run is still
a readable state file, and an interrupted process never corrupts what it
already recorded. Records look like:

    {"host": "srv01", "share": "data"}

Granularity is deliberately (host, share), not per-file. Per-file
checkpointing would mean a write for every file examined -- huge state
files and constant fsync churn for very little gain. The trade-off: an
interrupted share restarts from its beginning, so a resumed run may
re-report findings from the share that was in flight when you stopped.
Completed shares are never rescanned.

Note that findings themselves are NOT replayed on resume: the state file
tracks progress, not results. Point --resume at the same output file (or
keep the previous one) if you want the full picture.
"""
from __future__ import annotations

import json
import logging
import threading
from pathlib import Path

log = logging.getLogger("snafflesnake.state")


class ScanState:
    """Tracks completed (host, share) units for --resume.

    Thread-safe: worker threads call mark_done() concurrently, so writes
    are serialized under a lock and flushed immediately.
    """

    def __init__(self, path: str, resume: bool = False):
        self.path = Path(path)
        self._done: set[tuple[str, str]] = set()
        self._lock = threading.Lock()
        self._fh = None

        if resume and self.path.exists():
            self._done = self._load(self.path)
            log.info("resume: %d completed unit(s) loaded from %s", len(self._done), self.path)

        # Append (never truncate) so a resumed run extends the same ledger.
        self._fh = self.path.open("a", encoding="utf-8")

    @staticmethod
    def _load(path: Path) -> set[tuple[str, str]]:
        done: set[tuple[str, str]] = set()
        try:
            with path.open("r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        # A torn final line from a hard kill: ignore it and
                        # keep every complete record before it.
                        log.debug("ignoring malformed state line: %r", line[:120])
                        continue
                    host, share = rec.get("host"), rec.get("share")
                    if host is not None and share is not None:
                        done.add((host.lower(), share.lower()))
        except OSError as e:
            log.warning("could not read state file %s: %s", path, e)
        return done

    def is_done(self, host: str, share: str) -> bool:
        return (host.lower(), share.lower()) in self._done

    def mark_done(self, host: str, share: str) -> None:
        key = (host.lower(), share.lower())
        with self._lock:
            if key in self._done:
                return
            self._done.add(key)
            if self._fh is None:
                return
            try:
                self._fh.write(json.dumps({"host": host, "share": share}) + "\n")
                self._fh.flush()
            except OSError as e:
                log.warning("could not write state file: %s", e)

    def completed_count(self) -> int:
        return len(self._done)

    def close(self) -> None:
        with self._lock:
            if self._fh is not None:
                try:
                    self._fh.close()
                except OSError:
                    pass
                self._fh = None

    def __enter__(self) -> "ScanState":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
