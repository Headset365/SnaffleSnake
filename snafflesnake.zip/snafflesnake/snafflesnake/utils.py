"""
snafflesnake.utils
~~~~~~~~~~~~~
Small, well-tested helper functions shared across the codebase (Appendix B
of the build plan). These have no dependencies on any other snafflesnake module
and are built/tested first because everything else relies on them.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Hash parsing (for pass-the-hash auth)
# ---------------------------------------------------------------------------

_HEX32_RE = re.compile(r"^[0-9a-fA-F]{32}$")


def parse_hash(h: str) -> tuple[str, str]:
    """Parse an NTLM hash string into (lmhash, nthash).

    Accepts:
      'LMHASH:NTHASH' -> (LMHASH, NTHASH)
      ':NTHASH'       -> ('', NTHASH)
      'NTHASH'        -> ('', NTHASH)   (bare NT hash, no colon)

    Each half, if present, must be exactly 32 hex characters. Raises
    ValueError on malformed input.
    """
    if not h:
        raise ValueError("empty hash string")

    if ":" in h:
        lm, _, nt = h.partition(":")
    else:
        lm, nt = "", h

    if lm and not _HEX32_RE.match(lm):
        raise ValueError(f"invalid LM hash (must be 32 hex chars): {lm!r}")
    if not nt or not _HEX32_RE.match(nt):
        raise ValueError(f"invalid NT hash (must be 32 hex chars): {nt!r}")

    return lm, nt


# ---------------------------------------------------------------------------
# Size parsing / formatting
# ---------------------------------------------------------------------------

_SIZE_SUFFIXES = {"": 1, "B": 1, "K": 1_000, "M": 1_000_000, "G": 1_000_000_000, "T": 1_000_000_000_000}
_SIZE_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([KMGT]?B?)\s*$", re.IGNORECASE)


def parse_size(s: str) -> int:
    """Parse a human size expression into an integer byte count.

    '10M' -> 10_000_000, '500K' -> 500_000, '2G' -> 2_000_000_000,
    '1048576' -> 1048576. Case-insensitive decimal (not binary/1024)
    suffixes, matching Snaffler's -l semantics. Plain integers are
    accepted as-is.
    """
    if isinstance(s, int):
        return s
    s = str(s).strip()
    m = _SIZE_RE.match(s)
    if not m:
        raise ValueError(f"invalid size expression: {s!r}")
    number, suffix = m.groups()
    suffix = suffix.upper().rstrip("B") or ""
    if suffix not in _SIZE_SUFFIXES:
        raise ValueError(f"unknown size suffix in: {s!r}")
    return int(float(number) * _SIZE_SUFFIXES[suffix])


_HUMAN_UNITS = ["B", "kB", "MB", "GB", "TB", "PB"]


def human_size(n: int) -> str:
    """Format a byte count the way Snaffler displays file sizes.

    Uses base-1024 stepping with B/kB/MB/GB/TB/PB labels, one decimal
    place once we're past whole bytes (e.g. 212992 -> '208kB',
    1_560_000 -> '1.5MB'). Values under 1024 are shown as a bare
    integer with a 'B' suffix.
    """
    if n < 0:
        raise ValueError("size cannot be negative")
    if n < 1024:
        return f"{n}B"
    size = float(n)
    unit_index = 0
    while size >= 1024 and unit_index < len(_HUMAN_UNITS) - 1:
        size /= 1024
        unit_index += 1
    # Snaffler-style: no decimal if it rounds to a whole number, else 1 decimal
    if abs(size - round(size)) < 0.05:
        return f"{round(size)}{_HUMAN_UNITS[unit_index]}"
    return f"{size:.1f}{_HUMAN_UNITS[unit_index]}"


# ---------------------------------------------------------------------------
# FILE_LENGTH rule comparator
# ---------------------------------------------------------------------------

_SIZE_EXPR_RE = re.compile(r"^\s*(>=|<=|==|!=|>|<)\s*(.+)\s*$")


def size_expr_match(n: int, expr: str) -> bool:
    """Evaluate a FILE_LENGTH rule expression against a byte count.

    expr examples: '>10000000', '<1024', '>=500', '==0', '!=0'.
    The right-hand side may itself use K/M/G suffixes (delegates to
    parse_size).
    """
    m = _SIZE_EXPR_RE.match(expr)
    if not m:
        raise ValueError(f"invalid size expression: {expr!r}")
    op, rhs = m.groups()
    threshold = parse_size(rhs)
    if op == ">":
        return n > threshold
    if op == "<":
        return n < threshold
    if op == ">=":
        return n >= threshold
    if op == "<=":
        return n <= threshold
    if op == "==":
        return n == threshold
    if op == "!=":
        return n != threshold
    raise ValueError(f"unhandled operator: {op!r}")  # pragma: no cover


# ---------------------------------------------------------------------------
# Time formatting
# ---------------------------------------------------------------------------


def to_snaffler_time(epoch: float | None) -> str:
    """Format an epoch-seconds timestamp as 'yyyy-MM-dd HH:mm:ssZ' in UTC.

    Returns '' for None (e.g. a created-time that wasn't available).
    """
    if epoch is None:
        return ""
    dt = datetime.fromtimestamp(epoch, tz=timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M:%SZ")


def now_snaffler_time() -> str:
    """Current UTC time in the same 'yyyy-MM-dd HH:mm:ssZ' format."""
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%SZ")


# ---------------------------------------------------------------------------
# Field escaping (one-line-per-finding safety) & context extraction
# ---------------------------------------------------------------------------

_ESCAPE_MAP = {
    "\r\n": "\\r\\n",
    "\r": "\\r",
    "\n": "\\n",
    "\t": "\\t",
}


def escape_field(s: str) -> str:
    """Escape CR/LF/TAB in a value so it stays on a single output line.

    Order matters: CRLF is escaped as a pair first so it doesn't get
    split into two separate escapes by the individual CR/LF rules.
    This is the exact escaping that SnafflerParser's "unescape" mode
    reverses, so keep the substitution set aligned with it.
    """
    if not s:
        return s
    out = s.replace("\r\n", _ESCAPE_MAP["\r\n"])
    out = out.replace("\r", _ESCAPE_MAP["\r"])
    out = out.replace("\n", _ESCAPE_MAP["\n"])
    out = out.replace("\t", _ESCAPE_MAP["\t"])
    return out


def extract_context(text: str, start: int, end: int, width: int) -> str:
    """Return a context window around text[start:end], padded by
    roughly width//2 characters on each side, with surrounding
    whitespace runs collapsed to single spaces for readability.
    """
    pad = max(width // 2, 0)
    lo = max(0, start - pad)
    hi = min(len(text), end + pad)
    snippet = text[lo:hi]
    snippet = re.sub(r"\s+", " ", snippet).strip()
    return snippet


# ---------------------------------------------------------------------------
# Misc path helpers
# ---------------------------------------------------------------------------


def split_extension(name: str) -> str:
    """Return the lowercased extension (with leading dot) of a filename,
    or '' if there is none. Matches Python's os.path.splitext semantics
    but always lowercases.
    """
    if "." not in name or name.startswith("."):
        # dotfiles with no further dot (e.g. ".npmrc") have no "extension"
        # in the conventional sense unless there's a second dot.
        idx = name.rfind(".")
        if idx <= 0:
            return ""
    idx = name.rfind(".")
    if idx == -1 or idx == 0:
        return ""
    return name[idx:].lower()


def to_unc(host: str, share: str | None, path: str | None) -> str:
    """Build a \\\\host\\share\\path UNC string from parts."""
    parts = [p for p in (share, path) if p]
    return "\\\\" + host + ("\\" + "\\".join(parts) if parts else "")
