"""
snafflesnake.report
~~~~~~~~~~~~~~
Render collected Findings into a single self-contained HTML file for
review: severity-colored, filterable by severity/type/host/share, full-text
searchable, with the matched keyword highlighted in each content snippet and
any recovered secret (e.g. a decrypted GPP cpassword) shown prominently.

No external assets, no network, no JS libraries -- one file you can open in
a browser or drop into a report appendix.
"""
from __future__ import annotations

import html
import json
from collections import Counter

from snafflesnake.models import Finding, Triage

_SEV_ORDER = [Triage.BLACK, Triage.RED, Triage.YELLOW, Triage.GREEN]
_SEV_NAME = {Triage.BLACK: "Black", Triage.RED: "Red", Triage.YELLOW: "Yellow", Triage.GREEN: "Green"}
_SEV_COLOR = {
    Triage.BLACK: "#111827",
    Triage.RED: "#b91c1c",
    Triage.YELLOW: "#b45309",
    Triage.GREEN: "#15803d",
}


def _finding_to_row(f: Finding) -> dict:
    return {
        "sev": _SEV_NAME.get(f.triage, "Green"),
        "type": f.task_type,
        "rule": f.rule_name,
        "host": f.host,
        "share": f.share,
        "unc": f.unc,
        "ext": f.extension,
        "size": f.size_human or (str(f.size) if f.size else ""),
        "modified": f.modified,
        "keyword": f.keyword,
        "content": f.content,
        "decrypted": f.decrypted,
        "account": f.account,
    }


def _highlight(content: str, keyword: str) -> str:
    """HTML-escape content and wrap the first occurrence of keyword in a
    <mark>. Keyword matching is case-insensitive and literal.
    """
    esc = html.escape(content)
    if not keyword:
        return esc
    esc_kw = html.escape(keyword)
    lower_esc = esc.lower()
    idx = lower_esc.find(esc_kw.lower())
    if idx == -1:
        return esc
    end = idx + len(esc_kw)
    return esc[:idx] + "<mark>" + esc[idx:end] + "</mark>" + esc[end:]


def build_html(findings: list[Finding], meta: dict | None = None) -> str:
    rows = [_finding_to_row(f) for f in findings]
    counts = Counter(r["sev"] for r in rows)
    hosts = sorted({r["host"] for r in rows if r["host"]})
    rules = sorted({r["rule"] for r in rows if r["rule"]})
    total = len(rows)

    meta = meta or {}
    generated = html.escape(str(meta.get("generated", "")))
    scan_targets = html.escape(str(meta.get("targets", "")))

    # Summary chips per severity.
    chips = []
    for sev in _SEV_ORDER:
        name = _SEV_NAME[sev]
        chips.append(
            f'<span class="chip chip-{name.lower()}">{name}: {counts.get(name, 0)}</span>'
        )
    chips_html = "".join(chips)

    host_opts = "".join(f'<option value="{html.escape(h)}">{html.escape(h)}</option>' for h in hosts)
    rule_opts = "".join(f'<option value="{html.escape(r)}">{html.escape(r)}</option>' for r in rules)

    # Table rows.
    tr_html = []
    for r in rows:
        sev = r["sev"]
        secret_html = ""
        if r["decrypted"]:
            acct = f'<span class="acct">{html.escape(r["account"])}</span> ' if r["account"] else ""
            secret_html = f'<div class="secret">🔑 {acct}<code>{html.escape(r["decrypted"])}</code></div>'
        content_html = _highlight(r["content"], r["keyword"]) if r["content"] else ""
        content_block = f'<div class="content">{content_html}</div>' if content_html else ""
        kw = html.escape(r["keyword"])
        tr_html.append(
            f'<tr class="row sev-{sev.lower()}" '
            f'data-sev="{sev}" data-type="{html.escape(r["type"])}" '
            f'data-host="{html.escape(r["host"])}" data-rule="{html.escape(r["rule"])}" '
            f'data-hasecret="{"1" if r["decrypted"] else "0"}">'
            f'<td class="c-sev"><span class="dot dot-{sev.lower()}"></span>{sev}</td>'
            f'<td class="c-rule">{html.escape(r["rule"])}</td>'
            f'<td class="c-unc"><span class="unc">{html.escape(r["unc"])}</span>{secret_html}{content_block}'
            f'<div class="kw">{("matched: " + kw) if kw else ""}</div></td>'
            f'<td class="c-size">{html.escape(r["size"])}</td>'
            f'<td class="c-mod">{html.escape(r["modified"])}</td>'
            f"</tr>"
        )
    rows_html = "\n".join(tr_html)

    data_json = html.escape(json.dumps({"total": total}), quote=True)

    return _TEMPLATE.format(
        generated=generated,
        targets=scan_targets,
        total=total,
        chips=chips_html,
        host_opts=host_opts,
        rule_opts=rule_opts,
        rows=rows_html,
        data_json=data_json,
    )


def write_html_report(path: str, findings: list[Finding], meta: dict | None = None) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(build_html(findings, meta))


_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>snafflesnake findings</title>
<style>
  :root {{
    --bg:#0f1115; --panel:#171a21; --edge:#262b36; --text:#e5e7eb; --muted:#9aa4b2;
    --black:#f9fafb; --red:#f87171; --yellow:#fbbf24; --green:#4ade80;
  }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--text);
         font:14px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; }}
  header {{ padding:18px 22px; border-bottom:1px solid var(--edge); background:var(--panel); position:sticky; top:0; z-index:5; }}
  h1 {{ margin:0 0 4px; font-size:18px; letter-spacing:.5px; }}
  .meta {{ color:var(--muted); font-size:12px; }}
  .chips {{ margin-top:10px; display:flex; gap:8px; flex-wrap:wrap; }}
  .chip {{ padding:3px 10px; border-radius:999px; font-size:12px; border:1px solid var(--edge); }}
  .chip-black {{ color:var(--black); border-color:#4b5563; }}
  .chip-red {{ color:var(--red); border-color:#7f1d1d; }}
  .chip-yellow {{ color:var(--yellow); border-color:#78350f; }}
  .chip-green {{ color:var(--green); border-color:#14532d; }}
  .controls {{ padding:12px 22px; display:flex; gap:10px; flex-wrap:wrap; align-items:center;
               border-bottom:1px solid var(--edge); background:var(--panel); position:sticky; top:83px; z-index:4; }}
  input,select {{ background:var(--bg); color:var(--text); border:1px solid var(--edge);
                  border-radius:6px; padding:6px 9px; font:inherit; }}
  input[type=search] {{ min-width:260px; flex:1; }}
  label.tog {{ color:var(--muted); font-size:12px; display:flex; gap:5px; align-items:center; }}
  table {{ width:100%; border-collapse:collapse; }}
  th,td {{ text-align:left; padding:9px 14px; vertical-align:top; border-bottom:1px solid var(--edge); }}
  th {{ position:sticky; top:135px; background:var(--panel); color:var(--muted); font-weight:600; font-size:12px; z-index:3; }}
  .c-sev {{ white-space:nowrap; width:90px; }}
  .c-size,.c-mod {{ white-space:nowrap; color:var(--muted); font-size:12px; }}
  .dot {{ display:inline-block; width:9px; height:9px; border-radius:2px; margin-right:7px; vertical-align:middle; }}
  .dot-black {{ background:var(--black); }} .dot-red {{ background:var(--red); }}
  .dot-yellow {{ background:var(--yellow); }} .dot-green {{ background:var(--green); }}
  .unc {{ color:#cbd5e1; word-break:break-all; }}
  .content {{ margin-top:5px; color:var(--muted); white-space:pre-wrap; word-break:break-word;
              max-height:8.5em; overflow:auto; border-left:2px solid var(--edge); padding-left:8px; }}
  mark {{ background:#fde047; color:#111; padding:0 2px; border-radius:2px; }}
  .kw {{ margin-top:4px; color:#64748b; font-size:11px; }}
  .secret {{ margin-top:5px; padding:5px 8px; background:#1e293b; border:1px solid #334155; border-radius:6px; }}
  .secret code {{ color:#fca5a5; font-weight:700; }}
  .acct {{ color:#93c5fd; }}
  .row.sev-black td.c-sev {{ color:var(--black); }}
  .row.sev-red td.c-sev {{ color:var(--red); }}
  .row.sev-yellow td.c-sev {{ color:var(--yellow); }}
  .row.sev-green td.c-sev {{ color:var(--green); }}
  .hidden {{ display:none; }}
  #empty {{ padding:40px; text-align:center; color:var(--muted); }}
  footer {{ padding:14px 22px; color:var(--muted); font-size:11px; border-top:1px solid var(--edge); }}
</style>
</head>
<body>
<header>
  <h1>snafflesnake findings</h1>
  <div class="meta">Targets: {targets} &nbsp;·&nbsp; Generated: {generated} &nbsp;·&nbsp; <span id="count">{total}</span> findings</div>
  <div class="chips">{chips}</div>
</header>
<div class="controls">
  <input type="search" id="q" placeholder="search UNC, rule, content, secret...">
  <select id="fsev"><option value="">all severities</option><option>Black</option><option>Red</option><option>Yellow</option><option>Green</option></select>
  <select id="ftype"><option value="">all types</option><option>File</option><option>Share</option><option>Dir</option></select>
  <select id="fhost"><option value="">all hosts</option>{host_opts}</select>
  <select id="frule"><option value="">all rules</option>{rule_opts}</select>
  <label class="tog"><input type="checkbox" id="fsecret"> secrets only</label>
</div>
<table>
  <thead><tr><th>Sev</th><th>Rule / Location</th><th>Size</th><th>Modified</th></tr></thead>
  <tbody id="tb">
{rows}
  </tbody>
</table>
<div id="empty" class="hidden">No findings match the current filters.</div>
<footer>snafflesnake — generated locally, no data left this machine. Data: {data_json}</footer>
<script>
  var rows = Array.prototype.slice.call(document.querySelectorAll('#tb .row'));
  var q = document.getElementById('q'), fsev = document.getElementById('fsev'),
      ftype = document.getElementById('ftype'), fhost = document.getElementById('fhost'),
      frule = document.getElementById('frule'), fsecret = document.getElementById('fsecret'),
      count = document.getElementById('count'), empty = document.getElementById('empty');
  function apply() {{
    var term = q.value.toLowerCase(), sev = fsev.value, typ = ftype.value,
        host = fhost.value, rule = frule.value, secret = fsecret.checked, shown = 0;
    rows.forEach(function(r) {{
      var ok = true;
      if (sev && r.dataset.sev !== sev) ok = false;
      if (typ && r.dataset.type !== typ) ok = false;
      if (host && r.dataset.host !== host) ok = false;
      if (rule && r.dataset.rule !== rule) ok = false;
      if (secret && r.dataset.hasecret !== '1') ok = false;
      if (ok && term) ok = r.textContent.toLowerCase().indexOf(term) !== -1;
      r.classList.toggle('hidden', !ok);
      if (ok) shown++;
    }});
    count.textContent = shown;
    empty.classList.toggle('hidden', shown !== 0);
  }}
  [q, fsev, ftype, fhost, frule, fsecret].forEach(function(el) {{
    el.addEventListener('input', apply); el.addEventListener('change', apply);
  }});
</script>
</body>
</html>
"""
