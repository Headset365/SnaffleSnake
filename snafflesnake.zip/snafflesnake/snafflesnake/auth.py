"""
snafflesnake.auth
~~~~~~~~~~~~
Connection factory: given a Config and a target host, return a live,
authenticated impacket SMBConnection. Supports password, pass-the-hash,
and Kerberos auth; works transparently under proxychains for pivots.

IMPORTANT: SMBConnection objects are NOT thread-safe. Callers must create
one connection per worker thread and never share a connection across
threads (see scheduler.py).
"""
from __future__ import annotations

from impacket.smbconnection import SMBConnection, SessionError

from snafflesnake.config import Config


class AuthError(Exception):
    """Raised on any login/connection failure. Messages are redacted --
    never include the password or NT hash.
    """


def connect(host: str, cfg: Config) -> SMBConnection:
    """Open and authenticate an SMB connection to `host` using whichever
    auth mode is configured. Exactly one of cfg.kerberos / cfg.nthash /
    cfg.password should be meaningfully set; cli.py validates this before
    we ever get here, but we still branch defensively.
    """
    try:
        conn = SMBConnection(remoteName=host, remoteHost=host, sess_port=cfg.port, timeout=cfg.timeout)
    except Exception as e:
        raise AuthError(f"{host}: could not establish SMB connection ({_redact(e)})") from e

    try:
        if cfg.kerberos:
            conn.kerberosLogin(
                cfg.username,
                cfg.password or "",
                cfg.domain,
                lmhash=cfg.lmhash,
                nthash=cfg.nthash,
                kdcHost=cfg.dc_ip,
                useCache=cfg.use_ccache,
            )
        elif cfg.nthash:
            # Pass-the-hash. lmhash may legitimately be "".
            conn.login(cfg.username, "", cfg.domain, lmhash=cfg.lmhash, nthash=cfg.nthash)
        else:
            conn.login(cfg.username, cfg.password or "", cfg.domain)
    except SessionError as e:
        raise AuthError(f"{host}: authentication failed ({_redact(e)})") from e
    except Exception as e:
        raise AuthError(f"{host}: unexpected error during authentication ({_redact(e)})") from e

    return conn


def _redact(e: Exception) -> str:
    """Return a string form of an exception with no secret material.
    impacket exceptions carry an NT status string (e.g.
    STATUS_LOGON_FAILURE / STATUS_ACCESS_DENIED) which is safe to show;
    we simply never interpolate cfg.password/cfg.nthash anywhere, so
    there's nothing to strip here beyond returning str(e) as-is.
    """
    return str(e)
