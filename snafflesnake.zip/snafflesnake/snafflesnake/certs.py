"""
snafflesnake.certs
~~~~~~~~~~~~~~~~~~
x509 inspection for rules with MatchAction CheckForKeys, mirroring
Snaffler's x509Match().

The point is triage: a `.pfx` on a share is only interesting if it carries
a *usable private key*. A public-only cert is noise. Snaffler therefore
parses the file, tries a list of well-known/tutorial passwords when it's
encrypted, and reports why it's interesting -- HasPrivateKey,
NoPasswordRequired, PasswordCracked, the subject, expiry, and whether it's
a CA cert (a CA key is a domain-compromise-grade finding).

Implemented with `cryptography`, which handles PKCS#12 (.pfx/.p12), PEM and
DER without shelling out.
"""
from __future__ import annotations

import datetime as dt
import logging

log = logging.getLogger("snafflesnake.certs")

# Snaffler's CertPasswords list, ported verbatim -- these come from public
# tutorials/documentation and are exactly the ones people leave in place.
DEFAULT_CERT_PASSWORDS: list[str] = [
    "",
    "password",
    "mimikatz",
    "1234",
    "abcd",
    "secret",
    "MyPassword",
    "myPassword",
    "MyClearTextPassword",
    "ThePasswordToKeyonPFXFile",
    "P@ssw0rd",
    "testpassword",
    "@OurPassword1",
    "@de08nt2128",
    "changeme",
    "changeit",
    "SolarWinds.R0cks",
]

_PKCS12_EXTS = {".pfx", ".p12"}


def _load_pkcs12(data: bytes, password: bytes | None):
    from cryptography.hazmat.primitives.serialization import pkcs12

    return pkcs12.load_key_and_certificates(data, password)


def _load_plain_cert(data: bytes):
    """Try PEM then DER. Returns (private_key_or_None, cert_or_None)."""
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization

    cert = None
    try:
        cert = x509.load_pem_x509_certificate(data)
    except Exception:  # noqa: BLE001
        try:
            cert = x509.load_der_x509_certificate(data)
        except Exception:  # noqa: BLE001
            cert = None

    key = None
    try:
        key = serialization.load_pem_private_key(data, password=None)
    except Exception:  # noqa: BLE001
        key = None

    return key, cert


def _describe(cert, reasons: list[str]) -> None:
    """Append subject/expiry/issuer/CA/usage detail for a parsed cert."""
    from cryptography import x509
    from cryptography.x509.oid import ExtensionOID

    try:
        reasons.append(f"Subject:{cert.subject.rfc4514_string()}")
    except Exception:  # noqa: BLE001
        pass

    try:
        bc = cert.extensions.get_extension_for_oid(ExtensionOID.BASIC_CONSTRAINTS).value
        if bc.ca:
            reasons.append("IsCACert")
    except x509.ExtensionNotFound:
        pass
    except Exception:  # noqa: BLE001
        pass

    try:
        eku = cert.extensions.get_extension_for_oid(ExtensionOID.EXTENDED_KEY_USAGE).value
        names = [getattr(o, "_name", None) or o.dotted_string for o in eku]
        if names:
            reasons.append("EKU:" + "|".join(names))
    except x509.ExtensionNotFound:
        pass
    except Exception:  # noqa: BLE001
        pass

    try:
        san = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME).value
        dns = san.get_values_for_type(x509.DNSName)
        if dns:
            reasons.append("SAN:" + "|".join(dns[:10]))
    except x509.ExtensionNotFound:
        pass
    except Exception:  # noqa: BLE001
        pass

    try:
        expiry = cert.not_valid_after_utc
    except AttributeError:  # cryptography < 42
        expiry = cert.not_valid_after.replace(tzinfo=dt.timezone.utc)
    except Exception:  # noqa: BLE001
        expiry = None
    if expiry is not None:
        reasons.append("Expiry:" + expiry.strftime("%Y-%m-%d"))
        if expiry < dt.datetime.now(dt.timezone.utc):
            reasons.append("Expired")

    try:
        reasons.append(f"Issuer:{cert.issuer.rfc4514_string()}")
    except Exception:  # noqa: BLE001
        pass


def inspect_cert(
    data: bytes, filename: str = "", extension: str = "", passwords: list[str] | None = None
) -> list[str]:
    """Parse a certificate/keystore and return Snaffler-style match reasons.

    Returns [] if nothing could be parsed at all. A non-empty result always
    explains WHY the file is interesting, e.g.:
        ["HasPrivateKey", "NoPasswordRequired", "Subject:CN=web01", ...]
        ["HasPrivateKey", "PasswordCracked:changeit", ...]
        ["HasPassword", "LookNearbyForTxtFiles"]
    """
    try:
        import cryptography  # noqa: F401
    except ImportError:  # pragma: no cover
        log.warning("cryptography not installed -- skipping x509 inspection")
        return []

    reasons: list[str] = []
    key = cert = None
    no_password_required = False

    ext = (extension or "").lower()
    pw_list = DEFAULT_CERT_PASSWORDS if passwords is None else passwords

    if ext in _PKCS12_EXTS or _looks_like_pkcs12(data):
        try:
            key, cert, _ = _load_pkcs12(data, None)
            no_password_required = True
        except Exception:  # noqa: BLE001 -- almost always "needs a password"
            # Try the well-known passwords, plus the filename stem (Snaffler
            # does the same -- people name the file after its password).
            candidates = list(pw_list)
            stem = filename.rsplit(".", 1)[0] if filename else ""
            if stem and stem not in candidates:
                candidates.append(stem)

            for pw in candidates:
                try:
                    key, cert, _ = _load_pkcs12(data, pw.encode() if pw else None)
                except Exception:  # noqa: BLE001
                    continue
                reasons.append("PasswordBlank" if pw == "" else f"PasswordCracked:{pw}")
                break

            if not reasons:
                if not _looks_like_pkcs12(data):
                    # Not parseable AND not even DER-shaped: this isn't an
                    # encrypted keystore, it's junk (or an unsupported
                    # format). Claiming "HasPassword" here would be a
                    # confident lie about a file we failed to understand.
                    return []
                reasons.append("HasPassword")
                reasons.append("LookNearbyForTxtFiles")
                return reasons
    else:
        key, cert = _load_plain_cert(data)
        if key is not None:
            no_password_required = True

    if key is None and cert is None:
        return []

    if key is not None:
        reasons.insert(0, "HasPrivateKey")
        if no_password_required:
            reasons.append("NoPasswordRequired")
    else:
        # Public cert only: real, but far less interesting. Say so plainly
        # rather than implying we found a key.
        reasons.append("PublicCertOnly")

    if cert is not None:
        _describe(cert, reasons)

    return reasons


def _looks_like_pkcs12(data: bytes) -> bool:
    """PKCS#12 is DER: a SEQUENCE (0x30) and definitely not PEM text."""
    return data[:1] == b"\x30" and b"-----BEGIN" not in data[:200]
