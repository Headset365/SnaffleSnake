"""
snafflesnake.content
~~~~~~~~~~~~~~~
Downloads a file's bytes (capped by size) and runs the rule engine's
content-scope rules over it, producing Findings for each hit.
"""
from __future__ import annotations

import io

from snafflesnake import gpp
from snafflesnake.config import Config
from snafflesnake.models import Finding, Target, Triage
from snafflesnake.rules.engine import RuleEngine
from snafflesnake.utils import human_size, now_snaffler_time, to_snaffler_time


def scan_file(
    conn,
    share: str,
    path: str,
    size: int,
    target: Target,
    engine: RuleEngine,
    cfg: Config,
    rule_names: list[str] | None = None,
) -> list[Finding]:
    """Download `path` within `share` (if under cfg.max_file_size) and
    return content-rule Findings. If rule_names is given (from a relay's
    targets), only those content rules run; otherwise all contents-scope
    rules do. Returns [] for oversized or binary files.
    """
    if size > cfg.max_file_size:
        return []

    buf = io.BytesIO()
    smb_path = path.replace("\\", "/")
    conn.getFile(share, smb_path, buf.write)
    data = buf.getvalue()

    if _looks_binary(data):
        return []

    findings = engine.scan_content(data, target, rule_names=rule_names)

    # --- GPP cpassword recovery --------------------------------------
    # If this file carried any cpassword values, replace the raw content
    # hits with decrypted-password findings so the plaintext shows up
    # directly in the output.
    text = _decode(data)
    if text is not None and "cpassword" in text.lower():
        gpp_findings = _gpp_findings(text, target)
        if gpp_findings:
            findings = [f for f in findings if f.rule_name != "KeepGppCpassword"]
            findings.extend(gpp_findings)

    # Fill in metadata the engine's generic content-finding builder
    # doesn't have (size formatting / timestamps come from the enumerator
    # pass, not from RuleEngine, so backfill them here for consistency).
    modified = to_snaffler_time(target.mtime)
    created = to_snaffler_time(target.ctime)
    size_human = human_size(size)
    log_time = now_snaffler_time()
    for f in findings:
        f.size_human = size_human
        f.modified = modified
        f.created = created
        if not f.log_time:
            f.log_time = log_time

    return findings


def _gpp_findings(text: str, target: Target) -> list[Finding]:
    out: list[Finding] = []
    for secret in gpp.extract_gpp_secrets(text):
        if secret.password:
            content = f"cpassword recovered -> {secret.password}"
            if secret.account:
                content = f"account='{secret.account}' password='{secret.password}'"
        else:
            content = f"cpassword found but not decrypted ({secret.error})"
        out.append(
            Finding(
                triage=Triage.BLACK,
                rule_name="GppDecryptedPassword",
                task_type="File",
                host=target.host,
                share=target.share or "",
                full_path=target.path or "",
                unc=target.unc,
                extension=target.extension or "",
                size=target.size or 0,
                keyword="cpassword",
                content=content,
                decrypted=secret.password,
                account=secret.account,
                log_time=now_snaffler_time(),
            )
        )
    return out


def _decode(data: bytes) -> str | None:
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return None


def _looks_binary(data: bytes, sample_size: int = 4096) -> bool:
    """Cheap binary heuristic. A text BOM means it's text; otherwise a NUL
    byte in the first chunk almost always means this isn't text we should
    be running regexes over.
    """
    sample = data[:sample_size]
    if sample.startswith((b"\xff\xfe", b"\xfe\xff", b"\xef\xbb\xbf")):
        return False  # UTF-16/UTF-8 BOM -> treat as text
    return b"\x00" in sample
