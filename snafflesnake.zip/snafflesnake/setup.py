from setuptools import find_packages, setup

setup(
    name="snafflesnake",
    version="0.1.0",
    description="A Python/Linux port of Snaffler's core workflow for authorized SMB share/file triage.",
    packages=find_packages(exclude=["tests", "tests.*"]),
    package_data={"snafflesnake.rules": ["*.yaml"]},
    include_package_data=True,
    python_requires=">=3.10",
    install_requires=[
        "impacket>=0.11.0",
        "rich>=13.0",
        "PyYAML>=6.0",
        "pycryptodomex>=3.19",
    ],
    entry_points={
        "console_scripts": [
            "snafflesnake=snafflesnake.cli:main",
        ],
    },
)
