"""
snaffpy.cli
~~~~~~~~~~~
argparse surface and orchestration entry point. This is the ONLY place
that constructs a Config -- every other module receives it read-only.
"""
from __future__ import annotations

import argparse
import logging
import sys

from snaffpy.config import Config
from snaffpy.output import OutputSink
from snaffpy.rules.engine import RuleEngine, RuleLoadError
from snaffpy.scheduler import run as scheduler_run
from snaffpy.utils import parse_hash, parse_size


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="snaffpy",
        description="A Python/Linux Snaffler port: authenticated SMB share/file enumeration "
        "with a rules-based sensitive-file triage classifier. For authorized "
        "penetration testing and red team engagements only.",
    )

    p.add_argument("targets", nargs="*", help="Hosts/IPs to enumerate (in addition to --targets-file)")
    p.add_argument("--targets-file", help="Path to a file of hosts, one per line")

    auth_group = p.add_argument_group("Authentication")
    auth_group.add_argument("-u", "--username", required=True, help="Username")
    auth_group.add_argument("-p", "--password", help="Password")
    auth_group.add_argument("-H", "--hash", help="NTLM hash: LMHASH:NTHASH, :NTHASH, or bare NTHASH")
    auth_group.add_argument("-d", "--domain", default="", help="Domain (or '.' for local accounts)")
    auth_group.add_argument("-k", "--kerberos", action="store_true", help="Use Kerberos authentication")
    auth_group.add_argument("--use-ccache", action="store_true", help="Use ticket from $KRB5CCNAME (implies -k)")
    auth_group.add_argument("--dc-ip", help="Domain controller IP (for Kerberos)")

    enum_group = p.add_argument_group("Enumeration")
    enum_group.add_argument("--threads", type=int, default=10, help="Max concurrent host connections (default: 10; "
                             "use 2-4 under proxychains)")
    enum_group.add_argument("--max-depth", type=int, default=30, help="Max directory recursion depth (default: 30)")
    enum_group.add_argument("--max-file-size", default="10M",
                             help="Max file size to content-scan, e.g. 10M, 500K (default: 10M)")
    enum_group.add_argument("--port", type=int, default=445, help="SMB port (default: 445)")
    enum_group.add_argument("--timeout", type=int, default=15, help="Per-operation SMB timeout in seconds (default: 15)")
    enum_group.add_argument("--include-admin", action="store_true",
                             help="Include ADMIN$/C$-style administrative shares")
    enum_group.add_argument("--shares", help="Comma-separated list of share names to restrict to")
    enum_group.add_argument("--exclude-shares", help="Comma-separated list of share names to exclude")

    rules_group = p.add_argument_group("Rules")
    rules_group.add_argument("--rules", action="append", default=[],
                              help="Path to a YAML rules file (repeatable; merged, later overrides earlier by name)")
    rules_group.add_argument("--no-default-rules", action="store_true", help="Don't load the built-in default rules")

    out_group = p.add_argument_group("Output (mirrors Snaffler's switches)")
    out_group.add_argument("-o", "--outfile", help="Write results to this file")
    out_group.add_argument("-s", "--stdout", dest="to_console", action="store_true", default=True,
                            help="Also stream results to console (default: on)")
    out_group.add_argument("--no-stdout", dest="to_console", action="store_false", help="Suppress console output")
    out_group.add_argument("-t", "--type", dest="out_format", choices=["plain", "tsv", "json"], default="plain",
                            help="Output format (default: plain)")
    out_group.add_argument("-y", "--tsv", action="store_true", help="Alias for --type tsv")
    out_group.add_argument("--separator", type=int, default=9, help="TSV field separator byte value (default: 9 = TAB)")
    out_group.add_argument("--tsv-legacy", action="store_true", help="Emit 13-column TSV instead of 14-column")
    out_group.add_argument("--html", dest="html_file", metavar="FILE",
                           help="Write a self-contained, filterable HTML report to FILE")
    out_group.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")
    out_group.add_argument("--no-color", action="store_true", help="Disable colored console output")

    return p


def _resolve_targets(args: argparse.Namespace) -> list[str]:
    targets = list(args.targets)
    if args.targets_file:
        try:
            with open(args.targets_file, "r", encoding="utf-8") as fh:
                targets.extend(line.strip() for line in fh if line.strip())
        except OSError as e:
            raise SystemExit(f"snaffpy: could not read --targets-file: {e}")
    # de-duplicate while preserving order
    seen: set[str] = set()
    ordered = []
    for t in targets:
        if t not in seen:
            seen.add(t)
            ordered.append(t)
    return ordered


def _build_config(args: argparse.Namespace) -> Config:
    hosts = _resolve_targets(args)
    if not hosts:
        raise SystemExit("snaffpy: no targets specified (positional hosts or --targets-file required)")

    auth_modes_set = sum([bool(args.kerberos or args.use_ccache), bool(args.hash), bool(args.password)])
    if auth_modes_set == 0:
        raise SystemExit("snaffpy: one of --password, --hash, or --kerberos/--use-ccache is required")
    if auth_modes_set > 1:
        raise SystemExit("snaffpy: specify exactly one of --password, --hash, or --kerberos/--use-ccache")

    lmhash, nthash = "", ""
    if args.hash:
        try:
            lmhash, nthash = parse_hash(args.hash)
        except ValueError as e:
            raise SystemExit(f"snaffpy: {e}")

    try:
        max_file_size = parse_size(args.max_file_size)
    except ValueError as e:
        raise SystemExit(f"snaffpy: {e}")

    out_format = "tsv" if args.tsv else args.out_format

    shares_include = [s.strip() for s in args.shares.split(",")] if args.shares else []
    shares_exclude = [s.strip() for s in args.exclude_shares.split(",")] if args.exclude_shares else []

    cfg = Config(
        hosts=hosts,
        username=args.username,
        password=args.password,
        lmhash=lmhash,
        nthash=nthash,
        domain=args.domain,
        kerberos=bool(args.kerberos or args.use_ccache),
        use_ccache=args.use_ccache,
        dc_ip=args.dc_ip,
        port=args.port,
        timeout=args.timeout,
        threads=args.threads,
        max_depth=args.max_depth,
        max_file_size=max_file_size,
        include_admin=args.include_admin,
        shares_include=shares_include,
        shares_exclude=shares_exclude,
        rule_paths=args.rules,
        use_default_rules=not args.no_default_rules,
        out_format=out_format,
        out_file=args.outfile,
        html_file=args.html_file,
        to_console=args.to_console,
        tsv_separator=args.separator,
        tsv_legacy=args.tsv_legacy,
        color=not args.no_color,
        verbose=args.verbose,
    )

    return cfg


def main(argv: list[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    cfg = _build_config(args)

    logging.basicConfig(
        level=logging.DEBUG if cfg.verbose else logging.WARNING,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    try:
        engine = RuleEngine(rule_paths=cfg.rule_paths, use_default_rules=cfg.use_default_rules)
    except RuleLoadError as e:
        print(f"snaffpy: {e}", file=sys.stderr)
        return 1

    # Note: --include-admin is honored in the enumerator (it walks C$/ADMIN$
    # shares that are otherwise reported-but-not-walked). No rule needs to be
    # dropped, since Snaffler's default rules report dollar shares rather than
    # discarding them.

    sink = OutputSink(cfg)

    try:
        scheduler_run(cfg, engine, sink)
    except KeyboardInterrupt:
        print("\nsnaffpy: interrupted", file=sys.stderr)
        return 130

    return 0


if __name__ == "__main__":
    sys.exit(main())
