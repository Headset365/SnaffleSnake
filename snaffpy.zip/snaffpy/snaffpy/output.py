"""
snaffpy.output
~~~~~~~~~~~~~~
Writes Findings in Snaffler-compatible formats so existing ingestors
(SnafflerParser, Efflanrs, Parsler, snaffler-ng's importers, ...) can
consume snaffpy's output without modification. See build plan Phase 7 /
Appendix C for the exact field layout this targets.

Three formats:
  plain -- human-readable single-line-per-finding (default)
  tsv   -- delimiter-separated, 13 or 14 columns (--tsv-legacy for 13)
  json  -- NDJSON (one JSON object per line), NOT a JSON array
"""
from __future__ import annotations

import json
import sys
import threading
from collections import Counter

from snaffpy.config import Config
from snaffpy.models import Finding, Triage
from snaffpy.utils import escape_field, now_snaffler_time

# rich is optional at import time so a broken terminal/env can't crash
# output entirely -- but it's a declared dependency, so this should
# always succeed in a properly installed environment.
try:
    from rich.console import Console
    from rich.table import Table
except ImportError:  # pragma: no cover
    Console = None  # type: ignore
    Table = None  # type: ignore

_SEVERITY_STYLE = {
    Triage.BLACK: "bold white on grey15",
    Triage.RED: "bold red",
    Triage.YELLOW: "bold yellow",
    Triage.GREEN: "bold green",
}

_TRIAGE_SORT_ORDER = [Triage.BLACK, Triage.RED, Triage.YELLOW, Triage.GREEN]


class OutputSink:
    """Thread-safety note: this object is only ever written to from the
    single writer thread in scheduler.py, so no internal locking is
    needed for `write()` itself. A lock still guards the summary counters
    in case of future multi-writer use.
    """

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._lock = threading.Lock()
        self._counts: Counter[Triage] = Counter()
        self._all_findings: list[Finding] = []  # for the end-of-run summary table only

        self._file_handle = None
        if cfg.out_file:
            self._file_handle = open(cfg.out_file, "w", encoding="utf-8", newline="")

        self._console = Console(no_color=not cfg.color) if Console else None

    # -- public API ---------------------------------------------------------

    def write(self, finding: Finding) -> None:
        if not finding.log_time:
            finding.log_time = now_snaffler_time()

        with self._lock:
            self._counts[finding.triage] += 1
            self._all_findings.append(finding)

        line = self._format_line(finding)

        if self._file_handle:
            self._file_handle.write(line + "\n")

        if self.cfg.to_console:
            self._write_console(finding, line)

    def flush(self) -> None:
        if self._file_handle:
            self._file_handle.flush()
            self._file_handle.close()
            self._file_handle = None
        if self.cfg.html_file:
            self._write_html_report()
        self._print_summary()

    def _write_html_report(self) -> None:
        from snaffpy.report import write_html_report

        meta = {
            "generated": now_snaffler_time(),
            "targets": ", ".join(self.cfg.hosts) if getattr(self.cfg, "hosts", None) else "",
        }
        try:
            write_html_report(self.cfg.html_file, self._all_findings, meta)
            if self._console:
                self._console.print(f"[dim]HTML report written to {self.cfg.html_file}[/dim]")
        except OSError as e:
            if self._console:
                self._console.print(f"[red]failed to write HTML report: {e}[/red]")

    # -- format dispatch ------------------------------------------------

    def _format_line(self, f: Finding) -> str:
        if self.cfg.out_format == "tsv":
            return self._format_tsv(f)
        if self.cfg.out_format == "json":
            return self._format_json(f)
        return self._format_plain(f)

    def _format_plain(self, f: Finding) -> str:
        content = escape_field(f.content)
        if f.task_type == "Share":
            return f"[{f.log_time}] [Share] {{{f.triage}}}({f.unc})"
        inner = f"{f.rule_name}|{f.permissions}|{escape_field(f.keyword)}|{f.size_human}|{f.modified}"
        line = f"[{f.log_time}] [{f.task_type}] {{{f.triage}}}<{inner}>({f.unc})"
        if content:
            line += f" {content}"
        return line

    def _format_tsv(self, f: Finding) -> str:
        sep = chr(self.cfg.tsv_separator)
        fields = [
            f.log_time,
            f.task_type,
            str(f.triage),
            f.rule_name,
            f.permissions,
            escape_field(f.keyword),
            str(f.size),
            f.size_human,
            f.modified,
            f.created,
            f.unc,
            f.extension,
        ]
        if not self.cfg.tsv_legacy:
            fields.append(f.original_filename)  # 14-column layout
        fields.append(escape_field(f.content))
        return sep.join(fields)

    def _format_json(self, f: Finding) -> str:
        obj = {
            "level": "warn" if f.triage in (Triage.BLACK, Triage.RED) else "info",
            "time": f.log_time,
            "message": {
                "type": f.task_type,
                "severity": str(f.triage),
                "ruleName": f.rule_name,
                "permissions": f.permissions,
                "matchContext": f.keyword,
                "fileSize": f.size,
                "fileSizeHuman": f.size_human,
                "modified": f.modified,
                "created": f.created,
                "unc": f.unc,
                "extension": f.extension,
                "originalFilename": f.original_filename,
                "content": f.content,
            },
        }
        return json.dumps(obj, ensure_ascii=False)

    # -- console rendering ------------------------------------------------

    def _write_console(self, f: Finding, plain_line: str) -> None:
        if self._console is None:
            print(plain_line)
            return
        style = _SEVERITY_STYLE.get(f.triage, "")
        # Only colorize the severity-bearing prefix; keep the rest of the
        # line un-styled so paths/content stay copy-pasteable.
        if self.cfg.out_format in ("tsv", "json"):
            self._console.print(plain_line, markup=False, highlight=False)
        else:
            severity_tag = f"{{{f.triage}}}"
            colored = plain_line.replace(severity_tag, f"[{style}]{severity_tag}[/{style}]", 1)
            self._console.print(colored, markup=True, highlight=False)

    # -- summary ----------------------------------------------------------

    def _print_summary(self) -> None:
        if not self.cfg.to_console:
            return
        total = sum(self._counts.values())
        if total == 0:
            return

        if self._console:
            self._console.print()
            self._console.rule("snaffpy run summary")
            if Table:
                table = Table(show_header=True, header_style="bold")
                table.add_column("Severity")
                table.add_column("Count", justify="right")
                for triage in _TRIAGE_SORT_ORDER:
                    count = self._counts.get(triage, 0)
                    if count:
                        table.add_row(f"[{_SEVERITY_STYLE[triage]}]{triage}[/{_SEVERITY_STYLE[triage]}]", str(count))
                self._console.print(table)
            else:
                for triage in _TRIAGE_SORT_ORDER:
                    count = self._counts.get(triage, 0)
                    if count:
                        self._console.print(f"{triage}: {count}")
        else:
            print("\n--- snaffpy run summary ---", file=sys.stderr)
            for triage in _TRIAGE_SORT_ORDER:
                count = self._counts.get(triage, 0)
                if count:
                    print(f"{triage}: {count}", file=sys.stderr)
