"""
snaffpy.config
~~~~~~~~~~~~~~
The single Config object threaded through the whole application. cli.py is
the only place that constructs one; every other module receives it read-only.
"""
from __future__ import annotations

from dataclasses import dataclass, field

DEFAULT_GREPABLE_EXTS = {
    ".txt", ".config", ".cnf", ".conf", ".ini", ".yml", ".yaml", ".xml",
    ".json", ".env", ".ps1", ".bat", ".cmd", ".vbs", ".sh", ".sql", ".php",
    ".asp", ".aspx", ".jsp", ".properties", ".pem", ".key",
}


@dataclass
class Config:
    # --- targets ---
    hosts: list[str] = field(default_factory=list)

    # --- auth (exactly one of password / nthash / kerberos should be set) ---
    username: str = ""
    password: str | None = None
    lmhash: str = ""
    nthash: str = ""
    domain: str = ""
    kerberos: bool = False
    use_ccache: bool = False
    dc_ip: str | None = None

    # --- SMB connection ---
    port: int = 445
    timeout: int = 15

    # --- enumeration ---
    threads: int = 10
    max_depth: int = 30
    max_file_size: int = 10_000_000
    include_admin: bool = False
    shares_include: list[str] = field(default_factory=list)
    shares_exclude: list[str] = field(default_factory=list)
    grepable_exts: set[str] = field(default_factory=lambda: set(DEFAULT_GREPABLE_EXTS))

    # --- rules ---
    rule_paths: list[str] = field(default_factory=list)
    use_default_rules: bool = True

    # --- output ---
    out_format: str = "plain"  # "plain" | "tsv" | "json"
    out_file: str | None = None
    html_file: str | None = None  # write a self-contained HTML report here
    to_console: bool = True
    tsv_separator: int = 9  # TAB
    tsv_legacy: bool = False
    color: bool = True
    verbose: bool = False
