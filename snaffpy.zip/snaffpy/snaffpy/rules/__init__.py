"""snaffpy.rules -- the classification engine and default rule set."""
