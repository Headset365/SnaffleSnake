"""
snaffpy.models
~~~~~~~~~~~~~~
All enums and dataclasses used across snaffpy. This is the contract that
every other module builds on -- keep it stable and change it deliberately.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum

from snaffpy.utils import to_unc


class Triage(IntEnum):
    """Snaffler's severity taxonomy, ordered so comparisons work
    (Triage.BLACK > Triage.GREEN is True). Higher = more interesting.
    """

    GREEN = 1
    YELLOW = 2
    RED = 3
    BLACK = 4

    @classmethod
    def from_str(cls, s: str) -> "Triage":
        return cls[s.strip().upper()]

    def __str__(self) -> str:  # pretty name for output, e.g. "Red"
        return self.name.capitalize()


class EnumScope(Enum):
    """Which pass of the enumeration a rule applies to."""

    SHARE = "share"
    DIRECTORY = "directory"
    FILE = "file"
    CONTENTS = "contents"
    POSTMATCH = "postmatch"  # discard filters applied after a Snaffle match

    @classmethod
    def from_str(cls, s: str) -> "EnumScope":
        return cls(s.strip().lower())


class MatchLocation(Enum):
    SHARE_NAME = "share_name"
    FILE_PATH = "file_path"
    FILE_NAME = "file_name"
    FILE_EXTENSION = "file_extension"
    FILE_CONTENT = "file_content"
    FILE_LENGTH = "file_length"
    FILE_MD5 = "file_md5"  # accepted for compatibility; not matched in v1

    @classmethod
    def from_str(cls, s: str) -> "MatchLocation":
        return cls(s.strip().lower())


class WordListType(Enum):
    EXACT = "exact"
    CONTAINS = "contains"
    STARTSWITH = "startswith"
    ENDSWITH = "endswith"
    REGEX = "regex"

    @classmethod
    def from_str(cls, s: str) -> "WordListType":
        return cls(s.strip().lower())


class MatchAction(Enum):
    SNAFFLE = "snaffle"  # report it
    DISCARD = "discard"  # explicitly ignore (prunes share/dir/file)
    RELAY = "relay"  # bounce to named relay_targets (real chaining)
    CHECK_CONTENTS = "check_contents"  # snaffpy convenience: grep with all contents rules
    CHECK_FOR_KEYS = "check_for_keys"  # Snaffler's x509 dance; v1 reports the file
    SEND_TO_NEXT_SCOPE = "send_to_next_scope"  # pass downstream; v1 reports the file

    @classmethod
    def from_str(cls, s: str) -> "MatchAction":
        return cls(s.strip().lower())


@dataclass
class Rule:
    """A single classification rule loaded from YAML."""

    name: str
    enum_scope: EnumScope
    match_location: MatchLocation
    wordlist_type: WordListType
    wordlist: list[str]
    triage: Triage
    match_action: MatchAction = MatchAction.SNAFFLE
    match_length: int = 200  # context chars to show around a content hit
    description: str = ""
    relay_targets: list[str] = field(default_factory=list)  # for Relay rules
    # Compiled regex objects, populated by RuleEngine._load() for EVERY
    # wordlist type (Snaffler compiles all types to anchored regexes).
    compiled: list = field(default_factory=list, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d: dict) -> "Rule":
        return cls(
            name=d["name"],
            enum_scope=EnumScope.from_str(d["enum_scope"]),
            match_location=MatchLocation.from_str(d["match_location"]),
            wordlist_type=WordListType.from_str(d["wordlist_type"]),
            wordlist=list(d["wordlist"]),
            triage=Triage.from_str(d["triage"]) if isinstance(d["triage"], str) else Triage(d["triage"]),
            match_action=MatchAction.from_str(d.get("match_action", "snaffle")),
            match_length=int(d.get("match_length", 200)),
            description=d.get("description", ""),
            relay_targets=list(d.get("relay_targets", [])),
        )


@dataclass
class Target:
    """A generic thing being classified: a share, a directory, or a file."""

    host: str
    share: str | None = None
    path: str | None = None  # path within share, backslash-separated
    name: str | None = None  # leaf name, e.g. "file.txt"
    extension: str | None = None  # lowercased, with dot, "" if none
    size: int | None = None  # bytes
    is_dir: bool = False
    mtime: float | None = None  # epoch seconds
    ctime: float | None = None  # epoch seconds

    @property
    def unc(self) -> str:
        return to_unc(self.host, self.share, self.path)


@dataclass
class Finding:
    """A reportable result: a matched share or file. Every field here
    exists because some output format (plain/tsv/json) needs it -- see
    Phase 7 of the build plan for the mapping.
    """

    # --- classification ---
    triage: Triage
    rule_name: str
    task_type: str = "File"  # "File" | "Share" | "Dir"
    # --- location ---
    host: str = ""
    share: str = ""
    full_path: str = ""  # path within share (backslash-separated)
    unc: str = ""  # full \\host\share\path
    extension: str = ""  # lowercased, with dot
    # --- file metadata ---
    size: int = 0
    size_human: str = ""
    modified: str = ""  # "yyyy-MM-dd HH:mm:ssZ"
    created: str = ""
    permissions: str = "R"  # always "R" in v1 (see enumerator notes)
    original_filename: str = ""  # 14-col TSV field
    # --- match evidence ---
    keyword: str = ""  # exact string/regex/extension that fired
    content: str = ""  # context snippet ("" for name/ext-only matches)
    # --- decrypted secret (GPP cpassword, etc.) ---
    decrypted: str = ""  # recovered plaintext secret, if any
    account: str = ""  # associated account/username for the secret, if known
    # --- log event ---
    log_time: str = ""  # when this finding was logged (UTC, "now")
