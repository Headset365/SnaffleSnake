import pytest

from snaffpy.utils import (
    escape_field,
    extract_context,
    human_size,
    now_snaffler_time,
    parse_hash,
    parse_size,
    size_expr_match,
    split_extension,
    to_snaffler_time,
    to_unc,
)


class TestParseHash:
    def test_full_lm_nt(self):
        assert parse_hash("aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0") == (
            "aad3b435b51404eeaad3b435b51404ee",
            "31d6cfe0d16ae931b73c59d7e0c089c0",
        )

    def test_bare_nt_with_colon(self):
        lm, nt = parse_hash(":31d6cfe0d16ae931b73c59d7e0c089c0")
        assert lm == ""
        assert nt == "31d6cfe0d16ae931b73c59d7e0c089c0"

    def test_bare_nt_no_colon(self):
        lm, nt = parse_hash("31d6cfe0d16ae931b73c59d7e0c089c0")
        assert lm == ""
        assert nt == "31d6cfe0d16ae931b73c59d7e0c089c0"

    def test_invalid_length_raises(self):
        with pytest.raises(ValueError):
            parse_hash("deadbeef")

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            parse_hash("")


class TestParseSize:
    @pytest.mark.parametrize(
        "expr,expected",
        [
            ("10M", 10_000_000),
            ("500K", 500_000),
            ("2G", 2_000_000_000),
            ("1048576", 1048576),
            ("10m", 10_000_000),
            ("1KB", 1_000),
        ],
    )
    def test_valid(self, expr, expected):
        assert parse_size(expr) == expected

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            parse_size("not-a-size")


class TestHumanSize:
    def test_bytes(self):
        assert human_size(500) == "500B"

    def test_kb(self):
        assert human_size(212992) == "208kB"

    def test_mb_with_decimal(self):
        # 1.5 * 1024 * 1024 = 1572864
        assert human_size(1572864) == "1.5MB"

    def test_negative_raises(self):
        with pytest.raises(ValueError):
            human_size(-1)


class TestSizeExprMatch:
    def test_greater_than(self):
        assert size_expr_match(20_000_000, ">10000000") is True
        assert size_expr_match(5_000_000, ">10000000") is False

    def test_less_than(self):
        assert size_expr_match(500, "<1024") is True

    def test_equals(self):
        assert size_expr_match(0, "==0") is True

    def test_not_equals(self):
        assert size_expr_match(5, "!=0") is True

    def test_with_suffix_rhs(self):
        assert size_expr_match(20_000_000, ">10M") is True

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            size_expr_match(5, "bogus")


class TestTimeFormatting:
    def test_none_returns_empty(self):
        assert to_snaffler_time(None) == ""

    def test_epoch_zero(self):
        assert to_snaffler_time(0) == "1970-01-01 00:00:00Z"

    def test_now_matches_pattern(self):
        result = now_snaffler_time()
        assert result.endswith("Z")
        assert len(result) == 20  # 'yyyy-MM-dd HH:mm:ssZ'


class TestEscapeField:
    def test_crlf(self):
        assert escape_field("line1\r\nline2") == "line1\\r\\nline2"

    def test_tab(self):
        assert escape_field("a\tb") == "a\\tb"

    def test_lone_lf(self):
        assert escape_field("a\nb") == "a\\nb"

    def test_no_special_chars(self):
        assert escape_field("plain text") == "plain text"

    def test_empty(self):
        assert escape_field("") == ""


class TestExtractContext:
    def test_basic_window(self):
        text = "the quick brown fox jumps over the lazy dog"
        result = extract_context(text, 10, 15, width=20)
        assert "brown" in result

    def test_collapses_whitespace(self):
        text = "a\n\n\n   b"
        result = extract_context(text, 0, 1, width=20)
        assert "\n\n\n" not in result


class TestSplitExtension:
    def test_normal(self):
        assert split_extension("web.config") == ".config"

    def test_dotfile_no_second_dot(self):
        assert split_extension(".npmrc") == ""

    def test_dotfile_with_extension(self):
        assert split_extension(".env.local") == ".local"

    def test_no_extension(self):
        assert split_extension("README") == ""

    def test_case_insensitive_output(self):
        assert split_extension("Secret.PEM") == ".pem"


class TestToUnc:
    def test_full(self):
        assert to_unc("host01", "share", "dir\\file.txt") == "\\\\host01\\share\\dir\\file.txt"

    def test_share_only(self):
        assert to_unc("host01", "share", None) == "\\\\host01\\share"

    def test_host_only(self):
        assert to_unc("host01", None, None) == "\\\\host01"
