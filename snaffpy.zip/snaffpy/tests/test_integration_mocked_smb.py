"""
End-to-end pipeline test using a mocked SMBConnection (no live SMB server
in this environment). Validates share filtering, the directory walk, file
classification with the REAL ported Snaffler ruleset, relay-driven content
scanning, and all three output formats.
"""
from __future__ import annotations

import json
from unittest.mock import MagicMock

from snaffpy.config import Config
from snaffpy.enumerator import Enumerator
from snaffpy.output import OutputSink
from snaffpy.rules.engine import RuleEngine


class FakeSharedFile:
    def __init__(self, name, is_dir=False, size=0, mtime=0.0, ctime=0.0):
        self._name, self._is_dir, self._size = name, is_dir, size
        self._mtime, self._ctime = mtime, ctime

    def get_longname(self):
        return self._name

    def is_directory(self):
        return 1 if self._is_dir else 0

    def get_filesize(self):
        return self._size

    def get_mtime_epoch(self):
        return self._mtime

    def get_ctime_epoch(self):
        return self._ctime


def _fake_conn():
    conn = MagicMock()
    conn.listShares.return_value = [
        {"shi1_netname": b"data\x00", "shi1_type": 0},
        {"shi1_netname": b"IPC$\x00", "shi1_type": 3},
        {"shi1_netname": b"C$\x00", "shi1_type": 0},
    ]

    def list_path(share, pattern):
        pat = pattern.rstrip("/*")
        if share == "data":
            if pat in ("", "data"):
                return [
                    FakeSharedFile(".", is_dir=True),
                    FakeSharedFile("..", is_dir=True),
                    FakeSharedFile("home", is_dir=True),
                    FakeSharedFile("web.config", size=300, mtime=1700000000.0, ctime=1699000000.0),
                ]
            if pat == "home":
                return [
                    FakeSharedFile(".", is_dir=True),
                    FakeSharedFile("..", is_dir=True),
                    FakeSharedFile("id_rsa", size=1679, mtime=1700000001.0, ctime=1699000001.0),
                    FakeSharedFile("notes.txt", size=20, mtime=1700000002.0, ctime=1699000002.0),
                    FakeSharedFile("Groups.xml", size=900, mtime=1700000003.0, ctime=1699000003.0),
                ]
        if share == "C$":  # readable but should not be walked
            return []
        return []

    conn.listPath.side_effect = list_path

    def get_file(share, path, cb):
        if path.endswith("web.config"):
            cb(b'<configuration><appSettings><add key="AWSKey" value="AKIAIOSFODNN7EXAMPLE"/></appSettings></configuration>')
        elif path.endswith("id_rsa"):
            cb(b"-----BEGIN OPENSSH PRIVATE KEY-----\nAAAAB3Nz...\n-----END OPENSSH PRIVATE KEY-----\n")
        elif path.endswith("Groups.xml"):
            cb(
                b'<?xml version="1.0" encoding="utf-8"?>\n'
                b'<Groups><User name="Administrator (built-in)"><Properties action="U" '
                b'cpassword="j1Uyj3Vx8TY9LtLZil2uAuZkFQA/4latT76ZwgdHdhw" '
                b'userName="Administrator (built-in)"/></User></Groups>'
            )

    conn.getFile.side_effect = get_file
    return conn


def _run(cfg):
    engine = RuleEngine(use_default_rules=True)
    enumerator = Enumerator(_fake_conn(), engine, cfg, host="testhost01")
    findings = []
    findings.extend(enumerator.list_shares())
    for share in enumerator.walkable_shares:
        findings.extend(list(enumerator.walk_share(share)))
    return findings, enumerator


class TestPipeline:
    def test_ipc_discarded_data_kept(self):
        cfg = Config(hosts=["testhost01"], username="u", password="p")
        findings, enum = _run(cfg)
        shares = {f.share for f in findings if f.task_type == "Share"}
        assert "data" in shares
        assert "IPC$" not in shares

    def test_cshare_reported_but_not_walked(self):
        cfg = Config(hosts=["testhost01"], username="u", password="p")
        findings, enum = _run(cfg)
        shares = {f.share for f in findings if f.task_type == "Share"}
        assert "C$" in shares  # reported (KeepDollarShares, Black)
        assert "C$" not in enum.walkable_shares  # but not walked

    def test_cshare_walkable_with_include_admin(self):
        cfg = Config(hosts=["testhost01"], username="u", password="p", include_admin=True)
        _, enum = _run(cfg)
        assert "C$" in enum.walkable_shares

    def test_id_rsa_matched_by_real_rule(self):
        cfg = Config(hosts=["testhost01"], username="u", password="p")
        findings, _ = _run(cfg)
        rule_names = {f.rule_name for f in findings}
        assert "KeepSSHKeysByFileName" in rule_names

    def test_relay_drives_aws_key_content_match(self):
        cfg = Config(hosts=["testhost01"], username="u", password="p")
        findings, _ = _run(cfg)
        # web.config -> RelayCSharpByExtension -> KeepAwsKeysInCode (content)
        aws = [f for f in findings if f.rule_name == "KeepAwsKeysInCode"]
        assert len(aws) >= 1
        assert "AKIA" in aws[0].content

    def test_gpp_cpassword_decrypted_end_to_end(self):
        cfg = Config(hosts=["testhost01"], username="u", password="p")
        findings, _ = _run(cfg)
        gpp = [f for f in findings if f.rule_name == "GppDecryptedPassword"]
        assert len(gpp) == 1
        assert gpp[0].decrypted == "Local*P4ssword!"
        assert gpp[0].account == "Administrator (built-in)"
        assert gpp[0].triage.name == "BLACK"

    def test_metadata_populated(self):
        cfg = Config(hosts=["testhost01"], username="u", password="p")
        findings, _ = _run(cfg)
        f = next(f for f in findings if f.rule_name == "KeepSSHKeysByFileName")
        assert f.size == 1679
        assert f.unc == "\\\\testhost01\\data\\home\\id_rsa"
        assert f.permissions == "R"


class TestOutputFormats:
    def _sink(self, tmp_path, fmt, tsv_legacy=False):
        cfg = Config(hosts=["testhost01"], username="u", password="p", out_format=fmt,
                     out_file=str(tmp_path / f"out.{fmt}"), to_console=False, tsv_legacy=tsv_legacy)
        return cfg, OutputSink(cfg)

    def test_plain(self, tmp_path):
        cfg, sink = self._sink(tmp_path, "plain")
        findings, _ = _run(Config(hosts=["testhost01"], username="u", password="p"))
        for f in findings:
            sink.write(f)
        sink.flush()
        lines = (tmp_path / "out.plain").read_text().splitlines()
        assert len(lines) == len(findings)
        assert all(l.startswith("[") for l in lines)

    def test_tsv_14col(self, tmp_path):
        cfg, sink = self._sink(tmp_path, "tsv")
        findings, _ = _run(Config(hosts=["testhost01"], username="u", password="p"))
        ff = [f for f in findings if f.task_type == "File"]
        for f in ff:
            sink.write(f)
        sink.flush()
        for line in (tmp_path / "out.tsv").read_text().splitlines():
            assert len(line.split("\t")) == 14

    def test_tsv_13col_legacy(self, tmp_path):
        cfg, sink = self._sink(tmp_path, "tsv", tsv_legacy=True)
        findings, _ = _run(Config(hosts=["testhost01"], username="u", password="p"))
        ff = [f for f in findings if f.task_type == "File"]
        for f in ff:
            sink.write(f)
        sink.flush()
        for line in (tmp_path / "out.tsv").read_text().splitlines():
            assert len(line.split("\t")) == 13

    def test_json_ndjson(self, tmp_path):
        cfg, sink = self._sink(tmp_path, "json")
        findings, _ = _run(Config(hosts=["testhost01"], username="u", password="p"))
        ff = [f for f in findings if f.task_type == "File"]
        for f in ff:
            sink.write(f)
        sink.flush()
        for line in (tmp_path / "out.json").read_text().splitlines():
            obj = json.loads(line)
            assert "message" in obj and "unc" in obj["message"]
