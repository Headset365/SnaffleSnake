"""Tests for GPP cpassword decryption (snaffpy.gpp)."""
from __future__ import annotations

import pytest

from snaffpy import gpp


class TestDecryptCpassword:
    # Public, widely-published GPP test vectors -> known plaintext.
    def test_known_vector_1(self):
        assert gpp.decrypt_cpassword("j1Uyj3Vx8TY9LtLZil2uAuZkFQA/4latT76ZwgdHdhw") == "Local*P4ssword!"

    def test_known_vector_2(self):
        cpw = "edBSHOwhZLTjt/QS9FeIcJ83mjWA98gw9guKOhJOdcqh+ZGMeXOsQbCpZ3xUjTLfCuNH8pG5aSVYdYw/NglVmQ"
        assert gpp.decrypt_cpassword(cpw) == "GPPstillStandingStrong2k18"

    def test_padding_is_restored(self):
        # Same value, padding stripped, still decrypts.
        assert gpp.decrypt_cpassword("j1Uyj3Vx8TY9LtLZil2uAuZkFQA/4latT76ZwgdHdhw") == "Local*P4ssword!"

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            gpp.decrypt_cpassword("")

    def test_garbage_raises(self):
        with pytest.raises(ValueError):
            gpp.decrypt_cpassword("!!!not base64!!!")


GROUPS_XML = """<?xml version="1.0" encoding="utf-8"?>
<Groups clsid="{3125E937-EB16-4b4c-9934-544FC6D24D26}">
  <User clsid="{DF5F1855}" name="Administrator (built-in)">
    <Properties action="U" cpassword="j1Uyj3Vx8TY9LtLZil2uAuZkFQA/4latT76ZwgdHdhw"
      changeLogon="0" noChange="1" userName="Administrator (built-in)"/>
  </User>
</Groups>"""

SERVICES_XML = """<NTServices>
  <Service><Properties accountName="svc_backup"
    cpassword="edBSHOwhZLTjt/QS9FeIcJ83mjWA98gw9guKOhJOdcqh+ZGMeXOsQbCpZ3xUjTLfCuNH8pG5aSVYdYw/NglVmQ"/></Service>
</NTServices>"""

EMPTY_CPW_XML = '<User><Properties cpassword="" userName="nobody"/></User>'


class TestExtractGppSecrets:
    def test_extracts_and_decrypts_with_account(self):
        secrets = gpp.extract_gpp_secrets(GROUPS_XML)
        assert len(secrets) == 1
        assert secrets[0].password == "Local*P4ssword!"
        assert secrets[0].account == "Administrator (built-in)"
        assert secrets[0].error == ""

    def test_services_accountname(self):
        secrets = gpp.extract_gpp_secrets(SERVICES_XML)
        assert len(secrets) == 1
        assert secrets[0].password == "GPPstillStandingStrong2k18"
        assert secrets[0].account == "svc_backup"

    def test_empty_cpassword_ignored(self):
        assert gpp.extract_gpp_secrets(EMPTY_CPW_XML) == []

    def test_no_cpassword_returns_empty(self):
        assert gpp.extract_gpp_secrets("<xml>nothing here</xml>") == []

    def test_multiple_secrets(self):
        combined = GROUPS_XML + "\n" + SERVICES_XML
        secrets = gpp.extract_gpp_secrets(combined)
        passwords = {s.password for s in secrets}
        assert "Local*P4ssword!" in passwords
        assert "GPPstillStandingStrong2k18" in passwords


class TestIsGppFile:
    def test_recognizes_gpp_names(self):
        assert gpp.is_gpp_file("Groups.xml")
        assert gpp.is_gpp_file("services.xml")  # case-insensitive
        assert not gpp.is_gpp_file("web.config")
