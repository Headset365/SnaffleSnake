import textwrap

import pytest

from snaffpy.models import EnumScope, MatchAction, Target, Triage
from snaffpy.rules.engine import RuleEngine, RuleLoadError


def _write_rules(tmp_path, yaml_text: str) -> str:
    path = tmp_path / "rules.yaml"
    path.write_text(textwrap.dedent(yaml_text))
    return str(path)


class TestWordListTypes:
    def test_exact_match(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: ExactExt
                enum_scope: file
                match_location: file_extension
                wordlist_type: exact
                wordlist: [".pem"]
                triage: red
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", extension=".pem")
        result = engine.classify(target, EnumScope.FILE)
        assert result is not None
        assert result[0].triage == Triage.RED
        assert result[0].name == "ExactExt"

    def test_exact_no_match_on_partial(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: ExactExt
                enum_scope: file
                match_location: file_extension
                wordlist_type: exact
                wordlist: [".pem"]
                triage: red
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", extension=".pemx")
        assert engine.classify(target, EnumScope.FILE) is None

    def test_contains_match(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: ContainsPath
                enum_scope: file
                match_location: file_path
                wordlist_type: contains
                wordlist: ["password"]
                triage: yellow
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", path="backup\\password_list.txt")
        result = engine.classify(target, EnumScope.FILE)
        assert result is not None
        assert result[0].triage == Triage.YELLOW

    def test_startswith_match(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: StartsWithName
                enum_scope: file
                match_location: file_name
                wordlist_type: startswith
                wordlist: ["backup_"]
                triage: yellow
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", name="backup_2024.zip")
        assert engine.classify(target, EnumScope.FILE) is not None

    def test_endswith_match(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: EndsWithName
                enum_scope: file
                match_location: file_name
                wordlist_type: endswith
                wordlist: ["_bak"]
                triage: yellow
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", name="config_bak")
        assert engine.classify(target, EnumScope.FILE) is not None

    def test_regex_match(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            r"""
            rules:
              - name: RegexName
                enum_scope: file
                match_location: file_name
                wordlist_type: regex
                wordlist: ['^id_(rsa|dsa)$']
                triage: red
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", name="id_rsa")
        result = engine.classify(target, EnumScope.FILE)
        assert result is not None
        assert "id_" in result[1]

    def test_file_length_greater_than(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: BigFile
                enum_scope: file
                match_location: file_length
                wordlist_type: exact
                wordlist: [">10000000"]
                triage: yellow
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        big = Target(host="h", size=20_000_000)
        small = Target(host="h", size=100)
        assert engine.classify(big, EnumScope.FILE) is not None
        assert engine.classify(small, EnumScope.FILE) is None


class TestPrecedence:
    def test_highest_triage_wins(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: LowPriority
                enum_scope: file
                match_location: file_extension
                wordlist_type: exact
                wordlist: [".txt"]
                triage: yellow
              - name: HighPriority
                enum_scope: file
                match_location: file_path
                wordlist_type: contains
                wordlist: ["secret"]
                triage: red
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        # Matches both rules: .txt (yellow) and "secret" in path (red).
        target = Target(host="h", extension=".txt", path="secret\\notes.txt")
        result = engine.classify(target, EnumScope.FILE)
        assert result is not None
        assert result[0].triage == Triage.RED
        assert result[0].name == "HighPriority"

    def test_discard_wins_over_snaffle(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            """
            rules:
              - name: KeepIt
                enum_scope: share
                match_location: share_name
                wordlist_type: contains
                wordlist: ["IPC"]
                triage: black
                match_action: snaffle
              - name: DiscardIt
                enum_scope: share
                match_location: share_name
                wordlist_type: contains
                wordlist: ["IPC"]
                triage: green
                match_action: discard
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", share="IPC$")
        result = engine.classify(target, EnumScope.SHARE)
        assert result is not None
        assert result[0].match_action == MatchAction.DISCARD


class TestContentScanning:
    def test_password_regex_hit(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            r"""
            rules:
              - name: PasswordInContent
                enum_scope: contents
                match_location: file_content
                wordlist_type: regex
                wordlist: ['(?i)password\s*=\s*\S+']
                triage: red
                match_length: 40
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", share="s", path="config.txt", name="config.txt")
        data = b"some header text\npassword = Hunter2\nmore text after"
        findings = engine.scan_content(data, target)
        assert len(findings) == 1
        assert findings[0].triage == Triage.RED
        assert "password" in findings[0].content.lower()
        assert "Hunter2" in findings[0].content

    def test_no_match_returns_empty(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            r"""
            rules:
              - name: PasswordInContent
                enum_scope: contents
                match_location: file_content
                wordlist_type: regex
                wordlist: ['(?i)password\s*=\s*\S+']
                triage: red
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", share="s", path="config.txt", name="config.txt")
        data = b"nothing interesting here"
        assert engine.scan_content(data, target) == []

    def test_multiple_hits_in_one_file(self, tmp_path):
        rules_path = _write_rules(
            tmp_path,
            r"""
            rules:
              - name: AwsKey
                enum_scope: contents
                match_location: file_content
                wordlist_type: regex
                wordlist: ['AKIA[0-9A-Z]{16}']
                triage: black
            """,
        )
        engine = RuleEngine(rule_paths=[rules_path], use_default_rules=False)
        target = Target(host="h", share="s", path="creds.txt", name="creds.txt")
        data = b"key1=AKIAABCDEFGHIJKLMNOP\nkey2=AKIAZYXWVUTSRQPONMLK"
        findings = engine.scan_content(data, target)
        assert len(findings) == 2


class TestRuleLoading:
    def test_missing_file_raises(self):
        with pytest.raises(RuleLoadError):
            RuleEngine(rule_paths=["/nonexistent/path.yaml"], use_default_rules=False)

    def test_invalid_yaml_raises(self, tmp_path):
        path = tmp_path / "bad.yaml"
        path.write_text("rules: [this is not: valid: yaml: at all")
        with pytest.raises(RuleLoadError):
            RuleEngine(rule_paths=[str(path)], use_default_rules=False)

    def test_no_rules_and_no_default_raises(self):
        with pytest.raises(RuleLoadError):
            RuleEngine(rule_paths=[], use_default_rules=False)

    def test_later_file_overrides_earlier_by_name(self, tmp_path):
        first = _write_rules(
            tmp_path.joinpath("f1").mkdir() or tmp_path / "f1",
            """
            rules:
              - name: Overridden
                enum_scope: file
                match_location: file_extension
                wordlist_type: exact
                wordlist: [".a"]
                triage: green
            """,
        )
        second_dir = tmp_path / "f2"
        second_dir.mkdir()
        second = _write_rules(
            second_dir,
            """
            rules:
              - name: Overridden
                enum_scope: file
                match_location: file_extension
                wordlist_type: exact
                wordlist: [".b"]
                triage: black
            """,
        )
        engine = RuleEngine(rule_paths=[first, second], use_default_rules=False)
        rules = engine.rules_for(EnumScope.FILE)
        assert len(rules) == 1
        assert rules[0].triage == Triage.BLACK
        assert rules[0].wordlist == [".b"]

    def test_default_rules_load(self):
        engine = RuleEngine(use_default_rules=True)
        assert len(engine.rules_for(EnumScope.SHARE)) > 0
        assert len(engine.rules_for(EnumScope.FILE)) > 0
        assert len(engine.rules_for(EnumScope.CONTENTS)) > 0


class TestDropRule:
    def test_drop_existing_rule(self):
        engine = RuleEngine(use_default_rules=True)
        names_before = {r.name for r in engine.rules_for(EnumScope.SHARE)}
        assert "DiscardNonFileShares" in names_before
        assert engine.drop_rule("DiscardNonFileShares") is True
        names_after = {r.name for r in engine.rules_for(EnumScope.SHARE)}
        assert "DiscardNonFileShares" not in names_after

    def test_drop_nonexistent_rule_returns_false(self):
        engine = RuleEngine(use_default_rules=True)
        assert engine.drop_rule("ThisRuleDoesNotExist") is False
